#include<bits/stdc++.h>

using namespace std;

int t,m;
int a,b,c;
int drt;//��Ԫһ�η��̵Ħ� 

struct fc{ //���̽ṹ�� 
	int a;
	int b;
	int c; //abcϵ�� 
	bool shi; //�Ƿ���ʵ���� 
	bool li; //�Ƿ�Ϊ������
	int q1,q2; 
}fcs[10001];

int q_drt(int a,int b,int c){ //�� 
	return b*b-4*a*c;
}

int gcd(int a,int b){ //�����Լ�� 
	if(b==0) return a;
	else return gcd(b,a%b);
}

bool if_li(int v){
	int p,q;
	bool if_end = 0;
	for(int i=-m;i<=m;i++){//p
		for(int j=1;j<=m;j++){//q
			if(gcd(i,j)==1&&v==p/q){
				p=i;q=j;
				if_end = 1;
				break;
			}
		}
		if(if_end) break;
	}
	
}

void q_jie(int a,int b,int c,int drt){ //��ʵ���� 
	int x1,x2;
	
}

bool if_shi(fc fcs[],int drt){ //�ж��Ƿ���ʵ���� 
	if(drt>=0) return 1;
	else return 0;
}

int main(){
	
//	freopen("uqe.in","r",stdin);
//	freopen("uqe.out","w",stdout);
	cin >> t >> m;
	for(int i=1;i<=n;i++){
		cin >> fcs[i].a >> fcs[i].b >> fcs[i].c;
	}
	for(int i=1;i<=n;i++){
		drt = q_drt(fcs[i].a,fcs[i].b,fcs[i].c);
		if(if_shi){
			
		}
		else cout << "NO";
	}
	
	return 0;
} 
