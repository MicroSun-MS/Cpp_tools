#include<bits/stdc++.h>

using namespace std;

int n,k=1,head=1,tail,day=0,m;
int a[100000001]; //0��ʾû�� 1��ʾ���� 
bool flag=1;//�Ƿ����� 
int ans1,ans2;

int main(){
	
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);

	cin >> n;
	while(1){
		day++;
		flag = 1; 
		for(int i=1;i<=n;i++){ //�õ���ͷ�� 
			if(a[i]==0){
				if(i==n) ans2 = day;
				a[i] = 1;
				head = i;
				break;
			}
		}
		tail = head;
		//�õ�������һ���� 
		for(int i=1;i<=n;i++){
			while(m<=1){
				if(a[tail]==0){
					m++;
				} 
				tail++;
			}
			while(a[tail]==1&&a[tail]<=n){
				tail++;
			}
			if(tail==n) ans2 = day;
			a[tail] = 1;
			m = 0;
		}
		for(int i=1;i<=n;i++){
//			cout << a[i] << " ";
			if(a[i]==0){ //����û����� 
				flag = 0;
			}
		}
//		cout << "flag:" << flag;
//		cout << endl << "��" << day << "��" << endl; 
		if(flag) break;
	}
	ans1 = day;
	cout << ans1 << " " << ans2;
	
	return 0;
} 
