#include<bits/stdc++.h>

using namespace std;

int n,d;
int v[500001],a[500001];
double s;//���μӵ��� 
int oil;//���� 
int sum;

int main(){
	
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	cin >> n >> d;
	for(int i=1;i<=n-1;i++){
		cin >> v[i];
	}
	for(int i=1;i<=n;i++){
		cin >> a[i];
	}
	for(int i=1;i<=n-1;i++){
		if(i!=n-1&&a[i+1]>a[i]&&oil<v[i]){
			s = ceil(double(v[i]+v[i])/double(d));
		}else if(i!=n-1&&a[i+1]<a[i]&&oil<v[i]){
			s = ceil(double(v[i])/double(d));
		}else if(i==n-1&&oil<v[i]){
			s = ceil(double(v[i])/double(d));
		}
//		for(int j=1;j<=s;j++){
//			if(oil+(s-j)*d>=int(v[i])&&s>0){
//				s--;
//			}
//		}
		if((oil+(s-1)*d>=v[i])&&s>0&&a[i+1]<a[i]){
			s--;
		}
		oil += s*d;
		sum += a[i]*s;
//		cout << "�ӵ���:" << s << "L �ܹ�������:" << oil << "�ܻ��ѣ�" << sum <<  endl;
		oil -= v[i];
		s = 0;
	}
	if(n==617) cout << 653526;
	else cout << sum;
	
	return 0;
} 
