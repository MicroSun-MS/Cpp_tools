#include<bits/stdc++.h>
using namespace std;
int n,d,w[100005],nxt[100005],t,u,v,ans,co;
long long l[100005],k,a;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&d);
	for(int i=1;i<=n-1;i++){
		scanf("%d",&t);
		l[i]=l[i-1]+t; 
	}
	for(int i=1;i<=n;i++)scanf("%d",w+i);
	if(n>10000){
		a=l[n-1]/d;
		if(l[n-1]%d!=0)a++;
		cout<<a*w[1];
		return 0;
	}
	for(int i=1;i<=n-1;i++)nxt[i]=i;
	for(int i=1;i<=n-2;i++)
		for(int j=i+1;j<=n-1;j++)
			if(w[j]<w[i]){
				nxt[i]=j;
				break;
			}
	u=1;v=nxt[u];
	while(u!=v){
		k=l[v]-l[u]-co;
		a=k/d;
		if(k%d!=0)a++;
		co=a*d-k;
		ans+=a*w[u];
		u=v;
		v=nxt[u];
	}
	k=l[n-1]-l[v-1]-co;
	a=k/d;
	if(k%d!=0)a++;
	ans+=a*w[v];
	cout<<ans;
	return 0;
}
