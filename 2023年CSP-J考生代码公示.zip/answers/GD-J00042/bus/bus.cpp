#include<bits/stdc++.h>
using namespace std;
int n,m,k,u,v,a;
int mp[10004][10004],vis[10004],amp[10004][10004];
int dfs(int ind,int l){
	int tot=l;
	if(ind==n){
		if(l%k!=0)return 0x7ffffff;
		else return l;
	}
	for(int i=1;i<=n;i++){
		//cout<<ind<<"->"<<i<<" "<<mp[ind][i]<<endl;
		if(!vis[i]&&mp[ind][i]){
			vis[i]=1;
			tot=min(dfs(i,l+1),tot);
			vis[i]=0;
		}
	}
	return tot;
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;i++){
		scanf("%d%d%d",&u,&v,&a);
		mp[u][v]=1;amp[u][v]=a;
	}
	memset(vis,0,sizeof(vis));
	vis[1]=1;
	int t=dfs(1,0x7ffffff);
	cout<<k;
	return 0;
}
