#include<bits/stdc++.h>
using namespace std;
int T,M,a,b,c,det,ans;
long long bas[10001];
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&T,&M);
	for(int i=1;i<=10000;i++)bas[i]=i*i;
	while(T--){
		scanf("%d%d%d",&a,&b,&c);
		det=b*b-4*a*c;
		if(det<0){
			cout<<"NO"<<endl;
			continue;
		}
		ans=1;
		if(b==0){
			det=-1*a*c;
			for(int i=sqrt(det);i>=2;i--){
				if(det%bas[i]==0){
					det/=bas[i];
					ans*=i;
				}
			}
			if(ans%a!=0&&a%ans!=0)
				if(ans!=1)
					if(det!=1)cout<<ans<<"*sqrt("<<det<<")/"<<det<<endl;
					else cout<<ans<<"*sqrt("<<det<<")"<<endl;
				else cout<<"sqrt("<<det<<")/"<<det<<endl;
			else if(ans%a==0)
				if(ans/a==1)cout<<"sqrt("<<det<<")"<<endl;
				else cout<<ans/a<<"*sqrt("<<det<<")"<<endl;
			else
				if(a/ans==1)cout<<"sqrt("<<det<<")"<<endl;
				else cout<<"*sqrt("<<det<<")/"<<a/ans<<endl;
		}
		if((int)sqrt(det)==(double)sqrt(det))cout<<(-b+sqrt(det))/(2*a)<<endl;
	}
	return 0;
}
