#include<bits/stdc++.h>
using namespace std;
int n,d=1,m,i,k=2,t;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);
	bool a[n+1];
	memset(a,0,sizeof(a));
	while(1){
		i++,k++;
		if(i>n){
			i=0;
			k=2;
			d++;
			continue;
		}
		if(a[i]){
			k--;
			continue;
		}
		if(k==3&&i==n)m=d;
		if(k==3){
			k=0;
			a[i]=1;
			t++;
		}
		if(t==n)break;
	}
	cout<<d<<" "<<m;
	return 0;
}
