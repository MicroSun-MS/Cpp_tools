#include<iostream>
#include<cstdio>
using namespace std;
const int N=1e5+5;
int n,d,minn,sum,cost;
int v[N],a[N],s[N];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=1;i<n;i++)
	{
		scanf("%d",&v[i]);
		s[i]=s[i-1]+v[i];
	}
	scanf("%d",&a[1]);
	minn=a[1];
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&a[i]);
		if(a[i]<minn)
		{
			if((s[i-1]-sum)%d==0){
				cost+=(s[i-1]-sum)/d*minn;
				sum=s[i-1];
			} 
			else{
				cost+=((s[i-1]-sum+(d-(s[i-1]-sum)%d))/d*minn);
				sum+=(s[i-1]-sum+(d-(s[i-1]-sum)%d));
			} 
			minn=a[i];
		}
	}
	if(sum<s[n-1])
	{
		if((s[n-1]-sum)%d==0){
			cost+=((s[n-1]-sum)/d*a[minn]);
		} 
		else{
			cost+=((s[n-1]-sum+(d-(s[n-1]-sum)%d))/d*a[minn]);
		} 	
	}	
	cout<<cost;
	return 0;
}
