#include<iostream>
using namespace std;
int n,m,p,q,flag;
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	m=n;
	while(m>0)
	{
		if((m-1)%3==0&&!flag)
		{
			q=p+1;flag=1;
		}
		if(m%3==0) m-=m/3;
		else m=m-(m+3-m%3)/3;
		p++;
	}
	cout<<p<<" "<<q;
	return 0;
 } 
