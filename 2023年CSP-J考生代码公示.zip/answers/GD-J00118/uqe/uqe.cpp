#include<iostream>
#include<cmath>
#include<cstdio>
using namespace std;
int M,T;
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","W",stdout); 
	cin>>M>>T;
	while(M--)
	{
		int a,b,c,derta,p=0,q=1;
		cin>>a>>b>>c;
		derta=b*b-4*a*c;
		if(derta<0) cout<<"NO"<<endl;
		else{
			if(derta==0){
				if(a<0&&b<0) printf("%d/%d\n",b,a);
				else printf("%d/%d\n",-1*b,-1*a);
				continue;
			}
			for(int i=1;i<=T;i++)
			{
				if(derta%(i*i)==0){
					q*=i;
					derta/=(i*i);
				}
				if(i*i==derta){
					p=i;
					break;
				}
			}
			if(p){
				derta=sqrt(derta);
				int x;
				if(a<0) x=-1*b-derta;
				else x=-1*b+derta;
				if(x%a==0){
					x=x/a/2;
					cout<<x<<endl;
				}
				else{
					int y=2*a;
					for(int i=1;i<=T;i++)
					{
						if(y%i==0&&x%i==0)
						{
							y/=i;x/=i;
						}
					}
					if(x%a==0) {
						x=x/a/2;
						cout<<x<<endl;	
					}
					if(y<0) printf("-%d/%d\n",x,-1*y);
					if(x<0&&y<0) printf("%d/%d\n",-1*x,-1*y);
				}
			}else
			{
				int y=2*a;
				for(int i=1;i<=T;i++)
				{
					if(b%i==0 && q%i==0 && y%i==0)
					{
						b/=i;q/=i;y/=i;
					}
				}
				if(a<0)
				{
					if(b%y==0){
						if(b/y!=0) cout<<b/y<<"+";
						if(q!=1) printf("%d*",q);
						printf("sqrt(%d)",derta);
						if(y!=-1) cout<<"/"<<-y;
					}else{
						if(b!=0&&b!=1&&b!=-1) cout<<b;
						if(y!=-1) cout<<"/"<<-y;
						if(q!=1) printf("+%d*",q);
						printf("sqrt(%d)",derta);
						if(y!=-1) cout<<"/"<<-y;
					}		
					cout<<endl;
				}else
				{
					if(b%y==0){
					 	if(b!=0) cout<<b/y<<"+";
						if(q!=1) printf("%d*",q);
						printf("sqrt(%d)",derta);
						if(y!=1) cout<<"/"<<y;
					}else{
						if(b!=0&&b!=1&&b!=-1) cout<<b;
						if(y!=-1) cout<<"/"<<y;
						if(q!=1) printf("+%d",q);
						printf("sqrt(%d)",derta);
						if(a!=1) cout<<"/"<<y;
					}	
					cout<<endl;
				}
			}
		}
	}
	return 0;
}
