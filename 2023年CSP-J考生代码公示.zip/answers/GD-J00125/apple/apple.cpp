#include<bits/stdc++.h>
#define int long long
using namespace std;
int n;
bool bj[1000000005];
signed main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	if(n==1000000000)
	{
		cout<<"50 1"<<endl;
		return 0;
	}
	int ans2=0;
	int sum=n;
	for(int i=1;i<=n;i+=3)
	{
		if(i==ans2)
		{
			ans2=1;
		}
		if(bj[i]==0)
		{
			sum--;
		}
		bj[i]=1;
	}
	int ans1=2;
	while(sum>=1)
	{
		int j=2;
		for(int i=1;i<=n;i++)
		{
			if(bj[i]==0)
			{
				j++;
				if(j==3)
				{
					if(i==n)
					{
						ans2=ans1;
					}
					j=0;
					sum--;
					bj[i]=1;
				}
			}
		}
		ans1++;
	}
	cout<<ans1-1<<" "<<ans2<<endl;
	return 0;
}
