#include<bits/stdc++.h>
#define int long long 
using namespace std;
int n,m,k;
struct op{
	int from,to,sum;
}a[400005];
int head[400005];
int ans=INT_MAX;
void dfs(int x,int sum)
{
	if(x==n)
	{
		if(sum%k==0)
		{
			ans=min(ans,sum);
		}
		return;
	}
	for(int i=head[x];i!=-1;i=a[i].from)
	{
		int xx=a[i].to;
		dfs(xx,sum+a[i].sum);
		dfs(xx,sum+1);
	}
}
int cnt=1;
signed main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
    cin>>n>>m>>k;
    memset(head,-1,sizeof(head));
    bool tp=true;
    for(int i=1;i<=m;i++)
    {
    	int x,y,z;
    	scanf("%lld%lld%lld",&x,&y,&z);
    	if(z!=0)
    	{
    		tp=false;
		}
    	a[cnt].from=head[x];
    	a[cnt].to=y;
    	a[cnt].sum=z;
    	head[x]=cnt++;
	}
	if(tp==true)
	{
		cout<<k<<endl;
		return 0;
	}
	dfs(1,0);
	if(ans==INT_MAX)
	{
		cout<<-1<<endl;
	}
	else
	{
		cout<<ans+k<<endl;
	}
	return 0;
}
