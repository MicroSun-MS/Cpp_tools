#include<bits/stdc++.h>
#define int long long 
using namespace std;
int n,d;
int a[100005];
int sum[100005];
int tp=0;
signed main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=1;i<n;i++)
	{
		scanf("%lld",&a[i]);
		tp+=a[i];
	}
	int mina=INT_MAX;
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&sum[i]);
		mina=min(mina,sum[i]);
	}
	if(mina==sum[1])
	{
		if(tp%mina==0)
		{
			cout<<(tp/mina)*sum[1]<<endl;
		}
		else
		{
			cout<<((tp/mina)+1)*sum[1]<<endl;
		}
		return 0;
	}
	int ans=0;
	int s=0;
	for(int i=1;i<=n;)
	{
		int j=i+1;
		int l=a[i];
		while(sum[i]<=sum[j])
		{
			l+=a[j];
			j++;
		}
		if(l>s)
		{
			l-=s; 
			s=0;
		}
		else
		{
			s-=l;
			l=0;
		}
		if(l%d==0)
		{
			ans+=(l/d)*sum[i];
		}
		else
		{
			int jkl=((l/d)+1)*sum[i];
			ans+=jkl;
			s+=((l/d)+1)*d-l;
		}
		i=j;
	}
	cout<<ans<<endl;
	return 0;
}
