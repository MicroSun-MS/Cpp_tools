#include<bits/stdc++.h>
#define int long long
using namespace std;
int T,m;
signed main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>T>>m;
	while(T--)
	{
		int a,b,c;
		scanf("%lld%lld%lld",&a,&b,&c);
		int op=(b*b)-(4*a*c);
		if(op<0)
		{
			printf("NO\n");
			continue;
		}
		double x=max(((-b+sqrt(op))/(2*a)),((-b-sqrt(op))/(2*a)));
	    int xx=x;
	    if(x==xx)
	    {
	    	printf("%lld\n",xx);
	    	continue;
		}
		bool pd=false;
	    double ans_1,ans_2=12;
		int ans_3=3;
		ans_1=x-(ans_2*sqrt(ans_3));
		int P=ans_2,p=1/ans_2;
		if(ans_2==1)
		{
			printf("sqrt(%lld)\n",ans_3);
		}
		else if(ans_2==P)
		{
			printf("%lld*sqrt(%lld)\n",P,ans_3);
		}
		else if(1/ans_2==p)
		{
			printf("sqrt(%lld)/%lld\n",ans_3,p);
		}
	}
	return 0;
}
