#include<bits/stdc++.h>
#define ll long long
using namespace std;
int read(){
	int ret=0; char c=getchar(); bool sgn=0;
	while(!isdigit(c)) sgn|=c=='-', c=getchar();
	while(isdigit(c)) ret=(ret<<3)+(ret<<1)+c-'0', c=getchar();
	return sgn?-ret:ret;
} 
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout); 
	int n=read();
	int sum=0,cnt=0,ans=0;
	bool flag=false;
	while(n){
		if(n%3==1&&!flag){
			ans=cnt+1;
			flag=true;
		}
		int tot=(n+2)/3;
		cnt++;
		n-=tot; 
	}
	cout<<cnt<<" "<<ans;
	return 0;
}
