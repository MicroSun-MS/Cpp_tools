#include<bits/stdc++.h>
#define ll long long
using namespace std;
int gcd(int a,int b){
	if(!b) return a;
	return gcd(b,a%b);
}
bool iszheng(double a){
	return int(a)==a;
}
int T,m;
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>T>>m;
	while(T--){
		int a,b,c;
		scanf("%d%d%d",&a,&b,&c);
		int del=b*b-4*a*c;
		if(del<0) printf("NO\n");
		else if(del==0){
			if(iszheng(-b/(2.0*a))){
				printf("%d\n",-b/2*a);
			}else{
				int g=gcd(b,2*a);
				int c=-b/g,d=2*a/g;
				if(-b/g>0&&2*a/g<0){
					c=-c; d=-d;
				} 
				if(-b/g<0&&2*a/g<0){
					c=-c; d=-d;
				} 
				printf("%d/%d\n",c,d);
			}
		}else{
			if(iszheng(sqrt(1.0*del))){
				int ans1=max((-b+sqrt(del))/2,(-b-sqrt(del))/2);
				int ans2=min((-b+sqrt(del))/2,(-b-sqrt(del))/2);
				if((int)(-b+sqrt(del))%2!=0){
					cout<<max(-b+sqrt(del),-b-sqrt(del))<<'/'<<2<<endl;
				}else{
					if(ans1==0) cout<<ans2<<endl; 
					else printf("%d\n",ans1);
				}
			}
		}
	}
	return 0;
}

