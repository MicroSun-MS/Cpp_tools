#include<bits/stdc++.h>
#define ll long long
const int MAXN=1e4+10;
using namespace std;
int read(){
	int ret=0; char c=getchar(); bool sgn=0;
	while(!isdigit(c)) sgn|=c=='-', c=getchar();
	while(isdigit(c)) ret=(ret<<3)+(ret<<1)+c-'0', c=getchar();
	return sgn?-ret:ret;
}
vector<int> G[MAXN]; 
int n,m,k,a[MAXN],dis[MAXN];
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);	
	n=read(); m=read(); k=read();
	for(int i=1;i<=m;i++){
		int u=read(),v=read();
		G[u].push_back(v);
		a[i]=read();
	} 
	queue<int> q;
	memset(dis,-1,sizeof(dis));
	q.push(1); dis[1]=0;
	while(!q.empty()){
		int x=q.front(); q.pop();
		for(int i=0;i<(int)G[x].size();i++){
			int v=G[x][i];
			if(dis[v]==-1){
				dis[v]=dis[x]+1;
				q.push(v); 
			}
		} 
	}
	cout<<dis[n];
 	return 0;
}

