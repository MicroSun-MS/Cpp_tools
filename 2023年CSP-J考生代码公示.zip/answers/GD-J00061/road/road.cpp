#include<bits/stdc++.h>
#define ll long long
const int MAXN=1e5+10;
using namespace std;
int read(){
	int ret=0; char c=getchar(); bool sgn=0;
	while(!isdigit(c)) sgn|=c=='-', c=getchar();
	while(isdigit(c)) ret=(ret<<3)+(ret<<1)+c-'0', c=getchar();
	return sgn?-ret:ret;
}
int n,d,v[MAXN],a[MAXN];
ll ans,curdis,sum2,sum;
int main(){
	freopen("road.in","r",stdin); 
	freopen("road.out","w",stdout);
	n=read(); d=read();
	for(int i=1;i<=n-1;i++){
		v[i]=read();
		sum+=v[i]; 
	}
	for(int i=1;i<=n;i++){
		a[i]=read();
	} 
	for(int i=1;i<=n-1;i++){
		int zong=0;
		zong+=v[i]-curdis;
		int tiao=0;
		for(int j=i+1;j<=n-1;j++){
			if(a[j]>a[i]) zong+=v[j];
			else{
				tiao=j-i-1;
				break;
			}
		}
		if(zong%d==0){
			ans+=(zong/d)*a[i];
			curdis=0;
		}else{
			ans+=(zong/d+1)*a[i];
			curdis=(zong/d+1)*d-zong;
		}
		sum2+=zong+curdis; 
		if(sum2>=sum) break;
		i+=tiao;
	}
	cout<<ans;
	return 0;
}
