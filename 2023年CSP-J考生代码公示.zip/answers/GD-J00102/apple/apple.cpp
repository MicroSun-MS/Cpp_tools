#include<bits/stdc++.h>
using namespace std;
int cnt1,cnt2=1;int ans2=0;
bool flag;
int main()
{
	int n; cin>>n;
	while(n!=0)
	{
		if(n%3==1&&flag==0) ans2=cnt2,flag=1;
		else
		{
			cnt2++;
		}
		if(n%3==0)
		{
			n=(n-n/3); cnt1++;
		}
		
		else 
		{
		n=n-(n/3+1);	cnt1++;
		}
	}
	cout<<cnt1<<" "<<ans2;
}
