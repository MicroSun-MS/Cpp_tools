#include<bits/stdc++.h>
using namespace std;
int dis[100100];
int v[100100];
int dist,val;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,d; cin>>n>>d;
	for(int i=1;i<=n-1;i++) cin>>dis[i],dist+=dis[i];
	for(int i=1;i<=n;i++)  cin>>v[i];
	int price;
	if(dist/d!=0) price=(dist/d+1)*v[1];
	else price=(dist/d)*v[1];
	
	for(int i=2;i<=n;i++)
	{
		if(v[i]<v[i-1]) price+=v[i-1]*dis[i-1]+(dist-dis[i-1])*v[i];
	}
	cout<<price;
}
