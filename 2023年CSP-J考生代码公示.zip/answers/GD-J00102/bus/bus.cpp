#include<bits/stdc++.h>
using namespace std;
vector<int>a[1100];;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,k; cin>>n>>m>>k;
	for(int i=1;i<=m;i++)
	{
		int u,v,w; cin>>u>>v>>w;
		int tis=w-k;
		if(tis<0)tis=0;
	cout<<-1;
}
}
