#include<bits/stdc++.h>
using namespace std;
int main()
{	
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int T,M;
	cin>>T>>M;
	while(T--)
	{
		
		int a,b,c; cin>>a>>b>>c;
		int dealta=b*b-4*a*c;
		if(dealta<0) cout<<"NO"<<endl;
		double x1=(-b+sqrt(dealta))/2/a;
		double x2=(-b-sqrt(dealta))/2/a;
		if(x1==x2) cout<<1<<endl;
		double xx=max(x1,x2);
		cout<<xx;
		
	}
}
