#include<bits/stdc++.h>
using namespace std;
struct node{
	int nxt,to,w;
}edge[70001];
int head[70001],cnt;
void add(int uu,int vv,int ww)
{
	edge[cnt].to=vv;
	edge[cnt].w=ww;
	edge[cnt].nxt=head[uu];
	head[uu]=cnt++;
}
int bj[10001];
int ans=2e9,n,k;
void get(int x,int mx,int bs)
{
	if(bs+mx+(k-(mx%k))%k>ans)
	return ;
	if(x==n)
	{
		if(bs%k==0)
		{
			int gl=mx+(k-(mx%k))%k;
			if(gl+bs<ans)
			{
				ans=gl+bs;
			}
		}
		return ;
	}
	for(int i=head[x];~i;i=edge[i].nxt)
	{
		int y=edge[i].to;
		if(!bj[y])
		{
			bj[y]=1;
			get(y,max(mx,edge[i].w),bs+1);
			bj[y]=0;
		}
	}
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	memset(head,-1,sizeof(head));
	int m;
	scanf("%d%d%d",&n,&m,&k);
	int u,v,a;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d%d",&u,&v,&a);
		add(u,v,a);
	}
	bj[1]=1;
	get(1,-1,0);
	bj[1]=0;
	if(ans!=2e9)
	printf("%d",ans);
	else
	printf("-1");
	return 0;
}
