#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n;
	scanf("%d",&n);
	int wei,time=0,bz=1;
	while(1)
	{
		if(n==0)
		break;
		time++;
		if((n-1)%3==0&&bz)
		{
			bz=0;
			wei=time;
		}
		n=n-1-(n-1)/3;
	}
	printf("%d %d",time,wei);
	return 0;
}
