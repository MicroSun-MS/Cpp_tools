#include<bits/stdc++.h>
using namespace std;
int cnt=0;
int get(int a,int b)
{
	int r=a%b;
	while(r!=0)
	{
		a=b;
		b=r;
		r=a%b; 
	}
	return b;
}
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe,out","w",stdout);
	int t,m;
	scanf("%d%d",&t,&m);
	int a,b,c;
	for(int o=1;o<=t;o++)
	{
		scanf("%d%d%d",&a,&b,&c);
		int dt=b*b-4*a*c;
		if(dt<0)
		{
			printf("NO\n");
			continue;
		}
		
		int gg=sqrt(dt);
		if(gg*gg==dt)
		{
			int g1,g2;
			if(a<0)
			g1=-b-gg,g2=2*a;
			if(a>0)
			g1=-b+gg,g2=2*a;
			int gd=get(abs(g1),abs(g2));
			if(g1<0&&g2<0)
			g1=abs(g1),g2=abs(g2);
			g1=g1/gd,g2=g2/gd;
			if(abs(g1)%abs(g2)==0)
			{
				printf("%d\n",g1/g2);
			}
			else
			{
				printf("%d/%d\n",g1,g2);
			}
			continue;
		}
		int g1=-b,g2=2*a;
		int gd=get(abs(g1),abs(g2));
		if(g1<0&&g2<0)
		g1=abs(g1),g2=abs(g2);
		g1=g1/gd,g2=g2/gd;
		if(abs(g1)%abs(g2)==0)
		{
			if(g1/g2!=0)
			{
				printf("%d",g1/g2);
				printf("+");
			}
		}
		else
		{
			printf("%d/%d",g1,g2);
			printf("+");
		}
		int ctt=1;
		for(int i=1;i*i<=dt;i++)
		{
			if(dt%(i*i)==0)
			ctt=i;
		}
			g2=2*a;
			dt=dt/(ctt*ctt);
			int gg1=get(abs(ctt),abs(g2));
			ctt=ctt/gg1,g2=g2/gg1;
			if(ctt==1&&abs(g2)==1)
			{
				printf("sqrt(%d)\n",dt);
			}
			else if(ctt==1)
			{
				printf("sqrt(%d)/%d\n",dt,abs(g2));
			}
			else if(abs(g2)==1)
			{
				printf("%d*sqrt(%d)\n",ctt,dt);
			}
			else
			{
				printf("%d*sqrt(%d)/%d\n",ctt,dt,abs(g2));
			}
	}
	return 0;
}
