#include<bits/stdc++.h>
using namespace std;
int v[100101],a[100101];
long long gl[100101];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,d;
	scanf("%d%d",&n,&d);
	for(int i=1;i<n;i++)
	{
		scanf("%d",&v[i]);
		gl[i+1]=v[i]+gl[i];
	}
	int minn=2e9,wei;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		if(a[i]<minn)
		{
			minn=a[i];
			wei=i;
		}
	}
	int i=0;
	long long sum=0,ans=0;
	while(1)
	{
		i++;
		if(i==n)
		break;
		if(ans>gl[n])
		break;
		int x=i;
		while(a[i]<=a[x+1]&&x+1<n)
		{
			x++;
		}
		long long ned=gl[x+1]-ans;
		if(ned<0)
		ned=0;
		if(ned%d==0)
		{
			sum=sum+(ned/d)*a[i];
			ans=ans+ned;
		}
		else
		{
			sum=sum+(ned/d+1)*a[i];
			ans=ans+(ned/d+1)*d;
		}
		i=x;
	}
	printf("%lld",sum);
	return 0;
}
