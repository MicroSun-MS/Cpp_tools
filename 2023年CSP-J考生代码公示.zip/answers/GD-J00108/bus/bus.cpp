#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;i++){
		int u,v,a;
		scanf("%d%d%d",&u,&v,&a);
	}
	printf("-1");
	return 0;
} 
