#include<bits/stdc++.h>
using namespace std;
int n,d,mr=1,tmp=0,t;
long long v[100000+10],a[100000+10],V[100000+10];
long long ans=0;
bool flag=1;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&d);
	for(int i=1;i<=n-1;i++){
		scanf("%lld",&v[i]);
		V[i]=V[i-1]+v[i];
	}
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	while(mr!=n){
		t=tmp;
		int l=mr;
		bool flag=0;
		for(int i=l+1;i<=n;i++){
			if(a[i]<a[l]){
				flag=1;mr=i;break;
			}
		}
		if(flag==0){
			mr=n;
		}
		t+=V[mr-1]-V[l-1];
		tmp=d*ceil(t/d)-(V[mr-1]-V[l-1]);
		if(t%d==0){
			ans+=t/d*a[l];
		}
		if(t%d!=0){
			ans+=(t/d+1)*a[l];
		}
	}printf("%lld",ans);
	return 0;
}
