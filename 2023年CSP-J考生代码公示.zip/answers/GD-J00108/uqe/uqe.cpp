#include<bits/stdc++.h>
using namespace std;
int t,m;
void Tong(int &a,int &b){
	int gcd=__gcd(abs(a),abs(b));
	a/=gcd,b/=gcd;
	if(a<0 && b<0){a*=-1,b*=-1;}
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&t,&m);
	for(int i=1;i<=t;i++){
		int a,b,c;
		scanf("%d%d%d",&a,&b,&c);
		long long delta=1ll*b*b-1ll*4*a*c;
		if(delta<0){
			puts("NO");
		}
		if(delta==0){
			int B=-b,A=2*a;
			Tong(A,B);
			if(B%A==0){printf("%d\n",B/A);}
			else{printf("%d/%d\n",B,A);}
		}
		if(delta>0){
			int x1,x2;
			x1=(-b+sqrt(delta))/(2*a);
			x2=(-b-sqrt(delta))/(2*a);
			printf("%d\n",max(x1,x2));
		}
	}
	return 0;
}
