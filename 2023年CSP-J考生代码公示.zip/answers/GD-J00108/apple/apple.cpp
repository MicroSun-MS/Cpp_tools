#include<bits/stdc++.h>
using namespace std;
int n;
bool book[1010];
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);
	int cnt=1,tmp=1,ndays,total;
	bool flag=1;
	while(flag){
		cnt=1;
		flag=0;
		for(int i=1;i<=n;i++){
			if(book[i]==0 && cnt%3==1){
				if(i==n){
					ndays=tmp;
				}
				book[i]=1;
				flag=1;cnt++;continue;
			}
			if(book[i]==0){cnt++;}
		}
		if(flag==0){
			total=tmp-1;
		}
		tmp++;
	}printf("%d %d",total,ndays);

	return 0;
}
