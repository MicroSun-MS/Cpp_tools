#include <bits/stdc++.h>
using namespace std;
#define int long long
int v[100005],a[100005];
vector<int> vec;
signed main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,d;
	scanf("%lld%lld",&n,&d);
	for(int i=2;i<=n;i++) scanf("%lld",v+i);
	for(int i=2;i<=n;i++){
		v[i]+=v[i-1];
	}
	for(int i=1;i<=n;i++) scanf("%lld",a+i);
	int last=1;
	vec.push_back(1);
	for(int i=2;i<n;i++){
		if(a[i]<a[last]){
			vec.push_back(i);
			last=i;
		}
	} 
	vec.push_back(n);
	int ans=0,sum=0;
	for(int i=1;i<vec.size();i++){ 
		int tmp=v[vec[i]]-v[vec[i-1]];
		if(tmp<=sum){
			sum-=tmp;
		}else{
			ans+=(tmp-sum+d-1)/d*a[vec[i-1]];
			sum+=(tmp-sum+d-1)/d*d-tmp;
		}
	}
	printf("%d",ans);
 	return 0;
}
