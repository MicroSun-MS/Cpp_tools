#include <bits/stdc++.h>
using namespace std;
int sq[10020];
int gcd(int a,int b){
	if(b==0) return a;
	return gcd(b,a%b);
}
void out(int a,int b){
	int g=gcd(a,b); 
	a/=g;b/=g;
	if(b<0){
		b=-b;
		a=-a;
	}
	if(b==1) printf("%d",a);
	else{
		printf("%d/%d",a,b);
	}
	return;
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	for(int i=1;i<=5005;i++) sq[i]=i*i;
	int t,m,a,b,c;
	scanf("%d%d",&t,&m);
	while(t--){
		scanf("%d%d%d",&a,&b,&c);
		int d=b*b-4*a*c;
		if(d<0){
			printf("NO\n");
			continue;
		}
		int id=lower_bound(sq,sq+5005,d)-sq;
		if(id*id==d){
			d=id;
			if(a<0) d=-d;
			out(-b+d,2*a);
			printf("\n");
		}else{
			if(b!=0){
				out(-b,2*a);
				printf("+");	
			}
			int q;
			if(a<0) q=-1; 
			else q=1;
			for(int i=5005;i>=2;i--){
				if(d%sq[i]==0){
					q*=i;d/=sq[i];
				}
			}
			int g=gcd(2*a,q);
			q/=g;a=2*a/g;
			if(a<0){
				a=-a;q=-q;
			}
			if(q==a) printf("sqrt(%d)\n",d);
			else if(a==1) printf("%d*sqrt(%d)\n",q,d);
			else if(q==1) printf("sqrt(%d)/%d\n",d,a);
			else printf("%d*sqrt(%d)/%d\n",q,d,a);			
		}
	} 
	return 0;
}
