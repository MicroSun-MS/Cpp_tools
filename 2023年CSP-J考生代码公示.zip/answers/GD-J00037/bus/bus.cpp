#include <bits/stdc++.h>
using namespace std;
int cnt=1,head[10005],n,m,k;
struct node{
	int to,next,w;
}e[20005];
void add(int x,int y,int z){
	e[cnt].next=head[x];
	e[cnt].to=y;
	e[cnt].w=z;
	head[x]=cnt++;
}
struct Node{
	int id,time,sz;
	bool operator < (const Node &rhs) const{
		return sz>rhs.sz;
	}
};
int dp[10005][105];
bool vis[10005][105];
int mn(int i,int t){
	if(t<e[i].w%k) return k*(e[i].w/k+1)+t;
	else return k*(e[i].w/k)+t;
}
void djst(){
	priority_queue<Node> q;
	dp[1][0]=0;
	q.push({1,0,0});
	while(!q.empty()){
		Node now=q.top();
		q.pop();
		//cout<<now.id<<" "<<now.time<<" "<<now.sz<<endl; 
		if(now.sz!=dp[now.id][now.time]) continue;
		int t=(now.time+1)%k;
		for(int i=head[now.id];i;i=e[i].next){
			int v=e[i].to;
			if(dp[v][t]!=mn(i,t)&&dp[v][t]>dp[now.id][now.time]+1){
				dp[v][t]=dp[now.id][now.time]+1;
				if(dp[v][t]<e[i].w) dp[v][t]=mn(i,t);
				q.push({v,t,dp[v][t]});
			}
		}
	}
	return;
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	memset(dp,0x3f,sizeof(dp));
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;i++){
		int u,v,w;
		scanf("%d%d%d",&u,&v,&w);
		add(u,v,w); 
	}
	djst();
	if(dp[n][0]==0x3f3f3f3f) printf("-1\n");
	else printf("%d\n",dp[n][0]); 
	return 0;
}
