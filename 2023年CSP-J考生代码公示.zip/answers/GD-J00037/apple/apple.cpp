#include <bits/stdc++.h>
using namespace std;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n;
	scanf("%d",&n);
	int sum=0,id=0;
	while(n!=0){
		sum++;
		if(n%3==1&&id==0) id=sum;
		n-=((n+2)/3); 
	}
	printf("%d %d\n",sum,id);
	return 0;
}
