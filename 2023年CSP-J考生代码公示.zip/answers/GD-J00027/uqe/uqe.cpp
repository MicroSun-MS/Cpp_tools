#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int T,m,a,b,c,sum[1000010];
bool prime[1000010];
double max(double t1,double t2)
{
	if(t1>t2) return t1;
	else return t2;
}
int gcd(int t1,int t2)
{
	if(t1<t2)
	{
		int t=t1;
		t1=t2;
		t2=t;
	}
	if(t1==0||t2==0) return 1;
	if(t1%t2==0) return t2;
	else return gcd(t2,t1%t2);
}
int main()
{
	//RP++!
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	memset(prime,1,sizeof(prime));
	prime[1]=0;
	for(int i=2;i<=500000;i++)
		if(prime[i])
			for(int j=2;i*j<=1000000;j++)
				prime[i*j]=0;
	scanf("%d%d",&T,&m);
	while(T--)
	{
		scanf("%d%d%d",&a,&b,&c);
		int d=b*b-4*a*c;
		if(d<0) printf("NO\n");
		else
		{
			memset(sum,0,sizeof(sum));
			int maxd=d;
			double q1=-b;
			int tmp=0,r=1;
			for(int i=2;i<=maxd;i++)
				if(prime[i])
				{
					while(d%i==0)
					{
						d/=i;
						sum[i]++;
					}
					if(sum[i]%2!=0) r*=i;
					if(sum[i]>0)
					{
						if(tmp==0) tmp=1;
						tmp*=pow(i,sum[i]/2);
					}
					if(d==1) break;
				}
			if(maxd==1)
				q1+=(a<0?-1:1)*d;
			tmp*=(a<0?-1:1);
			if(r==1)
			{
				int p=q1+tmp,q=2.0*a;
				int tmp2=gcd(abs(p),abs(q));
				p/=tmp2,q/=tmp2;
				if(q<0) p=-p,q=-q;
				if(q==1) printf("%d\n",p);
				else if(p==0) printf("0\n");
				else printf("%d/%d\n",p,q);
			}
			else
			{
				int p_1=q1,q_1=2.0*a;
				int tmp2=gcd(abs(p_1),abs(q_1));
				p_1/=tmp2,q_1/=tmp2;
				if(q_1<0) p_1=-p_1,q_1=-q_1;
				if(p_1!=0)
				{
					if(q_1==1) printf("%d",p_1);
					else printf("%d/%d",p_1,q_1);
					printf("+");
				}
				double q2=tmp/(2.0*a);
				if(tmp==(int)(2.0*a)) printf("sqrt(%d)\n",r);
				else if(tmp%(2*a)==0) printf("%d*sqrt(%d)\n",(int)q2,r);
				else
				{
					double q_3=1.0/q2;
					if(fabs(q_3-(int)(q_3))<0.01) printf("sqrt(%d)/%d\n",r,(int)(q_3));
					else
					{
						int p_2=tmp,q_2=2*a;
						int tmp3=gcd(abs(p_2),abs(q_2));
						p_2/=tmp3,q_2/=tmp3;
						if(q_2<0) p_2=-p_2,q_2=-q_2;
						if(p_2!=1) printf("%d*",p_2);
						printf("sqrt(%d)",r);
						if(q_2!=1) printf("/%d\n",q_2);
						//printf("%d*sqrt(%d)/%d\n",p_2,r,q_2);
					}
				}
				continue;
			}
		}
	}
}