#include<cstdio>
#include<cmath>
using namespace std;
int main()
{
	//RP++!
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n,ans1=0,ans2=0;
	scanf("%d",&n);
	while(n>0)
	{
		ans1++;
		if(n%3==1&&ans2==0) ans2=ans1;
		n=n-ceil(n/3.0);
	}
	printf("%d %d\n",ans1,ans2);
}