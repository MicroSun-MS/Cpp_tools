#include<cstdio>
#include<cstring>
#include<cmath>
using namespace std;
int n,d,v[100010],a[100010],f[1010][1010],ans=0x3f3f3f3f;
int min(int t1,int t2)
{
	if(t1<t2) return t1;
	else return t2;
}
void work(int now,double gas,int cost)
{
	if(now==n)
	{
		ans=min(ans,cost);
		return;
	}
	for(int i=1;i<=ceil(v[n]/(double)(d));i++)
		for(int j=now+1;j<=n;j++)
			if((gas+i)*d>=v[j]-v[now])
				work(j,gas+i-(v[j]-v[now])/(double)(d),cost+a[now]*i);
}
int main()
{
	//RP++!
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&d);
	for(int i=2;i<=n;i++) scanf("%d",&v[i]),v[i]+=v[i-1];
	for(int i=1;i<=n;i++) scanf("%d",&a[i]);
	if(n>1000) printf("%d\n",ceil(v[n]/(double)(d))*a[1]);
	else
	{
		work(1,0,0);
		printf("%d\n",ans);
	}
}