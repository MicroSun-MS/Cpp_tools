#include<cstdio>
#include<vector>
#include<cstring>
using namespace std;
struct edge
{
	int to,v;
};
vector<edge>graph[10010];
int n,m,k;
namespace task1_5
{
	int ans=0x3f3f3f3f;
	void work(int now,int sum)
	{
		if(now==n)
		{
			if(sum%k==0) ans=min(ans,sum);
			return;
		}
		for(auto e:graph[now])
			if(sum>=e.v)
				work(e.to,sum+1);
	}
}
namespace task6_7
{
	int dis[10010],d[1000010];
	bool bz[10010];
	int spfa()
	{
		memset(dis,0x3f,sizeof(dis));
		dis[1]=0;
		int head=0,tail=1;
		d[1]=1;
		while(head<tail)
		{
			head++;
			int from=d[head];
			bz[from]=0;
			for(auto e:graph[from])
			{
				if(dis[e.to]>dis[from]+1)
				{
					dis[e.to]=dis[from]+1;
					if(bz[e.to]==0)
					{
						bz[e.to]=1;
						d[++tail]=e.to;
					}
				}
			}
		}
		return dis[n];
	}
}
int main()
{
	//RP++!
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;i++)
	{
		int from,to,v;
		scanf("%d%d%d",&from,&to,&v);
		graph[from].push_back(edge{to,v});
	}
	if(n<=10)
	{
		for(int i=0;i<=n;i++)
			task1_5::work(1,i*k);
		printf("%d\n",task1_5::ans==0x3f3f3f3f?-1:task1_5::ans);
	}
	else
	{
		int ans=task6_7::spfa();
		printf("%d\n",ans==0x3f3f3f3f?-1:ans);
	}
}