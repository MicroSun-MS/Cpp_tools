#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<math.h>
const int N=1e5+10;
const int M=1e3+10;
const int INF=0x3f3f3f3f;
using namespace std;
int n,m;
int ans=0;
int a[N],b[N],f[N];
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>m;
	int minn=INF,sum=0;
	bool flag=1;
	for(int i=1;i<n;i++){
		cin>>a[i];
		sum+=a[i];
		if(a[i]%m)flag=0;
	}
	for(int i=1;i<=n;i++){
		cin>>b[i];
		minn=min(minn,b[i]);
	}
	if(minn=b[1]){
		int x=(sum+m-1)/sum;
		cout<<x*b[1];
		return 0;
	}
	int ans=0;
	if(flag){
		for(int i=1;i<n;i++)a[i]/=m;
		for(int mi=INF,i=1;i<n;i++){
			mi=min(mi,b[i]);
			ans+=a[i]*mi;
		}
		cout<<ans;
		return 0;
	}
	return 0;
}
