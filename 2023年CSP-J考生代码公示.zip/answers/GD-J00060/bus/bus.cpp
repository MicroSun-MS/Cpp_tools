#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<math.h>
const int N=1e5+10;
const int M=5e6+10;
const int INF=0x3f3f3f3f;
using namespace std;
int n,m,k,maxx=0,minn=INF,T;
int head[N],to[N],ne[N],w[N],id;
void add(int x,int y,int z){
	to[++id]=y;
	w[id]=z;
	ne[id]=head[x];
	head[x]=id;
}
bool vis[N];
void dfs(int x,int t){
	if(vis[x])return;
	if(x==n){
		int num=(t+k-1)/k;
		minn=min(minn,num*k);
	}
	vis[x]=1;
	for(int i=head[x];i;i=ne[i]){
		int y=to[i],z=w[i];
		if(t>=w[i])dfs(y,t+1);
	}
	vis[x]=0;
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m>>k;
	for(int x,y,z,i=1;i<=m;i++){
		cin>>x>>y>>z;
		add(x,y,z);
		maxx=max(maxx,z);
	}
	//int minn=INF;
	for(int i=0;i<=maxx;i++){
		dfs(1,i);
	}
	cout<<minn;
	return 0;
}
