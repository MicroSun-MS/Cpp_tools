#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<math.h>
const int N=1e5+10;
const int M=5e6+10;
const int INF=0x3f3f3f3f;
using namespace std;
int n,m,T;
int a,b,c;
int sq[M][2];
int gcd(int x,int y){
	//cout<<"gcd"<<x<<' '<<y<<'\n';
	if(x%y==0)return y;
	return gcd(y,x%y);
}
int num[M];
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int g;
	for(int i=1;i<=1000;i++){
		for(int j=i*i;j<M;j+=i*i){
			sq[j][0]=i;
			sq[j][1]=j/i/i;
		}
	}
	/*
	5 5
	2 32 0

	*/
	//cout<<cout<<"AAA"<<gcd(378,2*81)<<"\n";
	//cout<<"AAA"<<sq[1024][0]<<' '<<sq[1024][1]<<"\n";
	cin>>T>>m;
	while(T--){
		cin>>a>>b>>c;
		if(a<0){
			a=-a;
			b=-b;
			c=-c;
		}
		int d=b*b-4*a*c;
		//cout<<"-A"<<d<<'\n';
		if(d<0){
			cout<<"NO\n";
			continue;
		}
		int x=-b,y=2*a;
		num[1]=1;
		if(x<0){
			//cout<<'-';
			num[1]=-1;
			x=-x;
		}
		//cout<<"AA";
		g=gcd(x,y);
		//cout<<"!"<<x<<','<<y<<"!";
		x/=g;
		y/=g;
		//cout<<"3A3";
		//cout<<x;
		num[2]=x;
		//if(y>1)cout<<'/'<<y;
		num[3]=y;
		if(num[2]==0)num[3]=1;
		//cout<<"1A1";
		if(d==0){
			cout<<num[1]*num[2];
			if(num[2]&&num[3]>1)cout<<"/"<<num[3];
			cout<<"\n";
			continue;
		}
		//cout<<"BB";
		if(d>0){
			//cout<<'+';
			num[4]=1;
			int x1=sq[d][0],x2=sq[d][1];
			x=2*a;
			g=gcd(x1,x);
			x/=g;
			x1/=g;
			
		//cout<<"CC";
			//cout<<x1<<'*'<<"sqrt("<<x2<<")";
			num[5]=x1;
			num[6]=x2;
			//if(x>1)cout<<"/"<<x;
			num[7]=x;
		}
		if(num[6]==1){
			d=0;
			g=gcd(num[3],num[7]);
		//cout<<"DD";
			num[2]*=num[7]/g;
			num[5]*=num[3]/g;
			
			num[3]*=num[7]/g;
			
		//cout<<"EE";
			num[2]=num[1]*num[2]+num[5];
			
			
			num[1]=1;
			if(num[2]<0){
				num[1]=-1;
				num[2]=-num[2];
			}
			
			//cout<<"AAA"<<num[2]<<' '<<num[3]<<"\n";
			
			if(num[2]){
				g=gcd(num[2],num[3]);
				//cout<<"C"<<g<<"\n";
				num[2]/=g;
				num[3]/=g;
			}
			//cout<<"BBB"<<num[2]<<' '<<num[3]<<"\n";
		//cout<<"FF";
			
		}
		if(num[2]){
			cout<<num[1]*num[2];
			if(num[3]>1)cout<<"/"<<num[3];
		}
		if(d){
			if(num[2])cout<<"+";
			if(num[5]>1)cout<<num[5]<<"*";
			cout<<"sqrt("<<num[6]<<")";
			if(num[7]>1)cout<<"/"<<num[7];
		}
		if(num[2]==0&&d==0){
			cout<<0;
		}
		
		
		cout<<'\n';
	}
	return 0;
}
