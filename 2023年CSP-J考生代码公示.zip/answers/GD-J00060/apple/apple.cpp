#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
#include<math.h>
const int N=1e5+10;
const int M=1e3+10;
const int INF=0x3f3f3f3f;
using namespace std;
int n;
int ans=0;
int a[N];
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	int cnt=0;
	while(n){
		cnt++;
		if(n%3==1&&ans==0){
			ans=cnt;
		}
		int x=(n+2)/3;
		n=n-x;
		//cout<<n<<'\n';
	}
	cout<<cnt<<' '<<ans;
	/*int cnt=0;
	int t=1;
	while(cnt<n){
		for(int o=0,i=1;i<=n;i++){
			if(a[i])continue;
			if(o==0)a[i]=t,++cnt;
			o++;
			o%=3;
		}
		t++;
	}
	for(int i=1;i<=n;i++){
		cout<<i<<' '<<a[i]<<'\n';
	}*/
	return 0;
}
