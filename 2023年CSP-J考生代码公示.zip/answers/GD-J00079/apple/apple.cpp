#include<bits/stdc++.h>
using namespace std;
long long n;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin >> n;
	int m=n,num=0,ans=0,i=0;
	while(m){
		num+=1;
		if(!i){
			if((m-1)%3==0){
				ans=num;
				i=1;
			}
		}
		m=m-(m-1)/3-1;
	}
	cout << num << " " << ans;
} 
