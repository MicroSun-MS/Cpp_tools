#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,k;
	cin >> n >> m >> k;
	int a[n][3];
	for(int i=0;i<m;i+=1)for(int j=0;j<3;j+=1)cin >> a[i][j];
	cout << a[0][1]*3;
}
