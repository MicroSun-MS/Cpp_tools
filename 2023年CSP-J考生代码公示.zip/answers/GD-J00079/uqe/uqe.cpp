#include<bits/stdc++.h>
using namespace std;
int n,t;
int Gcd(int *a,int *b){
	if((*a)*(*b)>=0){
		*a=abs(*a);
		*b=abs(*b);
	}else{
		*a=-1*abs(*a);
		*b=abs(*b);
	}
	for(int i=2;i<=min(abs(*a),abs(*b));i+=1){
		while(*a%i==0&&*b%i==0){
			*a/=i;
			*b/=i;
		}
	}
	return 0;
}
int turn(int q){
	for(int i=2;i<q;i+=1){
		while(q%(i*i)==0){
			q/=(i*i);
		}
	}
	return q;
}
int main(){
//	freopen("uqe.in","r",stdin);
//	freopen("uqe.out","w",stdout);
	cin >> n >> t;
	int x[n][4];
	for(int i=0;i<n;i+=1){
		cin >> x[i][1] >> x[i][2] >> x[i][3];
	}
	for(int i=0;i<n;i+=1){
		int a=x[i][1],b=x[i][2],c=x[i][3];
		int d=b*b-4*a*c;
		if(d<0){
			cout << "NO";
			if(i!=n-1)cout << endl; 
		}else{
			int x1=(sqrt(d)-b)/(2*a),x2=((-1)*sqrt(d)-b)/(2*a);
			if(x1>=x2){
				int p=sqrt(d);
				if(p*p==d){
					int z=sqrt(d)-b,m=2*a;
					Gcd(&z,&m);
					if(m==1||m==-1){
						cout << z;
					}else if(z*m>=0){
						cout << abs(z) << "/" << abs(m);
					}else{
						cout << -abs(z) << "/" << abs(m);
					}
				}else{
					int z1=turn(d),z2=sqrt(d/z2),z3=-b,m1=2*a,m2=2*a;
					Gcd(&z3,&m1);
					if(abs(m1)==1){
						cout << z3 << "+";
					}else if(z3*m1>=0){
						cout << abs(z3) << "/" << abs(m1) << "+";
					}else{
						cout << -1*abs(z3) << "/" << abs(m1) << "+";
					}
					if(d==z1){
						cout << "sqrt(" << z1 << ")" << "/" << m2;
					}else{
						Gcd(&z2,&m2);
						cout << z2 << "*sqrt(" << z1 << ")" << "/" << m2;
					}
				}
			}else{
				int p=sqrt(d);
				if(p*p==d){
					int z=-1*(sqrt(d))-b,m=2*a;
					Gcd(&z,&m);
					if(m==1||m==-1){
						cout << z;
					}else if(z*m>=0){
						cout << abs(z) << "/" << abs(m);
					}else{
						cout << -abs(z) << "/" << abs(m);
					}
				}else{
					int z1=turn(d),z2=-sqrt(d/z2),z3=-b,m1=2*a,m2=2*a;
					Gcd(&z3,&m1);
					if(abs(m1)==1){
						cout << z3 << "+";
					}else if(z3*m1>=0){
						cout << abs(z3) << "/" << abs(m1);
					}else{
						cout << -1*abs(z3) << "/" << abs(m1);
					}
					if(d==z1){
						cout << "sqrt(" << z1 << ")" << "/" << m2;
					}else{
						if((m2*z2)>=0){ 
							cout << "-";						
						}else{
							cout << "+";
							m2*=(-1);
						}
						Gcd(&z2,&m2);
						cout << z2 << "*sqrt(" << z1 << ")" << "/" << m2;
					}
				}
			}
		}
	}
} 
