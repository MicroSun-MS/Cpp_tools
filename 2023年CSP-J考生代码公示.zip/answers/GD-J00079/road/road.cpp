#include<bits/stdc++.h>
using namespace std;
int n,k;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin >> n >> k;
	int a[n+1],b[n+1];
	long long ans[n+1][2];
	b[0]=0;
	b[1]=0;
	for(int i=2;i<=n;i+=1){
		cin >> b[i];
		b[i]+=b[i-1];
	}
	for(int i=1;i<=n;i+=1){
		cin >> a[i];
	}
	for(int i=1;i<=n;i+=1){
		ans[i][0]=10000000000000000;
		ans[i][1]=0; 
	}
	ans[1][0]=0;
	for(int i=1;i<=n;i+=1){
		for(int j=i+1;j<=n;j+=1){
			int c=(b[j]-b[i]-ans[i][1]+k-1)/k;
			int money=c*a[i];
			if(money+ans[i][0]<ans[j][0]){
				ans[j][0]=money+ans[i][0];
				ans[j][1]=ans[i][1]+c*k-b[j]+b[i];
			}else if(money==ans[j][0]){
				ans[j][1]=max(ans[j][1],ans[i][1]+c*k-b[j]+b[i]);
			}
		}		
	}
	cout << ans[n][0];
}
