#include<iostream>
using namespace std;
const int MAX=100000;
int n,o;
double d,money;
struct use{int v,a;};
use oil[MAX];
int use2(int x,int y);
void use1(int x)
{
	float j;
	for(int i=x+1;i<n;i++)
	{
		if(oil[x].a>oil[i].a)
		{
			j=use2(x,i)/d;
			o=0;
			if(use2(x,i)%int(d)!=0)j+=1,o=1;
			money+=oil[x].a*(j-o);x=i;
		}
	}
	if(money==0)money=oil[0].a*j;
	cout<<int(money);
}
int use2(int x,int y)
{
	double s=0;
	for(int i=x;i<y;i++)s+=oil[i].v;
	return s;
}
int main()
{
	cin>>n>>d;
	for(int i=0;i<n-1;i++)cin>>oil[i].v;
	for(int i=0;i<n;i++)cin>>oil[i].a;
	use1(0);
	return 0;
}
