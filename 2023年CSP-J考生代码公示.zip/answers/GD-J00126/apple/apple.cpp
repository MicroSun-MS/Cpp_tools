#include<iostream>
using namespace std;
int n,m=0,ans,apple[1000];
void use1(int x)
{
	while(x>0)
	{
		x-=(x-1)/3+1;
		m++;
	}
	cout<<m<<" ";
}
int use3()
{
	for(int i=0;i<n;i++)if(apple[i]!=0)return i;
}
void use2(int x)
{
	int j=0;
	for(int i=0;i<m;i++)
	{
		while(j<n)
		{
			int num=0;
			apple[j]=0;j+=1;
			while(apple[j]==0&&j<n-1)
			{
				j+=1,num++;
				if(num==3)apple[j]=0,num=0;
			}
			if(j==n-1)cout<<i+1;
		}
		j=use3();
	}
}

int main()
{
	cin>>n;
	for(int i=0;i<n;i++)apple[i]=i+1;
	use1(n);
	use2(m);
	return 0;
}

