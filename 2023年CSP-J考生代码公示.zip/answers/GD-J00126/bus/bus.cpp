#include<iostream>
using namespace std;
struct use
{
	int u,v,a;
};
int n,m,k;
int main()
{
	cin>>n>>m>>k;
	use bus[m];
	for(int i=0;i<m;i++)cin>>bus[i].u>>bus[i].v>>bus[i].a;
	
	return 0;
}
