#include<iostream>
#include<cmath>
using namespace std;
int T,M,a,b,c;
int use(int x,int y,int z){return ((-1)*b+sqrt(b*b-4*a*c))/(2*a);}
int main()
{
    cin>>T>>M;
    int num[T];
    for(int i=0;i<T;i++)
    {
    	cin>>a>>b>>c;
		if(b*b-4*a*c<0)num[i]=0;
		else num[i]=use(a,b,c);
	}
	for(int i=0;i<T;i++)
	{
		if(num[i]==0)cout<<"NO"<<endl;
		else cout<<num[i]<<endl;
	}
	return 0;
}
