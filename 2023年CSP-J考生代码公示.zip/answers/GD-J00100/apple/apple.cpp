#include <iostream>
#include <cstdio>
using namespace std;

int main ()
{
	freopen ("apple.in" , "r" , stdin);
	freopen ("apple.out" , "w" , stdout);
	int n;
	scanf ("%d" , &n);
	int day = 0 , pos = 0;
	bool ans = 0;
	while (n)
	{
		day ++;
		if (!ans)
			pos ++;
		if ((n - 1) % 3 == 0)
			ans = 1;
		n -= (n / 3) + (bool)(n % 3);
	}
	printf ("%d %d" , day , pos);
	return 0;
}
