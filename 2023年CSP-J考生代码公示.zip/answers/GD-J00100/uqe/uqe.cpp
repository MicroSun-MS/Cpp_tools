#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;

int gcd (int x , int y)
{
	if (y == 0)
		return x;
	return gcd (y , x % y);
}

int Sqrt (int x)
{
	int l = 0 , r = 10000 , mid;
	while (l <= r)
	{
		mid = l + r + 1 >> 1;
		if (mid * mid > x)
			r = mid - 1;
		else if (mid * mid < x)
			l = mid + 1;
		else
			return mid;
	}
	return r;
}

void work (int a , int b , int c)
{
	int v = b * b - 4 * a * c;
	if (v < 0)
	{
		printf ("NO\n");
		return ;
	}
	if (c == 0)
	{
		int g = gcd (abs (b) , abs (a));
		double ans = -b / a;
		if (ans <= 0)
			printf ("0\n");
		else if (abs (b) % abs (a) == 0)
			printf ("%d\n" , -b / a);
		else
			printf ("%d/%d\n" , -b / g , a / g);
		return ;
	}
	if (b != 0)
	{
		int s = Sqrt (v);
		if (s * s == v)
		{
			double ans1 = 1.0 * (-b + s) / 2 / a , ans2 = 1.0 * (-b - s) / 2 / a , ans;
			bool p = 0;
			if (ans1 > ans2)
				ans = ans1;
			else
				ans = ans2 , p = 1;
			if (ans != (1.0 * (int)(ans)))
			{
				int g = gcd (abs (-b - s) , abs (2 * a));
				if (p)
					printf ("%d/%d\n" , (-b - s) / g , 2 * a / g);
				else
					printf ("%d/%d\n" , (-b + s) / g , 2 * a / g);
			}
			else
			{
				printf ("%d\n" , (int)(ans));
			}
		}
		return ;
	}
	if (abs (c) % abs (a) == 0)
	{
		int num = -c / a;
		int s = Sqrt (num);
		if (s * s == num)
		{
			printf ("%d\n" , s);
		}
		else
		{
			printf ("sqrt(%d)\n" , num);
		}
	}
	else
	{
		int x = Sqrt (-c) , y = Sqrt (a);
		if (x * x != -c || y * y != a)
		{
			printf ("NO\n");
			return ;
		}
		int g = gcd (x , y);
		printf ("%d/%d\n" , x / g , y / g);
	}
}

int main ()
{
	freopen ("uqe.in" , "r" , stdin);
	freopen ("uqe.out" , "w" , stdout);
	int t , m;
	scanf ("%d%d" , &t , &m);
	while (t --)
	{
		int a , b , c;
		scanf ("%d%d%d" , &a , &b , &c);
		work (a , b , c);
	}
	return 0;
}
