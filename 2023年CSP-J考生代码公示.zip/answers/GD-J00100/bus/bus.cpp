#include <iostream>
#include <cstdio>
#include <vector>
#include <queue>
using namespace std;
int d[10005];
vector <int> g[10005];
void bfs (int su)
{
	d[su] = 1;
	queue <int> q;
	q.push (su);
	while (!q.empty ())
	{
		int now = q.front ();
		q.pop ();
		for (int i = 0;i < g[now].size ();i ++)
		{
			int v = g[now][i];
			if (d[v] == 0)
			{
				d[v] = d[now] + 1;
				q.push (v);
			}
		}
	}
}

int main ()
{
	freopen ("bus.in" , "r" , stdin);
	freopen ("bus.out" , "w" , stdout);
	int n , m , k;
	scanf ("%d%d%d" , &n , &m , &k);
	bool f = 0;
	for (int i = 1;i <= m;i ++)
	{
		int x , y , a;
		scanf ("%d%d%d" , &x , &y , &a);
		if (a != 0)
			f = 1;
		g[x].push_back (y);
	}
	if (k == 1 && !f)
	{
		bfs (1);
		printf ("%d" , d[n] - 1);
	}
	else
	{
		printf ("-1");
	}
	return 0;
}
