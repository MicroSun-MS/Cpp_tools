#include <iostream>
#include <cstdio>
using namespace std;
long long n , d;
long long v , s[100005] , a[100005];

int main ()
{
	freopen ("road.in" , "r" , stdin);
	freopen ("road.out" , "w" , stdout);
	scanf ("%lld%lld" , &n , &d);
	for (long long i = 1;i < n;i ++)
	{
		scanf ("%lld" , &v);
		s[i + 1] = s[i] + v;
	}
	for (long long i = 1;i <= n;i ++)
	{
		scanf ("%lld" , a + i);
	}
	long long ans = 0;
	long long pos = 1;
	long double p = 0;
	for (long long i = 2;i <= n;i ++)
	{
		if (a[i] < a[pos] || i == n)
		{
			p = 1.0 * (s[i] - s[pos]) / (1.0 * d) - p;
			ans += ((long long)(p) + ((p - (long long)(p)) > 0.0)) * a[pos];
			p = 1.0 * ((long long)(p) + ((p - (long long)(p)) > 0.0)) - p;
			pos = i;
		}
	}
	printf ("%lld" , ans);
	return 0;
}
