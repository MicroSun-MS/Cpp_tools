#include<bits/stdc++.h>
using namespace std;
int n,t,sum,s=0,ans=1;
int main(){
	ios::sync_with_stdio;
	cin.tie(0),cout.tie(0);
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	t=n;
	while(t>0){
		if(t%3==1&&s==0) {
			sum=ans;
			s=1;
		}
		if(t%3==0) t-=(t/3);
		else t-=(t/3+1);
		ans++;
	}
	cout<<ans-1<<' '<<sum;
	return 0;
}

