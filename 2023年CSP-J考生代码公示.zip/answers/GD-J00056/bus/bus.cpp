#include<bits/stdc++.h>
using namespace std;
int n,m,k,x,y,z;
int main(){
	ios::sync_with_stdio;
	cin.tie(0),cout.tie(0);
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		cin>>x>>y>>z;
	}
	cout<<-1;
	return 0;
}

