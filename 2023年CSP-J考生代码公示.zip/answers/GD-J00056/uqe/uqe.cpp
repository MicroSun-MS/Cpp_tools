#include<bits/stdc++.h>
using namespace std;
int t,m,a,b,c,x,g,h,d,q1=1;
int check(int y,int z){
	y=abs(y);
	z=abs(z);
	if(y==0){
		return z;
	}
	if(z==0){
		return y;
	}
	int u=min(y,z),v=max(y,z);
	return check(u,v%u);
}
void bfs(int p,int q,int r){
	x=q*q-(4*p*r);
	g=check(2*a,b);
	q1=1;
	if(x<0) {
		cout<<"NO";
		return;
	}
	if(x==0){
		cout<<(-1)*b/g;
		if(2*a!=g) cout<<'/'<<(2*a/g);
		return;
	}
	for(int i=2;i*i<=x;i++){
		if(x%(i*i)==0){
			q1*=i;
			x/=(i*i);
		}
	}
	if(x==1){
		d=check(2*a,b+q1);
		cout<<((-1)*b+q1)/d;
		if(2*a!=d) cout<<'/'<<2*a/d;
		return;
	}
	if(b!=0){
		cout<<(-1)*b/g;
		if(2*a!=g) cout<<'/'<<(2*a/g);
		cout<<'+';
	}
	if(q1%(2*a)==0){
		q1/=(2*a);
		if(q1!=1) cout<<q1<<'*';
		cout<<"sqrt("<<x<<')';
	}else{
		h=check(q1,2*a);
		if(q1==h){
			cout<<"sqrt("<<x<<")/"<<2*a/h;
		}else{
			cout<<q1/h<<"*sqrt("<<x<<")/"<<2*a/h;
		}
	}
}
int main(){
	ios::sync_with_stdio;
	cin.tie(0),cout.tie(0);
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>t>>m;
	for(int i=1;i<=t;i++){
		cin>>a>>b>>c;
		bfs(a,b,c);
		if(i<t) cout<<'\n';
	}
	return 0;
}

