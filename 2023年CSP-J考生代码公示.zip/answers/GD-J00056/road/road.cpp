#include<bits/stdc++.h>
using namespace std;
int ans,i,j,n,d,t,x,a[100010],v[100010];
void dfs(int step){
	ans=0;
	if(step==n){
		return;
	}
	for(i=step;i<=n;i++){
		ans+=v[i];
		if(a[step]>a[i+1]){
			break;
		}
	}
	ans-=x;
	if(ans%d==0){
		t+=(ans/d*a[step]);
		x=0;
	}else {
		t+=((ans/d+1)*a[step]);
		x=d-ans%d;
	}
	dfs(i+1);
}
int main(){
	ios::sync_with_stdio;
	cin.tie(0),cout.tie(0);
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	a[n+1]=0;
	for(i=1;i<n;i++){
		cin>>v[i];
	}
	for(j=1;j<=n;j++){
		cin>>a[j];
	}
	dfs(1);
	cout<<t;
	return 0;
}

