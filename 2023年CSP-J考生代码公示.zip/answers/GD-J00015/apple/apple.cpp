#include<bits/stdc++.h>
using namespace std;
int upu(int b);
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int a,b;
	cin>>a;
	b=a;
	int ans1=0;
	int ans2;
	int afol=1;
	int qi=1;
	if((a-1)%3==0){
	    ans2=1;
		qi=0;
		afol=0;
	}
	while(b>0){
		if((b-1)%3 == 0&&qi==1){
		    qi=0;
			ans2=ans1+1;
		}
		int out=upu(b);
		b-=out;
		ans1++;
	} 
	cout<<ans1<<" "<<ans2;
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
int upu(int b){
	if(b%3==0){
		return b/3;
	}
	else return (b/3)+1;
}
