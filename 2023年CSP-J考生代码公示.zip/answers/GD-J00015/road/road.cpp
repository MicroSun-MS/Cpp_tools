#include<bits/stdc++.h>
using namespace std;
int rd[100200],pr[100200];
bool lea[100200];
int upu(int a,int b);//a/b����ȡ��; 
int tord=0,n,d;
int distance(int a,int b);
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int minp=1000000,minrd=-1;
	cin>>n>>d;
	for(int i=1;i<n;i++){
		cin>>rd[i];
		tord+=rd[i];
	}
	for(int i=1;i<=n;i++){
		cin>>pr[i];
		if(pr[i]<minp&&i<n){
			minp=pr[i];
			minrd=i;
		}
	}
	if(minrd==1){
		if(tord%d==0){
			cout<<tord/d*minp;
			fclose(stdin);
			fclose(stdout);
			return 0;
		}
		else{
			cout<<(tord/d+1)*minp;
			fclose(stdin);
			fclose(stdout);
			return 0;
		}
	}
	lea[minrd]=1;
	while(minrd!=1){
		int mint=1000000;
		int minrt=-1;
		for(int i=1;i<minrd;i++){
			if(pr[i]<mint){
			mint=pr[i];
			minrt=i;
			}
		}
		minrd=minrt;
		lea[minrd]=1;
	}
	int total=0,at,restdis=0;
	for(int i=1;i<n;i++){
		if(lea[i]==1){
			int j;
			for(int j=i+1;j<=n;j++){
				if(lea[j]==1||j==n){
					int tdis=distance(i,j);
					int tupu=upu((tdis-restdis),d);
					total += (tupu*pr[i]);
					restdis = tupu*d-tdis+restdis;
					//cout<<i<<" "<<j<<" "<<tdis<<" "<<tupu<<" "<<total<<" "<<restdis<<" "<<endl ;
					break;
				}	
			}
			
		}
	}
	//cout<<endl;
	cout<<total;
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
int upu(int a,int b){
	if(a%b==0)return a/b;
	else return a/b+1;
}

int distance(int a,int b){
	int ansd=0;
	for(int i=a;i<b;i++){
		ansd+=rd[i];
	}
	return ansd;
}

