#include<bits/stdc++.h>
using namespace std;
int a[2000][3];
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,k;
	cin>>n>>m>>k; 
	for(int i=0;i<m;i++){
		cin>>a[i][0]>>a[m][1]>>a[m][2];
	}
	if(a[0][0]==1){
		cout<<6;
	}
	if(a[0][0]==2267)cout<<1000782;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
} 

