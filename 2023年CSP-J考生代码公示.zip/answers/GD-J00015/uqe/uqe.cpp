#include<bits/stdc++.h>
using namespace std;
void solveb0(int a,int c);
void solve(int a,int b,int c);
int gcd(int a,int b);
int axa(int dt);
int axx(int dt);
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int t,m;
	cin>>t>>m;
	int a,b,c;
	for(int i=0;i<t;i++){
		cin>>a>>b>>c;
		if(b==0)solveb0(a,c);
		else solve(a,b,c);
		cout<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
void solveb0(int a,int c){
	if(a*c>0)cout<<"NO";
	int n;
	int m=-1*a*c;
	n=axa(m);
	m=axx(m);
	if(a<0)cout<<"-";
	if(n!=1)cout<<n<<"*";
	cout<<"sqrt("<<m<<")";
	if(a!=1)cout<<"/"<<a;
	return;
}
void solve(int a,int b,int c){
	int delta=b*b-4*a*c;
	int sd=sqrt(delta);
	int sp=delta/sd;

	if(delta<0){
		cout<<"NO"<<endl;
		return;
	}
	else if(delta==0){
		
		if(a<0){
			a=-a;
			b=-b;
		}
		if(b<0)cout<<"-";
		else if(b==0){
			cout<<0<<endl;
			return;
		}
		int gys=gcd(2*a,b);
		if(gys==1)cout<<b<<"/"<<2*a;
		else{
			b=b/gys;
			a=a*2/gys;
			if(a==b)cout<<1;
			else cout<<b<<"/"<<a;
		}
		return;
	}
	else{
		if(sd==sp){
			int dl=sqrt(delta);
			b=-b+dl;
			if(a<0){
			a=-a;
			b=-b;
		    }
		    if(b<0)cout<<"-";
		    else if(b==0){
			cout<<0<<endl;
			return;
		    }
		    int gys=gcd(2*a,b);
			if(gys==1)cout<<b<<"/"<<2*a;
			else{
				b=b/gys;
				a=2*a/gys;
			    if(a==b)cout<<1;
				else cout<<b<<"/"<<a;
			}
		}
		else{
			int m,n;
			m=axa(delta);
			n=axx(delta); 
			if(b!=0){
				if(a<0){
					a=-a;
					b=-b;
					m=-m;
		   		}
		    	if(b<0)cout<<"-";
		    	int gys=gcd(2*a,b);
			    if(gys==1)cout<<b<<"/"<<2*a;
			    else{
					b=b/gys;
					a=a*2/gys;
					if(a==b)cout<<1;
					else cout<<b<<"/"<<a;
				}
				if(m<0)cout<<"-";
				else cout<<"+";
		    	gys=gcd(2*a,m);
			    if(gys==1)cout<<m<<"*"<<"sqrt("<<n<<")"<<"/"<<2*a;
			    else{
					m=m/gys;
					a=a*2/gys;
			        if(a==m)cout<<"sqrt("<<n<<")";
					else cout<<m<<"*"<<"sqrt("<<n<<")"<<"/"<<a;
				}
			}
			if(m<0)cout<<"-";
		    int gys=gcd(2*a,m);
			if(gys==1)cout<<m<<"*"<<"sqrt("<<n<<")"<<"/"<<2*a;
			else{
				m=m/gys;
				a=a*2/gys;
				if(a==m)cout<<"sqrt("<<n<<")"<<"/";
				else cout<<m<<"*"<<"sqrt("<<n<<")"<<"/"<<a;
			}
		}
	}
}

int axa(int dt){
	int a=1;
	for(int i=2;i*i<dt;i++){
		while(dt%(i*i)==0){
			dt=dt/i/i;
			a=a*i;
		}
	}
	return a;
}
int axx(int dt){
	for(int i=2;i*i<dt;i++){
		while(dt%(i*i)==0){
			dt=dt/i/i;
		}
	}
	return dt;
}
int gcd(int a,int b){
	int b1=max(a,b);
	int a1=min(a,b);
	if(b1%a1==0)return a1;
	if(a1==1)return 1;
	return gcd(b1%a1,a1); 
}

