#include<bits/stdc++.h>
#define ll long long
#define R register
using namespace std;
ll n,T;
inline ll gcd(ll x,ll y) {
	if(x%y==0)return y;
	return gcd(y,x%y);
}
int main() {
//	freopen("uqe.in","r",stdin);
//	freopen("uqe.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>T>>n;
	while(T--) {
		ll x,y,z;
		cin>>x>>y>>z;
		ll d=(y*y)-4*(x*z);
		if(d<0) {
			cout<<"NO\n";
			continue;
		}
		if(d==0) {
			ll fz=-y,fm=2*x;
			bool fl=0;
			if(fz<0&&fm<0) {
				fz=-fz,fm=-fm;
			} else if(fz<0&&fm>0) {
				fl=1;
				fz=-fz;
			} else if(fz>0&&fm<0) {
				fl=1,fm=-fm;
			}
			if(fz==0){
				cout<<"0\n";continue;
			}
			ll md=gcd(fz,fm);
			if(fl) {
				cout<<'-';
			}
//			cout<<fz/md<<'/'<<fm/md<<'\n';
			if(fz%fm==0) {
				cout<<fz/fm<<'\n';
			} else {
				cout<<fz/md<<'/'<<fm/md<<'\n';
			}
		} else {
			ll mul=1;
			ll t=d;
			for(R int j=2; j<=t; j++) {
				int cnt=0;
				while(t%j==0) {
					cnt++;
					t/=j;
					if(cnt%2==0)mul*=j;
				}
			}
			d/=(mul*mul);
			ll fz=-y,fm=2*x;
			if(d==1) { //��ȫƽ����
				fz=-y+mul;
				bool fl=0;
				if(fz==0){
					cout<<"0\n";continue;
				}
				if(fz<0&&fm<0) {
					fz=-fz,fm=-fm;
				} else if(fz<0&&fm>0) {
					fl=1;
					fz=-fz;
				} else if(fz>0&&fm<0) {
					fl=1,fm=-fm;
				}
				ll md=gcd(fz,fm);
				if(fl) {
					cout<<'-';
				}
				if(fz%fm==0) {
					cout<<fz/fm<<'\n';
				} else {
					cout<<fz/md<<'/'<<fm/md<<'\n';
				}
			}else{
				bool fl=0;
				if(fz<0&&fm<0) {
					fz=-fz,fm=-fm;
				} else if(fz<0&&fm>0) {
					fl=1;
					fz=-fz;
				} else if(fz>0&&fm<0) {
					fl=1,fm=-fm;
				}
				ll md=gcd(fz,fm);
				if(fl) {
					cout<<'-';
				}
				if(fz%fm==0&&fz) {
					cout<<fz/fm;
				} else if(fz){
					cout<<fz/md<<'/'<<fm/md;
				}
				fl=0;
				if(fm<0){
					fl=1;fm=-fm;
				}
				if(fl){
					cout<<'-';
				}else if(fz)cout<<'+';
				md=gcd(mul,fm);
				if(mul%fm==0){
					if(mul/fm==1)cout<<"sqrt("<<d<<')'<<'\n';
					else cout<<mul/fm<<"*sqrt("<<d<<')'<<'\n';
				}else{
					if(mul/md==1)cout<<"sqrt("<<d<<")"<<"/"<<fm/md<<'\n';
					else cout<<mul/md<<"*sqrt("<<d<<")"<<"/"<<fm/md<<'\n';
				}
			}
		}
	}
	return 0;
}
/*
9 1000
1 -1 0
-1 -1 -1
1 -2 1
1 5 4
4 4 1
1 0 -432
1 -3 1
2 -4 1
1 7 1
*/
