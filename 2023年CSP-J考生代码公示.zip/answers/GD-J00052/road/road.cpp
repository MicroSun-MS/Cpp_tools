#include<bits/stdc++.h>
#define ll long long
#define R register
using namespace std;
const int N=1e5+5;
int n,m;
ll b[N],cost1[N],val[N],cur,sum,ans,pre[N],minn=1e9,summ;
//pre[i]��ʾ1~i�ľ��� 
struct edge{
	ll cost,id;
}a[N];
inline bool cmp(edge x,edge y){
	if(x.cost!=y.cost)return x.cost>y.cost;
	else return x.id>y.id;
}
int main(){
	freopen("road.in","r",stdin);freopen("road.out","w",stdout);
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	cin>>n>>m;
	for(R int i=1;i<n;i++){
		cin>>b[i];sum+=b[i];
		pre[i+1]=pre[i]+b[i];
	}
	for(R int j=1;j<=n;j++){
		cin>>a[j].cost;
		cost1[j]=a[j].cost;
		a[j].id=j;
		minn=min(minn,cost1[j]);
	}
	sort(a+1,a+n+1,cmp);
//	for(R int i=1;i<=n;i++){
//		cout<<a[i].id<<' '<<a[i].cost<<'\n';
//	}
	if(sum<=m){
		cout<<cost1[1]<<'\n';
		return 0;
	}
	if(minn==cost1[1]){
		if(sum%m!=0){
			cout<<cost1[1]*(sum/m+1);
		}else cout<<cost1[1]*(sum/m);
		return 0;
	}
	int startid;
	for(R int i=1;i<=n;i++){
		if(a[i].id==1){
			startid=i;break;
		}
	}
	ll p=0,idh=1;summ=0;
	for(R int i=startid;i<=n;){
		int shouldbuy=i;
		for(R int j=i+1;j<=n;j++){
			if(a[i].cost>a[j].cost&&a[j].id>idh){
				shouldbuy=j;break;
			}
		}
		if(shouldbuy==i){
			ll less=pre[n]-p;
			if(less%m==0){
				cout<<summ+cost1[idh]*(less/m)<<'\n';
			}else{
				cout<<summ+cost1[idh]*(less/m+1);
			}
			return 0;
		}
		ll dis=pre[a[shouldbuy].id];
		if(p>=dis){
			idh=a[shouldbuy].id;
			i=idh;
//			cout<<shouldbuy<<' '<<p<<' '<<idh<<' '<<summ<<'\n';
			continue;
		}
		dis=dis-p;
		if(dis%m!=0){
			summ+=(dis/m+1)*cost1[idh];
			p+=(dis/m+1)*m;idh=a[shouldbuy].id;
		}else{
			p+=dis;summ+=dis/m*cost1[idh];idh=a[shouldbuy].id;
		}
//		cout<<shouldbuy<<' '<<p<<' '<<idh<<' '<<summ<<'\n';
		i=shouldbuy;
		if(p>=pre[n]){
			cout<<summ;break;
		}
	}
	return 0;
}
/*
5 4
10 10 10 10
9 8 9 6 5

79
*/
