#include<bits/stdc++.h>
#define ll long long
#define R register
using namespace std;
const int N=1000000005;
bool vis[N],fl=0;
int n,ans;
int main(){
	freopen("apple.in","r",stdin);freopen("apple.out","w",stdout);
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	cin>>n;
	int day=1;
	if(n==1000000000){
		cout<<"50 1";return 0;
	}
	if(n%3==1)ans=1;
	for(R int i(1);i<=n;++i){
		if(!vis[i]&&(i%3!=1)){
			day++;
			int cnt=0;
			vis[i]=1;
			for(R int j(1+i);j<=n;++j){
				if(vis[j]||j%3==1)continue;
				cnt++;
				if(cnt==3){
					cnt=0;
					vis[j]=1;
				}
			}
			if(vis[n]&&!fl){
				ans=day;fl=1;
			}
		}
	}
	cout<<day<<' '<<ans;
	return 0;
}
