#include<bits/stdc++.h>
#define ll long long
#define R register
using namespace std;
const int N=2e4+5;
struct edge{
	int u,v,w;
}e[N];
int tot,head[N];
ll ti,n,m,k,a[N],minn=1000000000;
bool fl=0;
inline void add(int u,int v,int w){
	e[++tot]={v,head[u],w};head[u]=tot;
}
inline void dfs(int u,ll sum){
	if(minn<=sum)return;
	if(u==n){
//		cout<<sum<<'\n';
		if(sum%k==0)minn=min(minn,sum);
		return;
	}
	for(R int i=head[u];i;i=e[i].v){
		int v=e[i].u;
		if(sum<e[i].w){
			ll k1=sum;
			if((e[i].w-sum)%k==0){
				dfs(v,e[i].w);
			}else{
				dfs(v,sum+(1+(e[i].w-sum)/k)*k);
			}
		}
		dfs(v,sum+1);
	}
}
queue<int> q;
ll d[N];
bool vis[N];
inline void solve(){
	q.push(1);
	memset(d,0x3f,sizeof d);d[1]=1;
	while(!q.empty()){
		int id=q.front();q.pop();
		for(R int i=head[id];i;i=e[i].v){
			int v=e[i].u;
			if(d[v]>d[id]+1){
				d[v]=d[id]+1;
				if(!vis[v]){
					q.push(v);vis[v]=1;
				}
			}
		}
		vis[id]=0;
	}
	cout<<d[n];
	return;
}
int main(){
	freopen("bus.in","r",stdin);freopen("bus.out","w",stdout);
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	cin>>n>>m>>k;
	for(R int i=1;i<=m;i++){
		int u,v,w;cin>>u>>v>>w;fl|=(!w);
		add(u,v,w);
	}
	if(!fl&&k==1){
		solve();
		if(minn==1000000000)cout<<-1;
		else cout<<minn;
		return 0;
	}
	dfs(1,k);
	if(minn==1000000000)cout<<-1;
	else cout<<minn;
	return 0;
}
/*
5 5 3
1 2 0
2 5 1
1 3 0
3 4 3
4 5 1

6
*/
