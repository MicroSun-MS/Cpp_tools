#include<bits/stdc++.h>
using namespace std;
int p[10005];
int D;int xs=1;
void find()
{	
 	memset(p,0,sizeof(p));
    xs=1;
	int n=D;
	for(int i=2;i*i<=n;i++)
	{
		if(n%i==0)
		{
			while(n%i==0)
			{
				p[i]++;
				n/=i;
			}
		}
	}
	if(n>1) p[n]++;
	for(int i=2;i<=10000;i++)
	{
		if(p[i]>=2)
		{
			while(p[i]-2>=0)
			{
				p[i]-=2;
				xs*=i;
				D/=i*i;
			}
		}
	}
}
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout); 
	int n,M;
	cin>>n>>M;
	for(int i=1;i<=n;i++)
	{
		int a,b,c;
		cin>>a>>b>>c;
		int f=1;
		D=b*b-4*a*c;
		int d=sqrt(D);
		if(d*d<D) f=0;
		if(D<0)
		{
			cout<<"NO"<<'\n';
			continue;
		}
		if(a>0)
		{
			if(f==1)
			{
				int fz=-b+d;
				int fm=2*a;
				int g=__gcd(fz,fm);
				fz=fz/g;fm=fm/g;
				if(fm<0)
				{
						fm=-fm;
						fz=-fz;
				}
				if(fz%fm==0) cout<<fz/fm<<'\n';
				else if(fm==1) cout<<fz<<'\n';
				else cout<<fz<<"/"<<fm<<'\n';
			}
			else 
			{
				if(b!=0)
				{
					int fb=-b,ra=2*a;
					int g=__gcd(fb,ra);
					fb=fb/g;ra=ra/g;
					if(ra<0)
					{
						fb=-fb;
						ra=-ra;
					}
					if(fb%ra==0) cout<<fb/ra;
					else if(ra==1) cout<<fb;
					else cout<<fb<<"/"<<ra;
					cout<<"+";					
				}
				find();
				int fb=xs,ra=2*a;
				int g=__gcd(fb,ra);
				fb=fb/g;ra=ra/g;
				if(ra<0)
				{
					fb=-fb;
					ra=-ra;
				}
				if(ra==1)
				{
					if(fb==1) cout<<"sqrt("<<D<<")"<<endl;
					else cout<<fb<<"*sqrt("<<D<<")"<<endl;
				}
				else
				{
					if(fb==1) cout<<"sqrt("<<D<<")"<<"/"<<ra<<endl;
					else cout<<fb<<"*sqrt("<<D<<")"<<"/"<<ra<<endl;
				}
			}
		}
		else if(a<0)
		{
			if(f==1)
			{
				int fz=-b-d;
				int fm=2*a;
				int g=__gcd(fz,fm);
				fz=fz/g;fm=fm/g;
				if(fm<0)
				{
						fm=-fm;
						fz=-fz;
				}
				if(fz%fm==0) cout<<fz/fm<<'\n';
				else if(fm==1) cout<<fz<<'\n';
				else cout<<fz<<"/"<<fm<<'\n';
			}
			else 
			{
				if(b!=0)
				{
					int fb=-b,ra=2*a;
					int g=__gcd(fb,ra);
					fb=fb/g;ra=ra/g;
					if(ra<0)
					{
						fb=-fb;
						ra=-ra;
					}
					if(fb%ra==0) cout<<fb/ra;
					else if(ra==1) cout<<fb;
					else cout<<fb<<"/"<<ra;
					cout<<"+";					
				}
				find();
				int fb=xs,ra=2*a;
				int g=__gcd(fb,ra);
				fb=fb/g;ra=ra/g;
				if(ra<0)
				{
					fb=-fb;
					ra=-ra;
				}
				if(fb<0) fb=-fb;
				if(ra==1)
				{
					if(fb==1) cout<<"sqrt("<<D<<")"<<endl;
					else cout<<fb<<"*sqrt("<<D<<")"<<endl;
				}
				else
				{
					if(fb==1) cout<<"sqrt("<<D<<")"<<"/"<<ra<<endl;
					else cout<<fb<<"*sqrt("<<D<<")"<<"/"<<ra<<endl;
				}
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
 } 
/*
9 1000
1 -1 0
-1 -1 -1
1 -2 1
1 5 4
4 4 1
1 0 -432
1 -3 1
2 -4 1
1 7 1
*/
 
