#include<bits/stdc++.h>
using namespace std;
int a[1000005];
int b[1000005];
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n,con=0;
	cin>>n;
	for(int i=1;i<=n;i++){
		a[i]=i;
	}
	int num=0,i=1,day=1,id=0;
//	cout<<day<<":";
	b[1]=1;
	while(num<n)
	{
		if(a[i]==n) id=day;
//		cout<<a[i]<<" ";
		num++;
		a[i]=-1;
		int c=0;
		while(c<2&&i<=n)
		{
			con++;
			if(a[i]!=-1) c++;
			i++;
		}
		while(a[i]==-1) i++;
		if(i>n)
		{
			day++;
//			cout<<'\n'<<day<<":";
			i=1;
			while(a[i]==-1) i++;
			b[day]=a[i];
		}
	}
	cout<<day-1<<" "<<id;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
