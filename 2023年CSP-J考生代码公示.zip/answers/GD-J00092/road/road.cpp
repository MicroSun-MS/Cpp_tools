#include<bits/stdc++.h>
using namespace std;
int dis[100005],price[100005],sumd=0,you;
int answ=1e9;
int pre[100005];
int minn=1e9;
int n,d;
void dfs(int id,int money,int mein)
{
	if(id==n)
	{
		answ=min(answ,money);
		return;
	}
	for(int i=id+1;i<=n;i++)
	{
		int dd=pre[i]-pre[id];
		int oil=dd/d;
		if(oil*d+mein<dd) oil++;
		dfs(i,money+oil*price[id],mein+oil*d-dd);
	}
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout); 
	cin>>n>>d;
	if(n==1)
	{
		cout<<"0";
		return 0;
	}
	for(int i=2;i<=n;i++){
		cin>>dis[i];
		sumd+=dis[i];
		pre[i]=dis[i]+pre[i-1];
	}
	for(int i=1;i<=n;i++){
		cin>>price[i];
		minn=min(minn,price[i]);
	}
	if(price[1]==minn)//��֦1 
	{
		int ans=sumd/d;
		if(ans*d<sumd) ans++;
		cout<<ans*price[1];
		return 0; 
	}
	dfs(1,0,0);
	cout<<answ;
	fclose(stdin);
	fclose(stdout);
	return 0;
 } 
/*
5 4
10 10 10 10
9 8 9 6 5
*/
