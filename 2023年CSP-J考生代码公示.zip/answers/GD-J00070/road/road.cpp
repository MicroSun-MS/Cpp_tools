#include <bits/stdc++.h>
using namespace std;
int n,d;
int v[100005];
int a[100005];
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	int sum=0;
	for(int i=1;i<=n-1;i++){
		cin>>v[i];
		sum+=v[i];
	}
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	if(sum%d==0){
		cout<<a[1]*sum/d;
	}
	else {
		cout<<a[1]*((sum/d)+1);
	}
	
	return 0;
}
