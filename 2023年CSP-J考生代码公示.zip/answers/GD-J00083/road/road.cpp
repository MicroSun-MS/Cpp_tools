#include <bits/stdc++.h>
using namespace std;
int n,d,v[100005],a[100005];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d %d",&n,&d);
	for (int i = 1;i < n;i++)
		scanf("%d",&v[i]);
	for (int i = 1;i <= n;i++)
		scanf("%d",&a[i]);
	long long sum = 0;
	long long less = 0;
	for (int i = 1;i <= n;i++)
	{
		int pos = -1;
		for (int j = i+1;j <= n;j++)
		{
			if (a[j] < a[i])
			{
				pos = j;
				break;
			}
		}
		if (pos == -1)
		{
			long long ans = 0;
			for (int j = i;j < n;j++)
			{
				ans += v[j];
			}
			ans -= less;
			less = 0;
			if (ans % d == 0)
				cout << (ans/d) * a[i] + sum;
			else
				cout << (1+(ans/d)) * a[i] + sum;
			return 0;
		}
		else 
		{
			long long ans = 0;
			for (int j = i;j < pos;j++)
			{
				ans += v[j];
			}
			ans -= less;
			less = 0;
			if (ans % d == 0)
			{
				sum += (ans/d) * a[i];
			}
			else
			{
				sum += (1+(ans/d)) * a[i];
				less += d*(1+(ans/d)) - ans;
			}
		}
		i = pos-1;
	}
	cout << sum;
	return 0;
}
