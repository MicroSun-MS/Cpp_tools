#include <bits/stdc++.h>
using namespace std; 
int flag[100000005],date,ans;
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	long long n;
	scanf("%lld",&n);
	for (int k = 1;k <= n;k++)
	{
		int x = 2;
		for (int i = 1;i <= n;i++)
		{
			if (flag[i] == 0 && x == 2)
			{
				if (i == n)
				{
					date = k;
				}
				flag[i] = 1;
				x = 0;
			}
			else if (flag[i] == 0) 
			{
				x++;
			}
		}
		int f = 1;
		for (int i = 1;i <= n;i++)
		{
			if (flag[i] == 0)
			{
				f = 0;
				break;
			}
		}
		if (f == 1)
		{
			ans = k;
			break;
		}
	}
	cout << ans << " " << date;
	return 0;
} 
