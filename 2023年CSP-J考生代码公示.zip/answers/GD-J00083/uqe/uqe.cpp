#include <bits/stdc++.h>
using namespace std;
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int t,m;
	cin >> t >> m;
	int a,b,c;
	for (int i = 1;i <= t;i++)
	{
		cin >> a >> b>> c;
		int dt = b*b - 4*a*c;
		if (dt < 0)
		{
			cout << "NO" << endl;
			continue;
		}
		else
		{
			int n = -b + sqrt(dt);
			if (n % 2*a == 0)
			{
				cout << (-b + sqrt(dt)) / 2*a  << endl;
				continue;
			}
			else
			{
				cout << -b << "/" << 2*a << "+" << "sqrt(" << dt<<")"<< "/" << 2*a << endl;
				continue; 
			}
		}
	}
	return 0;
}
