#include<bits/stdc++.h>
using namespace std;
const int maxn=100000+1000;
#define ll long long
ll v[maxn],a[maxn],oil[maxn];//������v[i]   ÿ��վ����ͼ�a[i]    Ҫȥ�ļ���վ�� oil[i]
ll n,d,ans=0,kil=0;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	int w;
	for(int i=2;i<=n;i++){
		cin>>w;
		v[i]=v[i-1]+w;
	}
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	int mu=a[1],k=2;
	oil[1]=1;
	for(int i=2;i<=n;i++){
		if(mu>a[i]){
			mu=a[i];
			oil[k++]=i;
		}
	}
	if(k==2){
		if(v[n]%d==0){
			cout<<v[n]/d*a[1];
		}else{
			cout<<(v[n]/d+1)*a[1];
		}
		return 0;
	}
	int nil=0,sheng=0;//nil:Ҫ�ӵ���   sheng:ʣ����� 
	for(int i=1;i<k-1;i++){
		nil=0;
		int next=v[oil[i+1]]-v[oil[i]];
		if((next-sheng)%d==0){
			nil=(next-sheng)/d;
		}else{
			nil=(next-sheng)/d+1;
		}
		sheng=nil*d+sheng-next;
		ans+=nil*a[oil[i]];
	}
	cout<<ans;

	return 0;
}

