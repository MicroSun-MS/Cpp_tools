#include<bits/stdc++.h>
using namespace std;
const int maxn=10000+1000;
int u[maxn],v[maxn],a[maxn];
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,k;
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		cin>>u[i]>>v[i]>>a[i];
	}
	cout<<-1;




	return 0;
}

