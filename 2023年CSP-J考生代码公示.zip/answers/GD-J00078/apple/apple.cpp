#include<bits/stdc++.h>
using namespace std;
int n,ans=0,ans2=1;
bool check=false;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	while(n>0){
		if((n-1)%3==0){
			check=true;
		}
		n=n*2/3;
		ans++;
		if(!check){
			ans2++;
		}
	}
	cout<<ans<<" "<<ans2;
	
	
	return 0;
}
