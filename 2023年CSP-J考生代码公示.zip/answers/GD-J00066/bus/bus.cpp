#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,m,k;
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m*3;i++)cin>>n;
	cout<<k*2;
	return 0;
} 
