#include<bits/stdc++.h>
#define ll long long
using namespace std;
	int jl[100010];
	bool t[100010];
	int yj[100010];ll zj=0;
	int sy=0;
int main(){
	ll n,m;
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>m;
	bool tp=1;
	for(ll i=1;i<n;i++){
		cin>>jl[i];
	}
	for(ll i=1;i<=n;i++){
		cin>>yj[i];
	}
	for(ll i=1;i<=n;i++){
		if(t[i]==0){
			for(ll j=i;j<=n;j++){
				if(yj[i]>yj[j]){
					int cj=0;
					for(ll u=i;u<j;u++){
						cj+=jl[u];
					}
					zj+=((cj-sy)+m-1)/m*yj[i];
					sy=(sy+((cj-sy)+m-1)/m*m)-cj;
					tp=0;
//					cout<<sy<<endl;
					break;
				}
				
				else {
					t[j]=1;
				}
			}
			if(tp==1){
				int cj=0;
				for(ll u=i;u<n;u++){
					cj+=jl[u];
				}
				zj+=((cj-sy)+m-1)/m*yj[i];
				sy=(sy+((cj-sy)+m-1)/m*m)-cj;
				cout<<zj;
				return 0;
			}
		}
	}
	cout<<zj;
	return 0;
}
