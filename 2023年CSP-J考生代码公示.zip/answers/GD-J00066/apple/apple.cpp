#include<bits/stdc++.h>
#define ll long long
using namespace std;
int a[100000100];
bool b[100000100];
int main(){
	ll n,m;
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;m=n;
	for(int i=1;i<=n+1;i++){
		a[i]=i;
	}
	if(n<=3){
		cout<<n<<' '<<n;
	}
	int t=0,bj=0;
	for(int i=1;i<=n;i++){
		for(int j=i;j<=n;j++){
			if(b[j]==0){
				bj=1;
				if(a[j]==m&&t==0){
					m=i;
				}
				if(t==0)b[j]=1;
				t++;
				if(t==3)t=0;
			}
		}
		if(bj==0){
			cout<<i-1<<' '<<m;
			return 0;
		}
		bj=0,t=0;
	}
	return 0;
}
