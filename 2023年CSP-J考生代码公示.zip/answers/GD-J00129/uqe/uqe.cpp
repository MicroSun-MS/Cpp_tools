#include <bits/stdc++.h>
using namespace std;
int gcd(int a,int b){
	int k=min(a,b);
	int ans,i;
	if(a%b==0||b%a==0)return k;
	for(i=2;i<k;i++){
		if(a%i==0&&b%i==0)
			ans=i;
	}
	return ans;
}

int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int t,m;
	cin>>t>>m;
	for(int i=0;i<t;i++){
		cin>>a>>b>>c;
	}
	cout<<0;
	return 0;
}
