#include <bits/stdc++.h>
using namespace std;
int ans[100005],ans2[100005];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int s[100005],p[100005];
	int n,m,less=0,k=0,sum=0;
	cin>>n>>m;
	for(int i=0;i<n-1;i++){
		cin>>s[i];
		ans[k]=s[i];
		}
	for(int i=0;i<n;i++)cin>>p[i];
	
	while(k<n-1){
		int i=k+1;
		while(p[k]<=p[i]){
			s[k]+=s[i];
			i++;
		}
		int q=1;
		s[k]-=less;
		while(q*m<s[k]){
			q++;
		}
		ans2[k]=q;
		sum+=q*p[k];
		less=q*m-s[k];
		k=i;
	}
	cout<<sum;
	return 0;
}

