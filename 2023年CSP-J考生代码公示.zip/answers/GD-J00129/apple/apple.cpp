#include <bits/stdc++.h>
using namespace std;
int b[10000000];
int main()
{
	freopen("apple.in","r",stdin);
    freopen("apple.out","w",stdout);
    int n,ans,num=0,x,k=0,j=0;
    cin>>n;
    int s1=0;
    int s2=1;
    int i=0;
    while(i<n){
    	i=s1+s2;
    	s1=s2;
    	s2=i;
    	x=i;
    	j++;
    	while(x<=n){
    		k=0;
    		if(x==n)ans=j;
    		b[x]=1;
    		while(k<3){
    			x++;
    			if(b[x]==0)
    				k++;
			}
		}
	}
	if(b[n]==0){
		ans=j-1;
	}
	cout<<j<<" "<<ans;
	return 0;
}
