#include<bits/stdc++.h>
using namespace std;

int n, d, v[10005], a[10005], dp[10005], minest, ans;

int main(){
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	
	cin >> n >> d;
	for(int i = 0; i < n - 1; i++) cin >> v[i];
	for(int i = 0; i < n; i++) cin >> a[i];
	
	for(int i = 1; i < n; i++){
		minest = a[0];
		for(int j = 1; j < i; j++) minest = min(minest, a[j]);
		
		dp[i] = (v[i - 1] / d + (v[i - 1] % d != 0)) * minest;
		cout << (v[i - 1] / d + (v[i - 1] % d != 0)) << ' ' << minest<< ' ' << v[i - 1] << endl;
	}
	
	for(int i = 0; i < n; i++) ans += dp[i];
	
	cout << ans << endl;
	
	return 0;
}
