#include<bits/stdc++.h>
using namespace std;

vector<int> vi;
long long n, tim, eatn;

int main(){
	freopen("apple.in", "r", stdin);
	freopen("apple.out", "w", stdout);
	
	cin >> n;
	for(int i = 1; i <= n; i++) vi.push_back(i);
	
	while(vi.size()){
		tim++;
		for(int i = 0; i < vi.size(); i += 2){
			if(vi[i] == n) eatn = tim;
			for(int j = i; j < n - 1; j++) vi[j] = vi[j + 1];
			vi.pop_back();
		}
	}
	
	cout << tim << ' ' << eatn;
	
	return 0;
} 
