#include<bits/stdc++.h>
using namespace std;

int a, b, c;

int main(){
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	
	cin >> a >> b >> c;
	
	if(a * b - 4 * a * c) cout << "NO";
	else if(b == 0) cout << sqrt(0 - c);
}
