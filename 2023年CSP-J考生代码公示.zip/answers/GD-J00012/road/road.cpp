#include<iostream>
#include<cstdio>
#include<vector>
using namespace std;
const int maxn=1e5+10;
#define ll long long
int n;
ll d,sum[maxn],val[maxn],dis,mi=1e18+10;
ll ans;
vector<int> vec;
int main(){
	freopen("road.in","r",stdin); 
	freopen("road.out","w",stdout);
	scanf("%d %lld",&n,&d);
	for(int i=2;i<=n;i++){
		scanf("%lld",&dis);//dis
		sum[i]=sum[i-1]+dis;
	}
	for(int i=1;i<=n;i++){
		scanf("%lld",&val[i]);
		if(val[i]<mi){
			vec.push_back(i); 
			mi=val[i];
		}
	}
	dis=0ll;
	for(int i=0;i<vec.size()-1;i++){
		int x=vec[i],y=vec[i+1];
		ll res=sum[y]-sum[x]-dis;
		ll rec=(res%d==0?res/d:res/d+1ll);
		ans+=rec*val[x];
		dis=dis+rec*d-(sum[y]-sum[x]);
	}
	if(vec[vec.size()-1]!=n){
		int x=vec[vec.size()-1];
		ll res=sum[n]-sum[x]-dis;
		ll rec=(res%d==0?res/d:res/d+1ll);
		ans+=rec*val[x];
	}
	printf("%lld",ans);
	return 0;
}
