#include<iostream>
#include<map>
using namespace std;
map<int,int> vis;
#define ll long long
int n;
int ans,tot;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n); 
	for(int i=1;i<=n;i++){
		if(vis[i]){
			ans=max(ans,vis[i]);
			continue;
		}
		else{
			vis[i]=++tot;
			int cnt=0;
			for(int j=i+1;j<=n;j++){
				if(vis[j])
					continue;
				else
					cnt++;
				if(cnt==3){
					vis[j]=1;
					cnt=0;
				}
			} 
		}
	}
	printf("%d %d",tot,vis[n]);
	return 0;
} 
