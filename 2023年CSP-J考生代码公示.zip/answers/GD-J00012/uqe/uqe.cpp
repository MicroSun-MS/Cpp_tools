#include<iostream>
#include<cmath>
using namespace std;
int t,m;
int a,b,c,tmpa,tmpb,tmpc;
bool fun1(int fl,int fz,int fm){
	if(fz==0)
		return 0;
	if(fl==-1){
		printf("-"); 
	} 
	if(fm==1){
		printf("%d",fz);
	}
	else{
		printf("%d/%d",fz,fm);
	}
	return 1;
} 
bool fun2(int fz,int fm,int dlta){
	if(dlta==0)
		return 0;
	if(dlta==1){
		return fun1(1,fz,fm); 
	} 
	if(fz!=1){
		printf("%d",fz);
		printf("*");
	} 
	if(dlta!=1){
		printf("sqrt(%d)",dlta);
	} 
	if(fm!=1){
		printf("/%d",fm);
	}
	return 1;
} 
int gcd(int a,int b){
	if(a<b)
		swap(a,b);
	if(b==0)
		return a;
	else
		return gcd(b,a%b); 
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d %d",&t,&m);
	for(int k=1;k<=t;k++){ 
		scanf("%d %d %d",&tmpa,&tmpb,&tmpc);
		int fla=(tmpa<0?-1:1),flb=(tmpb<0?-1:1),flc=(tmpc<0?-1:1);
		a=abs(tmpa),b=abs(tmpb),c=abs(tmpc);
		int dlt=tmpb*tmpb-4*tmpa*tmpc;
		if(dlt<0){
			printf("NO\n");
			continue;
		} 
		if(tmpb==0&&tmpc==0){
			printf("0\n");
			continue;	
		}
		if(tmpb==0){
			if(tmpa*tmpc>0){
				printf("NO");
			}
			else{
				int d=1;
				c=c*a;
				for(int i=2;i*i<=c;i++){
					while(c%(i*i)==0){
						c/=i*i;
						d*=i;
					} 
				} 
				int g1=gcd(d,a);
				fun2(d/g1,a/g1,c);
			}
			printf("\n");
			continue;
		}
		if(tmpc==0){
			if(tmpb*tmpa<0){
				int g1=gcd(a,b); 
				fun1(1,b/g1,a/g1);
			}
			else{
				printf("0");
			}
			printf("\n");
			continue; 
		} 
		else{
			int d=1;
			if(dlt){
				for(int i=2;i*i<=dlt;i++){
					while(dlt%(i*i)==0){
						d*=i;//����ǰ��ϵ�� 
						dlt/=(i*i);
					}
				}  
			}
			if(dlt==0){
				int g1=gcd(b,2*a);
				fun1(fla*flb*(-1),b/g1,2*a/g1);//p1; 
			}
			else if(dlt==1){
				tmpb=-tmpb;
				if(tmpa<0&&tmpb<0){
					tmpb-=d;
				}
				else if(tmpa<0&&tmpb>0)
					tmpb-=d;
				else if(tmpa>0&&tmpb<0)
					tmpb+=d;
				else
					tmpb+=d;
				flb=(tmpb<0?-1:1);
				tmpb=abs(tmpb);
				int g1=gcd(tmpb,2*a);
				fun1(flb*fla,tmpb/g1,2*a/g1);
			}
			else{
				int g1=gcd(b,2*a);
				int g2=gcd(d,2*a); 
				if(b==0&&d==0){
					printf("0\n");
					continue;
				}
				fun1(flb*fla*(-1),b/g1,2*a/g1);
				if(b!=0)
					printf("+");
				fun2(d/g2,2*a/g2,dlt);
			}
			printf("\n");
		} 
	}
	return 0; 
}
