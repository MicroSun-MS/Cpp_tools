#include<bits/stdc++.h>
using namespace std;
double a,b,c;
int t,m;
int qq,pp;
int gcd(int a,int b)
{
 	if(b==0) return a;
 	else return gcd(b,a%b);
}
bool youli(double x)
{
	int q,p;
	for(q=1;q<=1000;q++)
	{
		p=x*q;
		if(p==x*q&&abs(gcd(p,q))==1)
		{
			break;
		}
	}
	if(q!=0&&p!=0) return true;
	else return false;
}
void printyouli(double x);
void printwuli(double x)
{
	bool ggg=0;
	for(int r=2;r<=m;r++)
	{
		for(double q2=0.1;q2<=m;q2+=0.01)
		{
			double q1=x-q2*sqrt(r);
			if(!youli(q1)) continue;
			if(q1!=0) 
			{
				printyouli(q1);
				cout<<"+";
				if(q2==1) printf("sqrt(%d)",r);
				else if((int)q2==q2) printf("%d*sqrt(%d)",(int)q2,(int)r);
				else if(1.0/q2==(int)1.0/q2) printf("sqrt(%d)/%d",r,(int)1.0/q2);
				else
				{
					for(int d=2;d<=m;d++)
					{
						int c=d*q2;
						if(c==d*q2&&abs(gcd(c,d))==1&&c>1)
						printf("%d*sqrt(%d)/%d",c,r,d);
					}
				}
				cout<<endl;
				ggg=1;
				break;
			}
		}
		if(ggg=1) break;
	}
}
void printyouli(double x)
{
	int p,q;
	for(q=1;q<=m;q++)
	{
		p=x*q;
		if(p==x*q&&abs(gcd(p,q))==1)
		{
			if(q==1) printf("%d\n",p);
			else printf("%d/%d\n",p,q);
			break;
		}
	}
	if(q==0&&p==0) printwuli(x);
}

int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>t>>m;
	for(int i=1;i<=t;i++)
	{
		qq=0,pp=0;
		scanf("%lf%lf%lf",&a,&b,&c);
		double dt=b*b-4*a*c;
		if(dt<0) 
		{
			cout<<"NO\n";
			continue;
		}
		double x=max((-b+sqrt(dt))/(2*a),(-b-sqrt(dt))/(2*a));
		printyouli(x);
		
	}
	return 0;
}

