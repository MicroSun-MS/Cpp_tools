#include<bits/stdc++.h>
using namespace std;
int n,m,k,ans=0xff;
int w[10010][10010];
bool f[10010];
int q[10010][2];
int bfs()
{
	int head=0,tail=1;
	q[head][0]=1,q[head][1]=0;
	f[1]=1;
	do
	{
		head++;
		for(int i=1;i<=n;i++)
		{
			if(w[q[head][0]][i]!=-1&&f[i]==0)
			{
				f[i]=1;
				tail++;
				q[tail][0]=i,q[tail][1]=q[head][1]+1;
			}
		}
	}while(head<tail);
	
	for(int i=0;i<=tail;i++)
	{
		if(q[i][0]==n) return q[i][1];
	}
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	f[1]=1;
	memset(w,-1,sizeof(w));
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++)
	{
		int u,v;
		scanf("%d%d",&u,&v);
		scanf("%d",&w[u][v]);
	}
	ans=bfs();
	if(ans==0xff)
	{
		cout<<-1;
		return 0;
	}
	while(1)
	{
		if(ans%k==0) 
		{
			cout<<ans;
			return 0;
		}
		ans++;
	}
	
	return 0;
}

