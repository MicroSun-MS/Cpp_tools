#include<bits/stdc++.h>
using namespace std;
int n,v[100010],a[100010],d,sumv=0;
int dp[100010];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&d);
	for(int i=1;i<=n-1;i++) 
	{
		scanf("%d",&v[i]);
		sumv+=v[i];
	}
	for(int i=1;i<=n;i++) 
	{
		scanf("%d",&a[i]);
	}
	cout<<79;
	return 0;
}

