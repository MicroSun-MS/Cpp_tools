#include<bits/stdc++.h>
using namespace std;
int n;
int a[1000100];
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	if(n==1) cout<<"1 1";
	else 
	{
		cout<<ceil(n*1.0/2)+1<<" ";
		if(n%3==1) cout<<1;
		else
		{
			int day=1;
			while(1)
			{
				int x=1;
				for(int i=1;i<=n;i++)
				{
					if(a[i]) continue;
					if(x==1) a[i]=1;
					if(x==3) x=1;
					else x++;
					if(i==n&&a[i]==1) 
					{
						cout<<day;
						return 0;
					}
				}
				day++;
			}
		}
	}
	
	return 0;
}

