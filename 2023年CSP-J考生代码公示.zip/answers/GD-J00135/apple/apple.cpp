#include<bits/stdc++.h>
using namespace std;
long long x;
int main(){
//	freopen("apple.in","r",stdin);
//	freopen("apple.out","w",stdin);
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>x;
	long long ans1=0,ans2=0;
	while(x){
		ans1++;
		if(x%3==1&&!ans2) ans2=ans1;
		x-=1+(x-1)/3;
	}
	cout<<ans1<<" "<<ans2;
	return 0;
}
//����
