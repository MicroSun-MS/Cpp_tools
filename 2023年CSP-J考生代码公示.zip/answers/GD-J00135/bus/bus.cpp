#include<bits/stdc++.h>
using namespace std;
struct node{
	int num,tim;
};
int n,m,k,c[20004];
vector<int> l[10004];
int bfs(){
	queue<node>q;
	node first;
	int get_in=0;
	first.num=1,first.tim=0;
	q.push(first);
	while(!q.empty()){
		node tmp=q.front();
		q.pop();
		if(tmp.num==n) return tmp.tim;
		for(int i=0;i<l[tmp.num].size();i++){
			node t;
			t.num=l[tmp.num][i];
			t.tim=tmp.tim+1;
			q.push(t);
		}
	}
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		int a,b;
		cin>>a>>b>>c[i];
		l[a].push_back(b);
	}
	cout<<bfs();
	return 0;
}
//����
