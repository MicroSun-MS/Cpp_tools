#include<bits/stdc++.h>
using namespace std;
int n,dis[100005],pri[100005],k;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>k;
	for(int i=2;i<=n;i++) scanf("%d",&dis[i]),dis[i]+=dis[i-1];
	for(int i=1;i<=n;i++){
		scanf("%d",&pri[i]);
	}
	int ans=0;
	for(int i=1;i<n;){
		int min_pri=i;
		for(int j=i+1;j<=n;j++)
			if(pri[j]<pri[i]){
				min_pri=j;
				break; 
			}
		if(min_pri==i) ans+=(dis[n]-dis[i])/k*pri[i],i=n;
		else ans+=(dis[min_pri]-dis[i])/k*pri[i],i=min_pri;
	}
	cout<<ans;
	return 0;
}
//����
