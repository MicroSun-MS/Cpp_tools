#include<bits/stdc++.h>
using namespace std;
int n,k;
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		int a,b,c;
		scanf("%d%d%d",&a,&b,&c);
		cout<<0<<endl;
	}
	return 0;
}
//����
