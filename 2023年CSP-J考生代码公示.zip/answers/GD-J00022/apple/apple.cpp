#include<iostream>
using namespace std;
using ll=long long;
ll n,res1,res2;
int main(){
    freopen("apple.in","r",stdin);
    freopen("apple.out","w",stdout);
    scanf("%lld",&n);
    while(n){
        res1++;
        if(!res2 and n%3==1)res2=res1;
        n-=(n/3+(n%3!=0));
    }
    printf("%lld %lld\n",res1,res2);
}