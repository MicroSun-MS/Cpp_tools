#include<iostream>
#include<cstring>
#include<vector>
#include<queue>
using namespace std;
using ll=long long;
const int N=1e4+10;
int n,m,k,x,y,z;
bool tag;
vector<pair<int,int>> road[N];
ll res,tmp3,tmp4;
const int lmt=CLOCKS_PER_SEC*0.98;
bool vis[N][110],vis2[N];
ll tmp1,tmp2;
const ll all=sizeof(vis)+sizeof(road);
queue<pair<int,int>> q;
int main(){
    freopen("bus.in","r",stdin);
    freopen("bus.out","w",stdout);
    scanf("%d%d%d",&n,&m,&k);
    // printf("%lld\n",all);
    for(int i=1;i<=m;i++){
        scanf("%d%d%d",&x,&y,&z);
        road[y].push_back({x,z});
    }
    for(ll t=0;!tag and clock()<lmt;t+=k){
        memset(vis2,0,n+1);
        memset(vis[n],0,sizeof(vis[n]));
        vis[n][0]=1;
        q.push({n,t});
        while(q.size() and clock()<lmt){
            auto pr=q.front();
            q.pop();
            tmp1=pr.first,tmp2=pr.second;
            if(tmp1==1 and tmp2%k==0){
                printf("%lld\n",t);
                return 0;
            }
            if(tmp2==0)continue;
            for(auto& ed:road[tmp1]){
                tmp3=ed.first;
                tmp4=ed.second;
                if(tmp4>tmp2-1)continue;
                if(!vis2[tmp3]){
                    vis2[tmp3]=true;
                    memset(vis[tmp3],0,sizeof(vis[tmp3]));
                }
                if(!vis[tmp3][(tmp2-1+k)%k]){
                    vis[tmp3][(tmp2-1+k)%k]=true;
                    q.push({tmp3,tmp2-1});
                }
            }
        }
    }
    puts("-1");
}