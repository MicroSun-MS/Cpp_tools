#include<iostream>
using namespace std;
using ll=long long;
ll tmp;
inline ll gcd(ll x,ll y){
    return y?gcd(y,x%y):x;
}
struct frac{
    ll x,y;
    friend frac conquer(const frac& ele){
        ll tmp=gcd(abs(ele.x),abs(ele.y));
        if(ele.y<0)return {-ele.x/tmp,-ele.y/tmp};
        return {ele.x/tmp,ele.y/tmp};
    }
    frac operator+(const frac& ele)const{
        frac ret;
        ret.x=x*ele.y+ele.x*y;
        ret.y=y*ele.y;
        return conquer(ret);
    }
    friend frac operator-(const frac& ele){
        return {-ele.x,ele.y};
    }
    frac rev(const frac& ele)const{
        return {ele.y,ele.x};
    }
    frac operator-(const frac& ele)const{
        return conquer(*this+(-ele));
    }
    frac operator*(const frac&ele)const{
        frac ret;
        ret.x=x*ele.x;
        ret.y=y*ele.y;
        return conquer(ret);
    }
    frac operator/(const frac& ele)const{
        return conquer(*this*rev(ele));
    }
    void print(){
        printf("%lld",x);
        if(y!=1)printf("/%lld",y);
    }
};
ll t,m,a,b,c,dt;
void run(){
    scanf("%lld%lld%lld",&a,&b,&c);
    dt=b*b-4*a*c;
    // printf("%lld %lld %lld\n",a,b,c);
    // printf("%lld\n",dt);
    if(dt<0){
        puts("NO");
        return;
    }
    frac res={-b,2*a};
    res=conquer(res);
    if(dt==0){
        res.print();
        putchar('\n');
        return;
    }
    tmp=1;
    for(int i=2;i*i<=dt;i++){
        while(dt%(i*i)==0){
            tmp*=i;
            dt/=(i*i);
        }
    }
    frac res2={tmp,2*a};
    res2=conquer(res2);
    if(dt==1){
        res=res+res2;
        res2.print();
        putchar('\n');
        return;
    }
    if(res2.x==1 and res2.y==1){
        res.print();
        putchar('+');
        printf("sqrt(%lld)\n",dt);
        return;
    }
}
int main(){
    freopen("uqe.in","r",stdin);
    freopen("uqe.out","w",stdout);
    scanf("%lld%lld",&t,&m);
    // printf("%lld %lld\n",t,m);
    while(t--)run();
}