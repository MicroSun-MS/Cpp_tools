#include<iostream>
#include<vector>
using namespace std;
const int N=1e5+10;
using ll=long long;
ll n,m,dis[N],v[N],cur,tmp,res,tag,pre,tmp2;
vector<int> vr;

int main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    scanf("%lld%lld",&n,&m);
    for(int i=2;i<=n;i++)scanf("%lld",dis+i),dis[i]+=dis[i-1];
    for(int i=1;i<=n;i++)scanf("%lld",v+i);
    vr.push_back(1);
    tag=n-1;
    for(;tag>0 and v[tag]<=v[tag+1];tag--);
    tag++;
    pre=1;
    for(int i=2;i<tag;i++){
        if(v[i]<v[pre]){
            pre=i;
            vr.push_back(i);
        }
    }
    vr.push_back(tag);
    if(tag!=n)
    vr.push_back(n);
    for(int i=1;i<vr.size();i++){
        // printf("%lld ",vr[i]);
        tmp=dis[vr[i]]-dis[vr[i-1]];
        // tmp-=cur;
        // printf("%lld %lld ",cur,tmp);
        if(tmp-cur>0){
            tmp2=tmp;
            tmp-=cur;
            res+=(tmp/m+(tmp%m!=0))*v[vr[i-1]];
            cur+=(tmp/m+(tmp%m!=0))*m;
            tmp=tmp2;
        }
        cur-=tmp;
        // printf("%lld ",cur);
        // printf("%lld\n",res);
    }
    // puts("");
    printf("%lld\n",res);
}