#include<bits/stdc++.h>
using namespace std;
int n,m,p;
int main(){
    scanf("%d%d%d",&n,&m,&p);
	for(int i=1;i<=m;i++){
		int x,y,z;
		scanf("%d%d%d",&x,&y,&z);
	}
	cout<<-1;
    return 0;
}
