#include<bits/stdc++.h>
using namespace std;
bool a[1000000005];
int n,ans1=0,ans2;
int main(){
    scanf("%d",&n);
    int m=n;
    while(m>0){
    	int b=4;
        for(int i=1;i<=n;i++){
            if(a[i]==1){
                continue;
            }
            if(b!=4){
            	b++;
            	continue; 
			}
        	b=2;
            a[i]=1;
            m--;
            if(i==n){
           		ans2=ans1+1;
			}
        }
        ans1++;
    }
    printf("%d %d",ans1,ans2);
    return 0;
}
