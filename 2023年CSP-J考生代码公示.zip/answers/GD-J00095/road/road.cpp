#include<bits/stdc++.h>
using namespace std;
int n,dd;
int a[100005],s[100005],g[100005];
struct info{
	int v,co;
}b[100005];
bool cmp(const info x,const info y){
	return x.co<y.co;
}
int main(){
    scanf("%d%d",&n,&dd);
    for(int i=1;i<n;i++){
    	scanf("%d",&a[i]);
	}
    for(int i=1;i<=n;i++){
    	scanf("%d",&b[i].co);
    	g[i]=b[i].co;
    	b[i].v=i;
	}
	for(int i=2;i<=n;i++){
		s[i]=s[i-1]+a[i-1];
	}
	sort(b+1,b+n+1,cmp);
	int c[100005],d=n,e=0;
	c[++e]=n;
	for(int i=1;i<=n;i++){
		if(b[i].v<d){
			d=b[i].v;
			c[++e]=b[i].v;
		}
	}
	int ans=0,y=0,f=1;
	while(f!=n){
		e--;
		int x=((s[c[e]]-s[f]-y-1)/dd+1);
		ans+=x*g[f];
		y=x*dd-s[c[e]]+s[f]+y;
		f=c[e];
	}
	cout<<ans;
	return 0;
}

