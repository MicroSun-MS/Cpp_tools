#include<bits/stdc++.h>
using namespace std;

int gcd(int x,int y){
	if(y==0) return x;
	return (y,x%y);
}

int main(void){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int a,b,c,n,m,dt;
	
	cin>>n>>m;
	
	for(int i=1;i<=n;i++){
		cin>>a>>b>>c;
		dt = b*b-4*a*c;
		if(dt<0) cout<<"NO"<<endl;
		else{
			if(b==0){
				cout<<"sqrt("<<dt<<")/"<<abs(2*a)<<endl;
			}
			
		}
	}

	
	return 0;
}
