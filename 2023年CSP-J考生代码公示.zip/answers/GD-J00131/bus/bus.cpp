#include<bits/stdc++.h>
using namespace std;

const int N=20003;
vector<int> G[N];
int a[N][N]={0};

int main(void){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,k,p;
	int u,v;
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			a[i][j] = -1;
		}
	}
	for(int i=1;i<=m;i++){
		cin>>u>>v>>p;
		G[u].push_back(v);
		a[u][v] = p;
	}
	cout<<-1<<endl;
	return 0;
}
