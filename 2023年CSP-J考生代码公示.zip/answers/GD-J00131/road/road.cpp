#include<bits/stdc++.h>
using namespace std;

const int k=1003,len=10003;
int a[k]={0};
int f[len][k]={0};
int s[k]={0};
int need[k]={0};

int main(void){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,d,m,v;
	cin>>n>>d;
	for(int i=1;i<=n-1;i++){
		cin>>v;
		s[i] = v+s[i-1];
		if(s[i]%d==0) need[i] = s[i]/d;
		else need[i] = s[i]/d+1;
		cout<<s[i]<<" "<<need[i]<<endl;
	}
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		f[i][0] = k;
		for(int j=i+1;j<=n;j++){
			f[i][j] = k;
		}
	}
	for(int i=1;i<=n-1;i++){
		for(int j=1;j<=i;j++){
			m = need[i]-need[i-1];
			f[i][j] = min(min(f[i][j-1],m*a[j]+f[i-1][j-1]),m*a[j]+f[i-1][j]);
		}
	}
	cout<<f[n-1][n-1];
	return 0;
}
