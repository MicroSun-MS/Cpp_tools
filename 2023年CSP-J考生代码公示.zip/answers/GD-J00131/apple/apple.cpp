#include<bits/stdc++.h>
using namespace std;

const int k=100000001;
int a[k]={0};

int main(void){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n,cnt=0,ans=0,num=1,time,j;
	cin>>n;
	num = n;
	for(int i=1;i<=n;i++) a[i] = 1;
	while (num>0){
		ans++;
		j=2;
		for(int i=1;i<=n;i++){
			if(a[i]){
				if(j==2){
					j = 0;
					a[i]=0;
					num--;
					if(i==n) time=ans;
				}
				else j++;
			}
		}
	}
	cout<<ans<<" "<<time<<endl;
	
	
	return 0;
}
