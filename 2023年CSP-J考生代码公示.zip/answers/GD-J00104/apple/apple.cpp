#include<bits/stdc++.h>
using namespace std;
int n,cnt,ans;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cin>>n;
	while (n){
		++cnt;
		if (n%3==1&&!ans)ans=cnt;
		n-=(n+2)/3;
	}
	cout<<cnt<<' '<<ans;
	return 0;
}
