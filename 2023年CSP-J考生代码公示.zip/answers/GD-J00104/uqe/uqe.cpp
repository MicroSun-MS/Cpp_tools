#include<bits/stdc++.h>
#define int long long
using namespace std;
int T,m,a,b,c; 
int d,fz1,fz2,fm,s,fz,dd;
bool flag=0;
signed main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cin>>T>>m;
	while (T--){
		cin>>a>>b>>c;
		d=b*b-4*a*c;
		if (d<0){
			cout<<"NO\n";
			continue;
		}
		fm=2*a;
		fz1=-b;
		fz2=1;
		int tmp=d;
		for (int i=2;i*i<=tmp;i++){
			while (tmp%(i*i)==0){
				tmp/=i*i;
				fz2*=i;
			}
		}
		if (tmp==1){
			fz=fz1;
			fm=2*a;
			if (a>0)fz+=fz2;
			else fz-=fz2;
			if (fz*fm<0)cout<<'-';
			fz=abs(fz),fm=abs(fm);
			dd=__gcd(fz,fm);
			fz/=dd;
			fm/=dd;
			if (fz==0){
				cout<<0<<'\n';
				continue;
			}
			if (fm==1){
				cout<<fz<<'\n';
				continue;
			}
			cout<<fz<<'/'<<fm<<'\n';
		}
		else{
			flag=0;
			fz=fz1;
			fm=2*a;
			if (fz*fm<0)cout<<'-';
			fz=abs(fz),fm=abs(fm);
			dd=__gcd(fz,fm);
			fz/=dd;
			fm/=dd;
			if (fz==0)flag=true;
			else if (fm==1)
				cout<<fz;
			else{
				cout<<fz<<'/'<<fm;
			}
			
			fz=fz2;
			fm=2*a;
			fz=abs(fz),fm=abs(fm);
			dd=__gcd(fz,fm);
			fz/=dd;
			fm/=dd;
			if (fz==0||tmp==0){
				if (flag)cout<<0;
				cout<<'\n';
				continue;
			}
			if (!flag)cout<<"+";
			if (fz>1)cout<<fz<<"*";
			cout<<"sqrt("<<tmp<<')';
			if (fm>1)cout<<'/'<<fm;
			cout<<'\n';
		}
	}
	return 0;
}
/*
1 0
-2 12 270

*/
