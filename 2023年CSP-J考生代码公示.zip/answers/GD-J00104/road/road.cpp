#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,d,v[100010],c[100010],ans,j=0,tmp,tmpv,lst;
signed main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cin>>n>>d;
	for (int i=2;i<=n;i++)cin>>v[i];
	for (int i=1;i<=n;i++)cin>>c[i];
	lst=1;
	for (int i=2;i<=n;i++){
		while (c[i]>=c[lst]&&i<n)tmpv+=v[i],i++;
		tmpv+=v[i];
		int k=(tmpv-tmp+d-1)/d;
		ans+=c[lst]*k;
		tmp+=k*d;
		lst=i;
	}
	cout<<ans;
	return 0;
}
