#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int u[10010],v[10010],a[10010],d[10010],f[10010][110],maxn,ans=1e9,kd;
bool flag=0;
struct node{
	int x,val;
};
struct node2{
	int y,z;
};
queue<int> q;
queue<node> q2;
vector<node2> G[10010];
signed main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cin>>n>>m>>k;
	for (int i=1;i<=m;i++){
		cin>>u[i]>>v[i]>>a[i];
		maxn=max(maxn,a[i]);
		G[u[i]].push_back(node2{v[i],a[i]});
		if (a[i])flag=1;
	}
	
	if (k==1){
		for (int i=1;i<=n;i++)d[i]=1e9;
		d[1]=0;
		q.push(1);
		while (!q.empty()){
			int now=q.front();
			q.pop();
			for (auto y:G[now]){
				if (d[y.y]>max(d[now],y.z)+1){
					d[y.y]=max(d[now],y.z)+1;
					q.push(y.y);
				}
			}
		}
		if (d[n]==1e9)cout<<-1;
		else cout<<d[n];
		return 0;
	}
	if (n*maxn>=200000000){
		cout<<-1;
		return 0;
	}
	for (int l=0;l<=maxn/k;l++){
		for (int i=1;i<=n;i++)
			for (int j=0;j<=k;j++)f[i][j]=1e9;
		f[1][0]=l*k;
		q2.push(node{1,0});
		while (!q2.empty()){
			node now=q2.front();
			q2.pop();
			for (auto y:G[now.x]){
				if (f[y.y][(now.val+1)%k]>f[now.x][now.val]+1&&f[now.x][now.val]>=y.z){
					f[y.y][(now.val+1)%k]=f[now.x][now.val]+1;
					q2.push({y.y,(now.val+1)%k});
				}
			}
		}
		ans=min(ans,f[n][0]);
	}
	if (ans==1e9)cout<<-1;
	else cout<<ans;
	return 0;
}
/*
5 5 3
1 2 0
2 5 1
1 3 0
3 4 3
4 5 1


*/
