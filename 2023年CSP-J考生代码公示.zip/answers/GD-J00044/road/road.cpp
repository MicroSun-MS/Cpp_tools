#include<iostream>
using namespace std;
const int N=1e5+10; 
int n,d,v[N],a[N],l=0,j,i=1;
long long c=0,x;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=1;i<n;i++){
		cin>>v[i];
	}
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}a[n]=-10000;
	while(i<n){
		j=i+1;
		x=0;
		while(true){
			x+=v[j-1];
			if(a[j]<a[i]){
				break;
			}
			j++;			
		}		
		if((x-l)%d==0){
			c+=a[i]*((x-l)/d);			
			l=0;
		}else{
			c+=a[i]*((x-l)/d+1);			
			l=d-((x-l)%d);
		}
		
		
		i=j;
	}
	cout<<c;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
