#include<bits/stdc++.h>
using namespace std;
int a,b,c,m,t;
void hj(int p,int q){
	int x=p,y=q;
	if(p<0){x=-p;}
	if(q<0){y=-q;}
	for(int i=min(x,y);i>=2;i--){
		if(x%i==0 && y%i==0){
			x/=i;
			y/=i;
		}
	}
	if(y!=1){
		if(p*q<0){
			cout<<'-'<<x<<'/'<<y;
		}else{
			cout<<x<<'/'<<y;
		}
	}else{
		if(p*q<0){
			cout<<-x<<"\n";
		}else{
			cout<<x<<"\n";
		}
	}
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>t>>m;
	for(int i=0;i<t;i++){
		cin>>a>>b>>c;
		double d=b*b-4*a*c;
		if(d<0){
			cout<<"NO\n";
		}else if(c==0){
			if(a*b>=0){
				cout<<0<<"\n";
			}else{
				hj(-b,a);
			}
		}else{
			int x=(-b+sqrt(d))/(2*a);
			cout<<x<<"\n";
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
