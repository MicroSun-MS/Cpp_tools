#include<iostream>
using namespace std;
long long n,s,k,ansn=0;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	for(int i=1;n>0;i++){
		k=n%3; 
		if(k==0){
			n-=n/3; 
		}else{
			n-=n/3+1;
		}s++;
		if(k==1 && !ansn){
			ansn=i;
		} 
	}cout<<s<<' '<<ansn;;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
