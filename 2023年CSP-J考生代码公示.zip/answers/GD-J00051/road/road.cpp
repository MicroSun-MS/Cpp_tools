#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll n,d,t,x=0;
ll v[100005],a[100005],ans;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld%lld",&n,&d);
	for(int i=1;i<=n-1;i++) scanf("%lld",&v[i]);
	for(int i=1;i<=n;i++) scanf("%lld",&a[i]);
	for(int i=1;i<=n-1;i++){
		if(x>=v[i]) x-=v[i];
		else{
			v[i]-=x;
			x=0; 
			if(v[i]%d==0) ans+=(v[i]/d)*a[i];
			else ans+=(v[i]/d+1)*a[i],x+=d-(v[i]%d);
		}
		t=i+1;
		while(a[i]<=a[t]){
			if(x>=v[t]) x-=v[t];
			else{
				v[t]-=x;
				x=0;
				if(v[t]%d==0) ans+=(v[t]/d)*a[i];
				else ans+=(v[t]/d+1)*a[i],x+=d-(v[t]%d);
			}
			t++;
		}
		i=t-1;
	} 
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
