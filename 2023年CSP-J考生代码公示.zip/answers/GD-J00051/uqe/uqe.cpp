#include<bits/stdc++.h>
using namespace std;
double a,b,c;
double x_1,x_2,dta;
#define ll long long
ll t,m,ta,tb,tc,p,tdta;
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>t>>m;
	for(int i=1;i<=t;i++){
		scanf("%lf%lf%lf",&a,&b,&c);
		ta=a,tb=b,tc=c;
		dta=b*b-4*a*c;
		tdta=dta;
		if(dta<0){
			cout<<"NO"<<endl;
			continue;
		}
		else{
			x_1=(-b+sqrt(dta))/(2*a);
			x_2=(-b-sqrt(dta))/(2*a);
			if(x_1>=x_2){
				if(abs(x_1)-abs(int(x_1))<0.000000000001) cout<<x_1<<endl;
				else{
					if(abs(-b+sqrt(dta))-abs(int(-b+sqrt(dta)))<0.0000000001){
						if(2*a/__gcd(-tb+int(sqrt(dta)),2*ta)<0&&(-b+sqrt(dta))/__gcd(-tb+int(sqrt(dta)),2*ta)<0) cout<<abs((-b+sqrt(dta))/__gcd(-tb+int(sqrt(dta)),2*ta))<<"/"<<abs(2*a/__gcd(-tb+int(sqrt(dta)),2*ta))<<endl;
						else if(2*a/__gcd(-tb+int(sqrt(dta)),2*ta)<0) cout<<"-"<<(-b+sqrt(dta))/__gcd(-tb+int(sqrt(dta)),2*ta)<<"/"<<abs(2*a/__gcd(-tb+int(sqrt(dta)),2*ta))<<endl;
						else cout<<(-b+sqrt(dta))/__gcd(-tb+int(sqrt(dta)),2*ta)<<"/"<<2*a/__gcd(-tb+int(sqrt(dta)),2*ta)<<endl;
					}
					else{
						if(b/(2*a)!=0){
							if(-tb%(2*ta)==0) cout<<-tb/(2*ta)<<"+";
							else{
								if(((2*ta)/__gcd(-tb,2*ta))<0&&(-tb/__gcd(-tb,2*ta))<0) cout<<abs(-tb/__gcd(-tb,2*ta))<<"/"<<abs((2*ta)/__gcd(-tb,2*ta))<<"+";
								else if(((2*ta)/__gcd(-tb,2*ta))<0) cout<<"-"<<(-tb/__gcd(-tb,2*ta))<<"/"<<abs((2*ta)/__gcd(-tb,2*ta))<<"+";
								else cout<<(-tb/__gcd(-tb,2*ta))<<"/"<<(2*ta)/__gcd(-tb,2*ta)<<"+";
							}
						}
						if(sqrt(dta)-int(sqrt(dta))<0.0000000001){
							if(int(sqrt(dta))%(2*ta)==0) cout<<int(sqrt(dta))/(2*ta)<<endl;
							else cout<<sqrt(dta)/__gcd(int(sqrt(tdta))*1LL,2*ta)<<"/"<<(2*ta)/__gcd(int(sqrt(tdta))*1LL,2*ta)<<endl; 
						}
						else{
							for(int j=dta-1;j>=1;j--){
								if(tdta%j==0){
									if(sqrt(j)-int(sqrt(j))<0.0000000001){
										p=j;
										break;
									}
								}
							}
							dta=dta/p;
							p=sqrt(p);
							if(p!=1){
								if(p%(2*ta)==0){
									if(abs(p/(2*ta))==1) cout<<"sqrt("<<dta<<")"<<endl;
									else cout<<abs(p/(2*ta))<<"*sqrt("<<dta<<")"<<endl;
								}
								else{
									if(abs(p/__gcd(p,2*ta))==1) cout<<"sqrt("<<dta<<")"<<"/"<<abs(2*a/__gcd(2*ta,p))<<endl;
									else cout<<abs(p/__gcd(p,2*ta))<<"*sqrt("<<dta<<")"<<"/"<<abs(2*a/__gcd(2*ta,p))<<endl;
								}
							}
							else{
								cout<<"sqrt("<<dta<<")"<<"/"<<abs(2*a)<<endl;
							}
						}
					}
				} 
			}
			else{
				if(abs(x_2)-abs(int(x_2))<0.000000000001) cout<<x_2<<endl;
				else{
					if(abs(-b-sqrt(dta))-abs(int(-b-sqrt(dta)))<0.0000000001){
						if(2*a/__gcd(-tb-int(sqrt(dta)),2*ta)<0&&(-b-sqrt(dta))/__gcd(-tb-int(sqrt(dta)),2*ta)<0) cout<<abs((-b-sqrt(dta))/__gcd(-tb-int(sqrt(dta)),2*ta))<<"/"<<abs(2*a/__gcd(-tb-int(sqrt(dta)),2*ta))<<endl;
						else if(2*a/__gcd(-tb-int(sqrt(dta)),2*ta)<0) cout<<"-"<<(-b-sqrt(dta))/__gcd(-tb-int(sqrt(dta)),2*ta)<<"/"<<abs(2*a/__gcd(-tb-int(sqrt(dta)),2*ta))<<endl;
						else cout<<(-b-sqrt(dta))/__gcd(-tb-int(sqrt(dta)),2*ta)<<"/"<<2*a/__gcd(-tb-int(sqrt(dta)),2*ta)<<endl;
					}
					else{
						if(b/(2*a)!=0){
							if(-tb%(2*ta)==0) cout<<-tb/(2*ta)<<"+";
							else{
								if(((2*ta)/__gcd(-tb,2*ta))<0&&(-tb/__gcd(-tb,2*ta))<0) cout<<abs(-tb/__gcd(-tb,2*ta))<<"/"<<abs((2*ta)/__gcd(-tb,2*ta))<<"+";
								else if(((2*ta)/__gcd(-tb,2*ta))<0) cout<<"-"<<(-tb/__gcd(-tb,2*ta))<<"/"<<abs((2*ta)/__gcd(-tb,2*ta))<<"+";
								else cout<<(-tb/__gcd(-tb,2*ta))<<"/"<<(2*ta)/__gcd(-tb,2*ta)<<"+";
							}
						}
						if(sqrt(dta)-int(sqrt(dta))<0.0000000001){
							if(int(sqrt(dta))%(2*ta)==0) cout<<int(sqrt(dta))/(2*ta)<<endl;
							else cout<<sqrt(dta)/__gcd(int(sqrt(tdta))*1LL,2*ta)<<"/"<<(2*ta)/__gcd(int(sqrt(tdta))*1LL,2*ta)<<endl; 
						}
						else{
							for(int j=dta-1;j>=1;j--){
								if(tdta%j==0){
									if(sqrt(j)-int(sqrt(j))<0.0000000001){
										p=j;
										break;
									}
								}
							}
							dta=dta/p;
							p=sqrt(p);
							if(p!=1){
								if(p%(2*ta)==0){
									if(abs(p/(2*ta))==1) cout<<"sqrt("<<dta<<")"<<endl;
									else cout<<abs(p/(2*ta))<<"*sqrt("<<dta<<")"<<endl;
								}
								else{
									if(abs(p/__gcd(p,2*ta))==1) cout<<"sqrt("<<dta<<")"<<"/"<<abs(2*a/__gcd(2*ta,p))<<endl;
									else cout<<abs(p/__gcd(p,2*ta))<<"*sqrt("<<dta<<")"<<"/"<<abs(2*a/__gcd(2*ta,p))<<endl;
								}
							}
							else{
								cout<<"sqrt("<<dta<<")"<<"/"<<abs(2*a)<<endl;
							}
						}
					}
				} 
			} 
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
