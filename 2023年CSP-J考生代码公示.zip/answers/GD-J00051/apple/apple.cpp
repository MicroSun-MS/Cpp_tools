#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll n,ans,anss,t,x,cnt;
int bz[1000005],flag;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	if(n<=1000000){
		x=1;
		while(1){
			if(bz[x]){
				x++;
			}
			else{
				cnt++;
				if(cnt==3){
					flag=1;
					bz[x]=t;
					cnt=0;
				}
				x++;
			}
			if(x>n){
				if(flag==0) break;
				flag=0;
				x=1,t++;
				cnt=2;
			}
		}
		ans=bz[n];
		while(n!=0){
			if(n%3==0) t=n/3,anss++;
			else t=n/3+1,anss++;
			n-=t;
		}
		cout<<anss<<" "<<ans<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
