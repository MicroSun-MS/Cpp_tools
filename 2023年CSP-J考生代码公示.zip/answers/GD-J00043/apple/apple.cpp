#include<bits/stdc++.h>
using namespace std;

bool f=1;
int n, m, s;

int main()
{
	freopen("apple.in", "r", stdin);
	freopen("apple.out", "w", stdout);
	cin>>n;
	for(; n>0; m++)
	{
		if(f&&n%3==1) s=m+1, f=0;
		if(n<3) n--;
		else n=n-(n+2)/3;
	}	
	cout<<m<<" "<<s;
	return 0;
} 
