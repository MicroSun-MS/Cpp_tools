#include<bits/stdc++.h>
using namespace std;

bool f;
int t, m, a, b, c, d;

int main()
{
	freopen("uqe.in", "r", stdin);
	freopen("uqe.out", "w", stdout);
	cin>>t>>m;	
	for(; t--; )
	{
		scanf("%d %d %d", &a, &b, &c);
		d=int(b*b-4*a*c), f=0;
		if(d<0)
		{
			printf("NO\n");
			continue;
		}
		for(int i=1; i<=sqrt(d); i++)
			if(i*i==d)
			{
				f=1;
				break;
			}
		if(f)
		{
			if(a>0)
			{
				if((-b+sqrt(d))%2==0) cout<<(-b+sqrt(d))/(2*a)<<endl;
				else cout<<(-b+sqrt(d))<<"/"<<(2*a)<<endl;
			}
			else
			{
				if((-b-sqrt(d))%(2*a)==0) cout<<(-b+sqrt(d))/(2*a)<<endl;
				else cout<<(-b+sqrt(d))<<"/"<<(2*a)<<endl;
			}
		}
	}
	return 0;
} 
