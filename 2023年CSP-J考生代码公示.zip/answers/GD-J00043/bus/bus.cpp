#include<bits/stdc++.h>
using namespace std;

int n, m, k, s=1e9;
struct mf
{
	int x, y, z, l;
} a[20009], b[20009];
struct qd
{
	int l[20009], ll[20009], t;
} li[10009];
bool cmp(mf o, mf p)
{
	return o.x<p.x;
}

int main()
{
	freopen("bus.in", "r", stdin);
	freopen("bus.out", "w", stdout);
	cin>>n>>m>>k;	
	for(int i=1; i<=m; i++)
	{
		scanf("%d %d %d", &a[i].x, &a[i].y, &a[i].z);
		li[a[i].x].l[++li[a[i].x].t]=a[i].y;
		li[a[i].x].ll[li[a[i].x].t]=a[i].z;
	}
	sort(a+1, a+1+m, cmp);
	int l=1, r=1;
	b[1].x=a[1].x, b[1].y=a[1].y, b[1].z=a[1].z, b[1].l=0;
	for(; l<=r; l++)
	{
		for(int i=1; i<=li[b[l].x].t; i++)
		{
			if(b[l].x!=n)
			{
				r++;
				b[r].x=b[l].y;
				b[r].y=li[b[r].x].l[i];
				b[r].z=max(b[l].z+1, li[b[l].x].ll[i]);
				b[r].l=b[l].l+1;
			}
			if(b[l].x==n&&b[l].l%k==0) s=min(s, b[l].z);
		}
	}
	if(s==1e9) s=-1;
	cout<<s;
	return 0;
} 
