#include<bits/stdc++.h>
using namespace std;

int n, d, m, s, t;
int a[100009], b[100009];

int main()
{
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	cin>>n>>d;
	for(int i=1; i<n; i++)
		scanf("%d", &a[i]);
	for(int i=1; i<=n; i++)
		scanf("%d", &b[i]);
	for(int i=1; i<n; i++)
	{
		if(i<t) continue;
		if(b[i]>b[i+1])
		{
			if(m<a[i])
			{
				s+=(a[i]-m+d-1)/d*b[i];
				m=(a[i]-m+d-1)/d*d-a[i]+m;
			}
		}
		else
		{
			int k=a[i];
			for(t=i+1; b[i]<b[t]; t++)
			{
				k+=a[t];
			}
			if(m<k)
			{
				s+=(k-m+d-1)/d*b[i];
				m=(k-m+d-1)/d*d-k+m;
			}
		}
	}
	cout<<s;
	return 0;
}
