#include<bits/stdc++.h>
using namespace std;
long long n,d,v[100005],a[100005],ym=1000005,ans,sum;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=1;i<=n-1;i++)
	{
		cin>>v[i];
	}
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=n-1;i++)
	{
		ym=min(ym,a[i]);
		if((v[i]-sum)%d==0)
		{
			ans+=(v[i]-sum)/d*ym;
			sum=0;
		}
		else
		{
			ans+=(floor((v[i]-sum)/d)+1)*ym;
			sum=(floor((v[i]-sum)/d)+1)*d-v[i];
		}
	}
	cout<<ans;
	return 0;
}

