#include<bits/stdc++.h>
using namespace std;
long long n,t=1,cnt,a[10005],sum,ans;
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		a[i]=i;
	}
	for(int i=1;;i++)
	{
		if(cnt==n)
		{
			break;
		}
		if(t<=n)
		{
			if(a[t]==n)
			{
				ans=sum+1; 
			}
			//cout<<a[t]<<"  &  "<<sum<<endl;
			a[t]=0;
			cnt++;
			do
			{
				t++;
			}while(a[t]==0&&t<=n);
			do
			{
				t++;
			}while(a[t]==0&&t<=n);
			do
			{
				t++;
			}while(a[t]==0&&t<=n);
		}
		if(t>n)
		{
			sum++;
			t=1;
			while(a[t]==0)
			{
				t++;
			}
		}
	}
	cout<<sum<<" "<<ans;
	return 0;
}

