#include<bits/stdc++.h>
using namespace std;
int t,m,a,b,c,san,v1,v2,x,p;
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>t>>m;
	for(int i=1;i<=t;i++)
	{
		scanf("%lld%lld%lld",&a,&b,&c);
		san=b*b-4*a*c;
		if(san<0)
		{
			printf("NO\n");
			continue;
		}
		v1=(b*(-1)+sqrt(san))/(2*a);
		v2=(b*(-1)-sqrt(san))/(2*a);
		x=max(v1,v2);
		for(int q=1;;q++)
		{
			p=x*q;
			if(__gcd(p,q)==1)
			{
				if(q==1)
				{
					printf("%lld\n",p);
					continue;
				}
				else
				{
					printf("%lld/%lld\n",p,q);
					continue;
				}
			}
		}
	}
	
	return 0;
}

