#include<bits/stdc++.h>
using namespace std;
int n;
int ans,tot=0;
bool flag=0;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	while(n>0){
		tot++;
		if((n-1)%3==0&&!flag){
			ans=tot;
			flag=1;
		}
		n-=(n-1)/3+1;
	}
	cout<<tot<<' '<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
