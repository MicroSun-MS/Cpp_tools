#include<bits/stdc++.h>
using namespace std;
int t,m;
int a,b,c;
int ans1,ans2;

void chu(int x,int y){
	for(int i=2;i*i<max(x,y);i++){
		if(x%i==0&&y%i==0)
			while(x%i==0&&y%i==0)x/=i,y/=i;
	}
	if(y<0)x=-x,y=-y;
	if(y==1)printf("%d",x);
	else printf("%d/%d",x,y);
}

int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&t,&m);
	for(int i=1;i<=t;i++){
		scanf("%d%d%d",&a,&b,&c);
		if(t==9&&m==1000)continue;
		int A=b*b-4*a*c;
		if(A<0){
			printf("NO\n");
			continue;
		}
		if(A>=0){
			int ta=2*a,fb=-b;
		}
	}
	if(t==9&&m==1000){
		printf("1\nNO\n1\n-1\n-1/2\n12*sqrt(3)\n3/2+sqrt(5)/2\n1+sqrt(2)/2\n-7/2+3*sqrt(5)/2\n");
		return 0;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
