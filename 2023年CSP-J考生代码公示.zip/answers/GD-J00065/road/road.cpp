#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=2e5+7;
ll n,d;
ll v[N],a[N];
ll minn=N,now,ans;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld%lld",&n,&d);
	for(int i=1;i<n;i++)
		scanf("%lld",&v[i]);
	for(int i=1;i<n;i++)
		scanf("%lld",&a[i]);	
	for(int i=1;i<n;i++){
		minn=min(minn,a[i]);
		now-=v[i];
		if(now<0){
			int jl=abs(now);
			if(jl%d==0){
				now+=jl;
				ans+=jl/d*minn;
			}
			else {
				now+=(jl/d+1)*d;
				ans+=(jl/d+1)*minn;
			}
		}
	}
	printf("%lld",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
