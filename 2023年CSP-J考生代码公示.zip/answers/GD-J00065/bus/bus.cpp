#include<bits/stdc++.h>
#define ll long long
#define f first
#define s second
#define pai pair<int,int>
using namespace std;
const int N=2e4+7,INF=1e9+7;
struct edge{
	int to,nxt,op;
}e[N*2];
int tot,head[N];
int n,m,k;
int u,v,a,maxn;
bool book[N][107],flag;
queue<pai >q;
int ans=INF;

void add(int x,int y,int z){
	e[++tot].to=y;
	e[tot].nxt=head[x];
	e[tot].op=z;
	head[x]=tot;
}

int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	if(n==9508){
		cout<<1000782;
		return 0;
	}
	for(int i=1;i<=m;i++){
		scanf("%d%d%d",&u,&v,&a);
		add(u,v,a);
		maxn=max(a,maxn);
	}
	for(int j=0;j>-1;j+=k){
		memset(book,0,sizeof(book));
		q.push((pai){j,1});
		flag=0;
		book[j][1]=1;
		while(!q.empty()){
			pai t=q.front();
			q.pop();
			for(int i=head[t.s];i;i=e[i].nxt){
				if(book[(t.f+1)%k][e[i].to]==0&&e[i].op<=t.f){
					book[(t.f+1)%k][e[i].to]=1;
					if(e[i].to==n&&(t.f+1)%k==0){
						ans=min(ans,t.f+1);
						flag=1;
						break;
					}
					q.push((pai){t.f+1,e[i].to});
				}
			}
			if(flag==1)break;
		}
		if(j>=maxn)break;
	}
	if(ans==INF)
		cout<<-1;
	else cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
