#include<bits/stdc++.h>
using namespace std;
int s,n,d,l[10001],price[10001];
int main(){
	cin>>n>>d;
	for(int i=1;i<n;i++){
		cin>>l[i];
		s+=l[i];
	}
	for(int i=1;i<=n;i++){
		cin>>price[i];
	}
	cout<<s/d*price[1];
}
