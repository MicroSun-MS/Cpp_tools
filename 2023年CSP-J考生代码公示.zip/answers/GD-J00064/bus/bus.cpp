#include<bits/stdc++.h>
using namespace std;
int t=0,n,m,k,r[1005][5],p[1001],;
void trip(a){
	
	if(p[a]==0){
		for(int i=1;i<=m;i++){
			if(r[i][1]==a&&t>=r[i][3]){
				p[a]==1;
				t++;
				trip(r[i][2]);
			}
			if(a==n&&t%k==0){
				cout<<t;
				return;
			}
		}
		p[a]=0
	}
}
int main(){
	cin>>n>>m>>k;
	for(int i=1;i<m;i++){
		cin>>r[i][1]>>r[i][2]>>r[i][3];
	}
}
