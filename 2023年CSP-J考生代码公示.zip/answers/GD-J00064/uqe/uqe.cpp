#include<bits/stdc++.h>
using namespace std;
int a,b,c,t,m,p,q;
float jga,jgb;
int main(){
	cin>>t>>m;
	for(int i=1;i<=t;i++){
		cin>>a>>b>>c;
		if(b*b-4*a*c<0){
			cout<<"NO"<<endl;
		}else{
			if((((-1*b+sqrt(b*b-4*a*c))/2/a)%1)==0){
				if((-1*b+sqrt(b*b-4*a*c)/2/a)>(-1*b-sqrt(b*b-4*a*c))/2/a){
					cout<<-1*b+sqrt(b*b-4*a*c)/2/a;
				}else{
					cout<<-1*b-sqrt(b*b-4*a*c)/2/a;
				}
			}
			
		}
	}
	return 0;
}
