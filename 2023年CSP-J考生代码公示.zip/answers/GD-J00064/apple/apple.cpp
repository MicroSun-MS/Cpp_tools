#include<bits/stdc++.h>
using namespace std; 
int n,m=0,o,days=1;
bool f=1,l=1;
int main(){
	//freopen('r','',"apple.in");
//	freopen('w','',"apple.out");
	cin>>n;
	int a[n];
	for(int i=0;i<n;i++){
		a[i]=1;
	}
	while(l){
		l=0;
		for(int i=0;i<n;i++){
			if(a[i]==1&&f){
				a[i]=0;
				f=0;
			//	cout<<a[i]<<" ";
			}else if(a[i]==1&&m==2){
				a[i]=0;
				m=0;
			//	cout<<a[i]<<" ";
				if(i==(n-1)) o=days;  
			}else if(a[i]==1){
				m++;
			}
			if(a[i]==1) l=1;
			
		}
		//cout<<endl;
		f=1;
		days++;
	}
	cout<<days<<' '<<o<<endl;
	return 0;
}
