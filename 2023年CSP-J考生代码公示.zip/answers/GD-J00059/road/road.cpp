// 25 road - AlanTaki ^ Minna
// love xiami forever
#include <bits/stdc++.h>
using namespace std;
long long ans, minn = 1e6;
int n, d, y;
int v[100005], a[100005], s[100005];
int main () {
	freopen ("road.in", "r", stdin);
	freopen ("road.out", "w", stdout);
	scanf ("%d %d", &n, &d);
	for (int i = 1; i <= n - 1; i++) {
		scanf ("%d", &v[i]);
		s[i] = v[i] + s[i - 1];
	}
	for (int i = 1; i <= n; i++) {
		scanf ("%d", &a[i]);
	}
	int pos = n;
	for (int i = 1; i < n - 1;) {
		for (int j = i; j <= n - 1; j++) {
			if (a[j] < a[i]) {
				pos = j;
				break;
			}
		}
		long long dis = s[pos - 1] - s[i - 1];
		int pr = 0;
		if ((dis - y) % d == 0) {
			pr = (dis - y) / d;
		}
		else {
			pr = (dis - y) / d + 1;
		}
		y += pr * d;
		ans += pr * a[i];
		y -= dis;
//		cout << i << '=' << ans << ' ';
		i = pos;
	}
//	cout << pos << "\n";
	long long dis = s[n - 1] - s[pos - 1];
	int pr = 0;
	if ((dis - y) % d == 0) {
		pr = (dis - y) / d;
	}
	else {
		pr = (dis - y) / d + 1;
	}
	y += pr * d;
	ans += pr * a[pos];
	printf ("%lld", ans);
	return 0;
}
