// 30 bus - AlanTaki ^ Minna
// love xiami forever 
#include <bits/stdc++.h>
using namespace std;
int n, m, k, ans = 1e8;
int adj[10005][10005];

void dfs (int t, int node) {
//	cout << t << ' ' << node << "\n";
	if (node == n) {
		if (t % k != 0) {t /= k; t *= k; t += k;} 
		ans = min (ans, t);
		return ;
	}
	for (int i = 1; i <= n; i++) {
		if (adj[node][i] == 1) {
			dfs (t + 1, i);
		}
	}
}

int main () {
	freopen ("bus.in", "r", stdin);
	freopen ("bus.out", "w", stdout); 
	cin >> n >> m >> k;
	for (int i = 1; i <= m; i++) {
		int u, v, a;
		cin >> u >> v >> a;
		adj[u][v] = 1;
	}
//	for (int i = 1; i <= n; i++) {
//		for (int j = 1; j <= n; j++) {
//			cout << adj[i][j] << ' ';
//		}
//		cout << "\n";
//	}
	dfs (0, 1);
	cout << ans << "\n";
	return 0;
}
