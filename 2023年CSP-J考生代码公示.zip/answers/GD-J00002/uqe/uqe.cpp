//-------------------------------RP++-------------------------------
//�����������ˣ��ɶ�Ĵ�Ĥ�� �� 
//upd:11:45 ���ˡ� 
#include<cstdio>
#include<cmath>
using namespace std;
int t,m;
int a,b,c;
int issq(int);
int gcd(int,int);
void opyl(int,int);
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&t,&m);
	while(t--){
		scanf("%d%d%d",&a,&b,&c);
		int k=b*b-4*a*c;
		if(k<0){
			printf("NO\n");
			continue;
		}
		if(issq(k)!=-1){
			if(a>0)
				opyl(-b+sqrt(k),2*a);
			else
				opyl(-b-sqrt(k),2*a);
		}else{
			if(b!=0){
				opyl(-b,2*a);
				putchar('+');
			}
			if(a>0){
				int q2=1,q3=2*a;
				int kk=sqrt(k);
				for(int i=2;i<=kk;++i){
					while(k%(i*i)==0)
						k/=(i*i),q2*=i;
				}
				int gcdoo=gcd(q2,q3);
				q2/=gcdoo;
				q3/=gcdoo;
				if(q2<0){
					q2=-q2;
				}
				if(q2!=1)
					printf("%d*",q2);
				printf("sqrt(%d)",k);
				if(q3!=1)
					printf("/%d",q3);
			}else{
				a=-a;
				int q2=1,q3=2*a;
				int kk=sqrt(k);
				for(int i=2;i<=kk;++i){
					while(k%(i*i)==0)
						k/=(i*i),q2*=i;
				}
				int gcdoo=gcd(q2,q3);
				q2/=gcdoo;
				q3/=gcdoo;
				if(q2<0){
					q2=-q2;
				}
				if(q2!=1)
					printf("%d*",q2);
				printf("sqrt(%d)",k);
				if(q3!=1)
					printf("/%d",q3);
			}
		}
		putchar('\n');
	}
}
void opyl(int a,int b){
	int k=gcd(a,b);
	a/=k;
	b/=k;
	if(b<0&&a>0)
		b=-b,a=-a;
	if(b==1)
		printf("%d",a);
	else
		printf("%d/%d",a,b);
}
int issq(int n){
	int k=sqrt(n);
	if(k*k==n)
		return k;
	return -1;
}
int gcd(int a,int b){
	if(a%b==0)
		return b;
	return gcd(b,a%b);
}
/*
9 1000
1 -1 0
-1 -1 -1
1 -2 1
1 5 4
4 4 1
1 0 -432
1 -3 1
2 -4 1
1 7 1

*/
/*
5000 1000
-3 -18 54 

*/ 
