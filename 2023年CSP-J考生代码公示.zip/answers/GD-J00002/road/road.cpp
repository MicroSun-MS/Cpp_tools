//-------------------------------RP++-------------------------------
//�����������ˣ�������֡� 
//upd:11:01,���������ˣ����L21 
#include<cstdio>
#define int long long
using namespace std;
int n,o,d,ans,last=1;
int v[100002],a[100002],s[100002];
signed main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld%lld",&n,&d);
	for(int i=2;i<=n;++i){
		scanf("%lld",v+i);
		s[i]=s[i-1]+v[i];
	}
	for(int i=1;i<=n;++i){
		scanf("%lld",a+i);
	}
	a[n+1]=0x7fffffff;
	a[n]=-1;
	for(int i=2;i<=n;++i){
		if(a[i]<a[last]){
			int k=(s[i]-s[last]-o+(d-1))/d;
			ans+=k*a[last];
			o=k*d+o-(s[i]-s[last]);
			last=i;
		}
	}
	printf("%lld\n",ans);
}
/*
5 4
10 10 10 10
9 8 9 6 5

*/
