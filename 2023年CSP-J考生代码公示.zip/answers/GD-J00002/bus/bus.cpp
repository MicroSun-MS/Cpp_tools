//-------------------------------RP++-------------------------------
#include<cstdio>
#include<queue>
#include<cstring>
#define int long long
using namespace std;
struct dd{
	int pos,t;
};
int n,m,k;
vector<int> g[10002];
queue<dd> q;
int vis[10002];
void bfs();
signed main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	for(int i=1;i<=m;++i){
		int u,v,a;
		scanf("%lld%lld%lld",&u,&v,&a);
		g[u].push_back(v);
	}
	bfs();
	printf("%lld",(vis[n]+k-1)/k);
}
void bfs(){
	memset(vis,0x7f,sizeof(vis));
	q.push((dd){1,0});
	vis[1]=0;
	while(!q.empty()){
		dd f=q.front();
		q.pop();
		int u=f.pos;
		for(int i=0;i<g[u].size();++i){
			int v=g[u][i];
			if(vis[v]>f.t+1){
				vis[v]=vis[u]+1;
				q.push({v,vis[v]});
			}
		}
	}
}
/*
5 5 2
1 3 0
3 4 0
4 5 0
1 2 0
2 5 0

*/
