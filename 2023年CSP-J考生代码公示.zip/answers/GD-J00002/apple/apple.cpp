//-------------------------------RP++-------------------------------
#include<cstdio>
#define int long long
using namespace std;
int n,ans1,ans2=-1;
bool b=0;
signed  main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%lld",&n);
	while(n){
		++ans1;
		if(n%3==1&&!b){
			b=1;
			ans2=ans1;
		}
		n-=(n+2)/3;
	}
	if(!b)
		ans2=ans1;
	printf("%lld %lld\n",ans1,ans2);
}
