#include<bits/stdc++.h>
using namespace std;
int n,m,v[100010],a[100010],oil,minn=INT_MAX,k;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;i++)scanf("%d",v+i);
	for(int i=1;i<=n;i++)scanf("%d",a+i);
	for(int i=1;i<=n;i++){
		minn=min(minn,a[i]);
		if(oil>=v[i])oil-=v[i];
		else k+=minn*((v[i]-oil)/m+((v[i]-oil)%m>0)),oil+=((v[i]-oil)/m+((v[i]-oil)%m>0))*m-v[i];
	}
	printf("%d",k);
	return 0;
} 
