#include<bits/stdc++.h>
using namespace std;
int n,m,k,i;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);
	while(n>0){
		i++;
		if(n%3==1&&k==0)k=1,m=i;
		n=n-(n-1)/3-1;
	} 
	printf("%d %d",i,m);
	return 0;
} 
