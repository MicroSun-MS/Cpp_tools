#include<bits/stdc++.h>
using namespace std;
int ans[200010],t,ti[200010],nxt[200010],to[200010],h[200010],n,m,k,u=0x3f3f3f3f;
queue<int>q;
void add(int x,int y,int z){
	nxt[++t]=h[x];
	h[x]=t;
	to[t]=y;
	ti[t]=z;
}
int main(){
	freopen("bus1.in","r",stdin);
	freopen("bus1.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1,x,y,z;i<=m;i++)
		scanf("%d%d%d",&x,&y,&z),
			add(x,y,z);
	q.push(1);
	memset(ans,0x3f3f3f3f,sizeof ans);
	ans[1]=0;
	while(!q.empty()){
		int x=q.front();
		q.pop();
		for(int i=h[x];i;i=nxt[i]){
			if(to[i]==n){
				if(ti[i]<=ans[x])ans[to[i]]=ans[x]+1,q.push(to[i]);
				else ans[to[i]]=ans[x]+((ti[i]-ans[x])/3+((ti[i]-ans[x])%3>0))*3+1,q.push(to[i]);
				if(ans[n]%k==0)u=min(u,ans[n]);
			}
			else if(ti[i]<=ans[x]){if(ans[to[i]]+k>ans[x]+1)ans[to[i]]=ans[x]+1,q.push(to[i]);}
			else if(ans[to[i]]+k>ans[x]+((ti[i]-ans[x])/3+((ti[i]-ans[x])%3>0))*3+1)ans[to[i]]=ans[x]+((ti[i]-ans[x])/3+((ti[i]-ans[x])%3>0))*3+1,q.push(to[i]);
		}
	}
	if(u!=0x3f3f3f3f)printf("%d",u);
	else printf("-1");
	return 0;
} 
