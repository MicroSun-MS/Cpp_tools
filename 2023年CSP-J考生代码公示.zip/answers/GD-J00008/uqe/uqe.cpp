#include<bits/stdc++.h>
using namespace std;
long long T,a,b,c,m;
namespace fenshu{
	long long sqrt(long long k){
		long long l=1,r=k;
		while(l<r){
			long long mid=(l+r)>>1;
			if(mid*mid==k)return mid;
			if(mid*mid>k)r=mid;
			else l=mid+1;
		}
		return l;
	}
	struct fs{
		long long fm,fz;
		friend bool operator < (fs a,fs b){
			return a.fz*1.0/a.fm<b.fz*1.0/b.fm;
		}
		void Int(long long u){
			fz=u,fm=1;
			return;
		}
		friend fs operator * (fs a,fs b){
			fs c;
			c.fm=a.fm*b.fm;
			c.fz=a.fz*b.fz;
			long long l=__gcd(c.fm,c.fz);
			c.fm/=l;
			c.fz/=l;
			return c;
		}
		friend fs operator + (fs a,fs b){
			long long l=a.fm*b.fm/__gcd(a.fm,b.fm);
			fs aa=a,bb=b,c;
			aa.fz*=l/aa.fm,bb.fz*=l/bb.fm;
			c.fz=aa.fz+bb.fz;
			c.fm=l;
			l=__gcd(c.fm,c.fz);
			c.fm/=l;
			c.fz/=l;
			return c;
		}
		void read(){
			scanf("%lld",&fz);
			fm=1;
		}
		bool _sqrt(){
			return fenshu::sqrt(fz)*fenshu::sqrt(fz)==fz&&fenshu::sqrt(fm)*fenshu::sqrt(fm)==fm;
		}
		fs sqrt(){
			fs a;
			a.fz=fenshu::sqrt(fz),a.fm=fenshu::sqrt(fm);
			return a;
		}
		void yf(){
			long long l=__gcd(fm,fz);
			fm/=l;
			fz/=l;
			if(fm<0)fm=-fm,fz=-fz;
		}
		void output(){
			if(fm==1)printf("%lld",fz);
			else printf("%lld/%lld",fz,fm);
		}
	};
	long long fj(long long u){
		long long l=1,o=1,p=u;
		for(long long i=2;i<=fenshu::sqrt(p);i++){
			o=1;
			while(p%i==0)p/=i,o=!o;
			if(!o)l*=i;
		}
		if(p>0)l*=p;
		return l;
	}
}
using namespace fenshu;
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%lld%lld",&T,&m);
	while(T--){
		scanf("%lld%lld%lld",&a,&b,&c);
		if(b==0&&c==0){
			printf("0\n");
			continue;
		}
		if(c==0){
			if(b*a>0)printf("0\n");
			else{
				fs f;
				f.fz=-b,f.fm=a;
				f.yf();
				f.output();
				printf("\n");
			}
			continue;
		}
		if(b==0){
			if(c*a>0){
				printf("NO\n");
				continue;
			}
			fs f;
			f.fm=a;
			f.fz=-c;
			f.yf();
			if(f._sqrt())f=f.sqrt(),f.output(),printf("\n");
			else if(fenshu::sqrt(f.fm)*fenshu::sqrt(f.fm)==f.fm){
				long long y=fj(f.fz);
				if(y==f.fz){
					if(f.fm==1){
						if(y==1)printf("1\n");
						else printf("sqrt(%lld)\n",f.fz);
					}
					else if(y==1)printf("1/%lld",fenshu::sqrt(f.fm));
					else printf("sqrt(%lld)/%lld\n",f.fz,fenshu::sqrt(f.fm));
				}
				else{
					if(f.fm==1){
						if(y==1)printf("%lld\n",fenshu::sqrt(f.fz/y));
						else printf("%lld*sqrt(%lld)\n",fenshu::sqrt(f.fz/y),y);
					}
					else if(y==1)printf("%lld/%lld",fenshu::sqrt(f.fz/y),fenshu::sqrt(f.fm));
					else printf("%lld*sqrt(%lld)/%lld\n",fenshu::sqrt(f.fz/y),y,fenshu::sqrt(f.fm));
				}
			}
			else{
				long long y=fj(f.fm);
				f.fz*=y;
				f.fm*=y;
				y=fj(f.fz);
				if(y==f.fz){
					if(f.fm==1){
						if(f.fz==1)printf("1\n");
						else printf("sqrt(%lld)\n",f.fz);
					}
					else if(f.fz>1)printf("sqrt(%lld)/%lld\n",f.fz,fenshu::sqrt(f.fm));
					else printf("1/%lld\n",fenshu::sqrt(f.fm));
				}
				else{
					if(f.fm==1){
						if(y==1)printf("%lld\n",fenshu::sqrt(f.fz/y));
						else printf("%lld*sqrt(%lld)\n",fenshu::sqrt(f.fz/y),y);
					}
					else if(y==1)printf("%lld/%lld",fenshu::sqrt(f.fz/y),fenshu::sqrt(f.fm));
					else printf("%lld*sqrt(%lld)/%lld\n",fenshu::sqrt(f.fz/y),y,fenshu::sqrt(f.fm));
				}
			}
			continue;
		}
		if(b*b-4*a*c<0){
			printf("NO\n");
			continue;
		}
		else if(b*b==4*a*c){
			fs f;
			f.fm=2*a;
			f.fz=-b;
			f.yf();
			f.output();
			printf("\n");
		}
		else{
			fs f1,f2;
			f1.fm=2*a;
			f1.fz=-b;
			f1.yf();
			long long dt=b*b-4*a*c;
			if(fenshu::sqrt(dt)*fenshu::sqrt(dt)==dt){
				f2.fz=fenshu::sqrt(dt);
				a=a>0?a:-a;
				f2.fm=2*a;
				f2.yf();
				f1=f1+f2;
				f1.yf();
				f1.output();
				printf("\n");
				continue;
			}
			else{
				f1.output();
				printf("+");
				f2.fz=dt;
				f2.fm=4*a*a;
				f2.yf();
				long long y=fj(f2.fm);
				f2.fz*=y;
				f2.fm*=y;
				y=fj(f2.fz);
				if(y==f2.fz){
					if(f2.fm==1)printf("sqrt(%lld)",f2.fz);
					else printf("sqrt(%lld)/%lld",f2.fz,fenshu::sqrt(f2.fm));
				}
				else{
					if(f2.fm==1)printf("%lld*sqrt(%lld)",fenshu::sqrt(f2.fz/y),y);
					else printf("%lld*sqrt(%lld)/%lld",fenshu::sqrt(f2.fz/y),y,fenshu::sqrt(f2.fm));
				}
				printf("\n");
			}
		}
	}
	return 0;
} 
