#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+5;

int gcd(int x,int y){
	if(x<y)swap(x,y);
	if(x%y==0)return y;
	else return (y,x/y);
}
int find(int n){
	for(int i=n;i>=1;i--){
		if(i*i>n)continue;
		if(n%(i*i)==0){
			return i;
		}
	}
}

int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	
	int t,m;
	scanf("%d%d",&t,&m);
	while(t--){
		int a,b,c,the;
		scanf("%d%d%d",&a,&b,&c);
		the=b*b-4*a*c;
		if(the<0){
			printf("NO\n");
		}
		else if(the==0){
			int d=gcd(abs(b),2*a);
			if((-b)%(2*a)==0)printf("%d\n",(-b)/(2*a));
			else printf("%d/%d\n",(-b)/d,2*a/d);
		}
		else{
			if(int(sqrt(the))*int(sqrt(the))==the){
				if(int(sqrt(the)-b)%(2*a)==0)printf("%d\n",int(sqrt(the)-b)/(2*a));
				else printf("%d/%d\n",int(sqrt(the)-b),(2*a));
			}
			else{
				int x=1;
				while(find(the)!=1){
					x=x*find(the);
					the=the/(x*x);
				}
				if(b==0){
					if(x==1)printf("sqrt(%d)/%d\n",the,2*a);
					else{
						int d=gcd(x,2*a);
						if(x/d==1){
							if((2*a)/d==1)printf("sqrt(%d)\n",the);
							else printf("sqrt(%d)/%d\n",the,(2*a)/d);
						}
						else{
							if((2*a)/d==1)printf("%d*sqrt(%d)\n",x/d,the);
							else printf("%d*sqrt(%d)/%d\n",x/d,the,2*a/d);
						}
					}
				}
				else{
					int d=gcd(x,2*a);
					if(x==1){
						if((-b)%(2*a)==0)printf("%d+sqrt(%d)/%d\n",(-b)/(2*a),the,2*a);
						else printf("%d/%d+sqrt(%d)/%d\n",(-b),2*a,the,2*a);
					}
					else{
						if((-b)%(2*a)==0){
							if(x/d==1){
								if(2*a/d==1)printf("%d+sqrt(%d)\n",(-b)/(2*a),the);
								else printf("%d+sqrt(%d)/%d\n",(-b)/(2*a),the,2*a/d);
							}
							else{
								if(2*a/d==1)printf("%d+%d*sqrt(%d)\n",(-b)/(2*a),x/d,the);
								else printf("%d+%d*sqrt(%d)/%d\n",(-b)/(2*a),x/d,the,2*a/d);
							}
						}
						else{
							if(x/d==1){
								if(2*a/d==1)printf("%d/%d+sqrt(%d)\n",(-b),2*a,the);
								else printf("%d/%d+sqrt(%d)/%d\n",(-b),2*a,the,2*a/d);
							}
							else{
								if(2*a/d==1)printf("%d/%d+%d*sqrt(%d)\n",(-b),2*a,x/d,the);
								else printf("%d/%d+%d*sqrt(%d)/%d\n",(-b),2*a,x/d,the,2*a/d);
							}
						}
					}
				}
			}
		}
	}
	return 0;
}
/*
9 1000
1 -1 0
-1 -1 -1
1 -2 1
1 5 4
4 4 1 
1 0 -432 
1 -3 1
2 -4 1 
1 7 1 
*/
