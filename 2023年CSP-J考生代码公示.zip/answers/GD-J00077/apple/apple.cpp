#include<bits/stdc++.h>
using namespace std;

queue<int> a,b;

int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)a.push(i);
	int day=0,ans;
	while(!a.empty()||!b.empty()){
		day++;
		while(!a.empty()){
			if(a.front()==n)ans=day;
			a.pop();
			if(!a.empty()){
				b.push(a.front());
				a.pop();
			}
			if(!a.empty()){
				b.push(a.front());
				a.pop();
			}
		}
		while(!b.empty()){
			a.push(b.front());
			b.pop();
		}
	}
	printf("%d %d",day,ans);
	return 0;
}
