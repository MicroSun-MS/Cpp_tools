#include<bits/stdc++.h>
using namespace std;
int n,h;
double a,b,c;
int i,t;
void zf(double d){
	int i=1;
	while(((int)(d/10)*10)!=d){
		d=d*10,i=i*10;
	}
	int t=d;
	while(__gcd(t,i)!=1){
		int p=__gcd(t,i);
		t/=p;
		i/=p;
	}
	if(i<0){
		i=i-(2*i);
		t=(-1*t);
	}	
	if(i==1) {
		cout<<t<<endl;
		return;
	}
	cout<<t<<" "<<i<<endl;
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>n>>h;
	for(int o=1;o<=n;o++){
		cin>>a>>b>>c;
		double k=b*b-4*a*c;
		if(k<0) {
			cout<<"NO";
			continue;
		}
		if(k>0){
			double j1=((-1*b)+sqrt(k))/(2*a);
			double j2=((-1*b)-sqrt(k))/(2*a);
			double w=max(j1,j2);
			zf(w);
		}
		if(k==0){
			double j1=((-1*b)+sqrt(k))/(2*a);
			int t=j1*10;
			if((t/10)!=a){
				zf(j1);
			}
			else cout<<j1<<endl;
		}
	}
	return 0;
} 
