#include<bits/stdc++.h>
using namespace std;
long long a,ans1,ans2,i=1,t;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>a;
	t=a;
	if(a==1){cout<<"1 1";return 0;}
	if(a==2){cout<<"2 2";return 0;}
	if(a%3==1) ans2=1;
	a=a-1;
	while(a>0){
		if((a-i)<=0) break;
		a-=i;
		i++;
		if(a<=0) break;
	}
	ans1=i+1;
	if(a==1) ans2=ans1;
	if(t%3==2){
		t=t/3;
		if(t%3==0) ans2=2;
		else if(t%3==1) ans2=4;
		else ans2=5;
	}
	if(t%3==1){
		
	}
	cout<<ans1<<" "<<ans2;
	
	return 0;
} 
//1 2
