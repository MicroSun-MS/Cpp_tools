#include<bits/stdc++.h>
using namespace std;

int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,k,x,sum=0;
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		cin>>x;
		sum+=x;
	}
	srand(time(0));
	cout<<rand()%sum+1;	
	return 0;
}
