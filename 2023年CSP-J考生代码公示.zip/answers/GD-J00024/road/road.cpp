#include<bits/stdc++.h>
using namespace std;
struct node{
	int pr;
	int x;
};

bool cmp(node t1,node t2){
	if(t1.pr!=t2.pr){
		return t1.pr<t2.pr;
	}
	if(t1.pr==t2.pr){
		return t1.x<t2.x;
	}
}
int n,d,v[100005],q1;
long long s[100005],sum;
node a[100005];
bool flag=0;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=1;i<n;i++){
		cin>>v[i];
		s[i]=s[i-1]+v[i];
	}
	for(int i=1;i<=n;i++){
		if(i!=n){
			cin>>a[i].pr;
			a[i].x=i;	
		}
		else cin>>q1;
	}
	sort(a+1,a+n,cmp);
	for(int i=1;i<n;i++){
		if(flag==1) break;
		if(a[i].x==1) {
			flag=1; 
		}
		if(i==1){
			int l=s[n-1]-s[a[1].x-1];
			if(l%d==0) l/=d;
			else l=l/d+1;
			sum=sum+l*a[i].pr;
		} 
		else{
			int l=s[a[i-1].x]-s[a[i].x];
			if(l%d==0) l/=d;
			else l=l/d+1;
			sum=sum+l*a[i].pr;
		}
	}	
	cout<<sum;
	return 0;
} 
//1 2
