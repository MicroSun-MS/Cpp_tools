#include<bits/stdc++.h>

FILE *in, *out; 

int main(){
	in=fopen("bus.in","r");
	out=fopen("bus.out","w");
	fprintf(out,"-1"); 
	return 0;
} 
