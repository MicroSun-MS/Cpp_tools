#include<bits/stdc++.h>

FILE *in, *out; 

long N,temp;
long ans1,ans2;

int main(){
	in=fopen("apple.in","r");
	out=fopen("apple.out","w");
	
	fscanf(in,"%ld",&N);
	
	for(ans1=0,temp=N;temp>0;ans1++){
		temp-=(temp+2)/3;
	}
	
	for(ans2=1,temp=N-1;temp%3;ans2++){
		temp-=(temp+2)/3;
	}
	
	fprintf(out,"%d %d",ans1,ans2);
	
	return 0;
}
