#include<bits/stdc++.h>

FILE *in, *out; 

int T,M;

int p,q;

int uqe[3];

char ans[100]={0};

int delta;


int gcd(int a,int b){
	int temp;
	while(a%b){
		temp=a;
		a%=b;
		b=temp;
	}
}

int broker(int a){
	for(int i=sqrt(a);i>1;i--){
		if(a%(i*i)==0)
			return i;
	}
	return 1;
}



int main(){
	in=fopen("uqe.in","r");
	out=fopen("uqe.out","w");
	
	fscanf(in,"%d %d",&T,&M);
	
	for(int i=0;i<T;i++){
		
		fscanf(in,"%d %d %d",&uqe[0],&uqe[1],&uqe[2]);
		
		delta=uqe[1]*uqe[1]-4*uqe[0]*uqe[2];
		
		if(delta<0){
			fputs("NO",out);
			continue;
		}
		
		ans[0]=0;
		
		if(uqe[1]!=0){
			int gcd_tmp=gcd(uqe[1],-2*uqe[0]);
		
			p=uqe[1]/gcd_tmp;
			q=-2*uqe[0]/gcd_tmp;
			
			if(q<0){
				p=-p;
				q=-q; 
			}	
			sprintf(ans,"%d",p);
						
			if(q!=1){
				sprintf(ans,"/%d",q);
			}
		}
			
		if(delta!=0){
			
			sprintf(ans,"+");
			
			int a=broker(delta),r=delta/(a*a);
				
			int gcd_tmp2=gcd(a,r);
				
			p=a/gcd_tmp2;
			q=r/gcd_tmp2;
				
			if(q<0){
				p=-p;
				q=-q; 
			}
				
			sprintf(ans,"+%d",p);
			
			if(r!=1){
				sprintf(ans,"*sqrt(%d)",r);
			}
						
			if(q!=1){
				sprintf(ans,"/%d",q);
			}
		}
		else{
			if(uqe[1]==0)
				sprintf(ans,"0");
		}
		
		fputs(ans,out);	
		
	}
	
	return 0; 
} 
