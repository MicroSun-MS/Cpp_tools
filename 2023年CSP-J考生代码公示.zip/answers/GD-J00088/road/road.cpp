#include<bits/stdc++.h>

FILE *in, *out;

int n,d;
int v[100000];
int a[100002];
int chose[100002];

long can_drive,need_drive,money,add_oil;
	
int count;

int main(){
	in=fopen("road.in","r");
	out=fopen("road.out","w");
	
	fscanf(in,"%d %d",&n,&d);
	
	for(int i=0;i<n-1;i++){
		fscanf(in,"%d",v+i);
	}

	
	fscanf(in,"%d",a);
	chose[0]=0;	
	
	for(int i=1;i<n;i++){
		fscanf(in,"%d",a+i);
		
		if(a[i]<a[chose[count]]){
			count++;
			chose[count]=i;
		}
	}
	
	count++;
	chose[count]=n;
	
	for(int i=0;i<count;i++){
		need_drive=0;
		for(int j=chose[i];j<chose[i+1];j++){
			need_drive+=v[j];
		}
		
		add_oil=(need_drive-can_drive)/d+((need_drive-can_drive)%d!=0);
		can_drive+=add_oil*d-need_drive;
		money+=add_oil*a[chose[i]];
		
	}
	
	fprintf(out,"%d",money);
	
	return 0; 
} 
