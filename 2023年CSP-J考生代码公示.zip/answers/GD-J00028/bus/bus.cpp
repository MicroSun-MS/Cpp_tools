#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	srand(time(0));
	int n,m,k,u[10001],v[10001],a[10001];
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		cin>>u[i]>>v[i]>>a[i];
	}
	cout<<rand(); 
	fclose(stdin);
	fclose(stdout);
	return 0;
}
