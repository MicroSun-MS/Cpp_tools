#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n,ans=0,num=-1;
	cin>>n;
	while(n){
		ans++;
		if(n%3==1&&num==-1){
			num=ans;
		}
		n-=ceil(n/3.0);
	}
	cout<<ans<<' '<<num;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
