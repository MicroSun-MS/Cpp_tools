#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int n,m,a[5001],b[5001],c[5001];
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		cin>>a[i]>>b[i]>>c[i];
		cout<<"NO"<<endl;
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
