#include<bits/stdc++.h>
using namespace std;
struct st{
	int a,v;
}c[10001],now;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,d,ans=0,nowi=1;
	long long l=0;
	double f=0;
	cin>>n>>d;
	for(int i=1;i<n;i++){
		cin>>c[i].v;
	}
	for(int i=1;i<=n;i++){
		cin>>c[i].a;
	}
	now=c[1];
	for(int i=1;i<=n;i++){
		l+=c[i-1].v;
		if(c[i].a<=now.a){
			if(f*d>=l){
				f-=(double)l/d;
			}
			else{
				if(l/d*d+f*d>=l){
					ans+=now.a*floor((double)l/d);
					f=floor((double)l/d)+f-ceil((double)l/d);
				}
				else{
					ans+=now.a*ceil((double)l/d);
					f+=ceil((double)l/d);
					f-=(double)l/d;
				}
			}
			now=c[i];
			nowi=i;
			l=0;
		}
	}
	if(nowi!=n){
		for(int j=nowi;j<n;j++){
			l+=c[j].v;
		}
		if(l/d*d+f*d>=l){
			f-=(double)l/d;
		}
		else{
			ans+=now.a*ceil((double)l/d);
			f+=ceil((double)l/d);
			f-=(double)l/d;
		}
	}
	cout<<ans;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
