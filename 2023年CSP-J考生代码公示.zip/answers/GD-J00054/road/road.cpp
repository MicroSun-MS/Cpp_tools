#include<bits/stdc++.h>
using namespace std;
int f[100005][2];
int main(){
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	int n, d;
	scanf("%d %d", &n, &d);
	int v[n+5], a[n+5];
	v[0]=0;
	for(int i=1; i<n; i++){
		scanf("%d", &v[i]);
		v[i]+=v[i-1];
	}
	for(int i=0; i<n; i++)scanf("%d", &a[i]);
	for(int i=1; i<n; i++){
		f[i][0]=0x3f3f3f3f;
		for(int j=0; j<i; j++){
			int s=v[i]-v[j]-f[j][1];
			int L=(s-1)/d+1;
			if(f[i][0] > f[j][0]+L*a[j]){
				f[i][0]=f[j][0]+L*a[j];
				f[i][1]=L*d-s;
			}			
		}
	}
	printf("%d", f[n-1][0]); 
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
