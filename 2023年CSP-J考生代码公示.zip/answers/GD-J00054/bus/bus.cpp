#include<bits/stdc++.h>
using namespace std;
int n, m, k;
int a[1005][1005], cost[10005];
void dfs(int v){
	if(v==n){
		return ; 
	}
	for(int i=1; i<=n; i++){
		if(a[v][i]!=0){
			if(cost[v]<a[v][i])cost[i]=min(cost[i], a[v][i]+1);
			else cost[i]=min(cost[i], cost[v]+1);
			dfs(i);	
		}
	}
}
int main(){
	freopen("bus.in", "r", stdin);
	freopen("bus.out", "w", stdout);
 	scanf("%d %d %d", &n, &m, &k);
 	cost[1]=k;
 	for(int i=1; i<n; i++)cost[i]=0x3f3f3f3f;
 	for(int i=0; i<m; i++){
 		int v, u, c;
 		scanf("%d %d", &v, &u);	
 		scanf("%d", &c);	
 		a[v][u]=c;
	}
 	dfs(1);
 	if(cost[n]=0x3f3f3f3f)printf("-1"); 
	else{
		printf("%d", cost[n]+cost[n]%k);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
