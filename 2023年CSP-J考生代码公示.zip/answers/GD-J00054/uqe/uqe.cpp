#include<bits/stdc++.h>
using namespace std;
int gcd(int a, int b){
	if(a%b==0) return b;
	else return gcd(b, a%b);
}
int main(){
	freopen("uqe.in", "r", stdin);
	freopen("uqe.out", "w", stdout);
 	int T, M;
 	scanf("%d %d", &T, &M);
 	for(int i=0; i<T; i++){
 		float a, b, c;
 		scanf("%f %f %f", &a, &b, &c);
 		int d=b*b-4*a*c, e, f, g;
 		if(d<0){
 			printf("NO"); continue;
		}
 		int d2=sqrt(d);
 		if(d==d2*d2){
 			e=-b+d2;
 			f=2*a;
			g=gcd(e,f);
			if(g<0)g=-g; 
			if(g!=1){
				e/=g; f/=g;
			}
			if(f==1)printf("%d", e);
			else{	
				printf("%d/%d", e, f);	
			}
		}
		else{
			int r=1;
			for(int i=2; i<sqrt(d); i++){
				while(d%(i*i)==0){
					d/=i*i; r*=i;
				}
			}
			e=-b;
 			f=2*a;
			g=gcd(e,f);
			if(g<0)g=-g; 
			if(g!=1){
				e/=g; f/=g;
			}
			if(f==1 && e!=0){
				printf("%d", e);
				printf("+"); 
			}
			else{	
				if( e!=0 ){
					printf("%d/%d", e, f);
					printf("+"); 
				}	
			}
			f=2*a; e=r;
			g=gcd(e,f);
			if(g<0)g=-g;
			if(g!=1){
				e/=g; f/=g;
			}
			if(e!=1 && f!=1)printf("%d*sqrt(%d)/%d", e, d, f);
			else{
				if(e==1 && f!=1)printf("sqrt(%d)/%d", d, f);
				if(e!=1 && f==1)printf("%d*sqrt(%d)", e, d);
				if(e==1 && f==1)printf("sqrt(%d)", d);
			} 
		}
	 }
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
