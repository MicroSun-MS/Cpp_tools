#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("apple.in", "r", stdin);
	freopen("apple.out", "w", stdout);
	int n, ans=0, m=-1;
	scanf("%d", &n);
	while(n!=0){
		ans++;
		if(n%3==1 && m==-1)m=ans;
		n-=(n-1)/3+1;
	}
	printf("%d %d", ans, m);
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
