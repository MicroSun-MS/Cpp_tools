#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,d;
	cin>>n>>d;
	int v[10000],a[10000];
	for(int i=0;i<n-1;i++){
		cin>>v[i];
	}
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	int ans=0;
	int m=0,Dis=0,Total=0,You=0;
	for(int i=0;i<n;i+=m){
		m=0,Dis=0;
		do{
			Dis+=v[i+m];
			m++;
		}while(a[i]<=a[i+m]);
		Total+=Dis;
		int k=Dis/d;
		You+=k;
		if(You*d<Total){
			k++;
			You++;
		}
		ans+=k*a[i];
	}
	cout<<ans;
	return 0;
}
