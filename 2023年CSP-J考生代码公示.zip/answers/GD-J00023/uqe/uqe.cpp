#include<bits/stdc++.h>
using namespace std;
int num[8]={4,9,25,49,121,169,289,361}; 
int gcd(int a,int b){
	for(int i=min(a,b);i>0;i++){
		if(a%i==0&&b%i==0)return i;
	}
}
int isround(double n){
	if(int(n*10000)%10000==0)return 1;
	return 0;
}
void v(double n){
	int fst=n*10000,scd=10000,c=gcd(fst,scd);
	fst/=c;
	scd/=c;
	if(scd<0){fst*=-1;scd*=-1;}
	if(scd==1)cout<<fst;
	else cout<<fst<<"/"<<scd;
}
double k(int n){
	int q=1;
	for(int i=0;i<8;i++){
		if(n%num[i]==0)q*=sqrt(num[i]);
	}
	return q;
}
int r(int n){
	for(int i=0;i<8;i++){
		if(n%num[i]==0)n/=num[i];
	}
	return n;
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int t,m;
	cin>>t>>m;
	int a[5000],b[5000],c[5000];
	for(int i=0;i<t;i++){
		cin>>a[i]>>b[i]>>c[i];
	}
	for(int i=0;i<t;i++){
		if(c[i]==b[i]){cout<<-b[i];continue;}
		}
		int Delta=pow(b[i],2)-4*a[i]*c[i];
		if(Delta<0){
			cout<<"NO"<<endl;
			continue;
		}
		double X1=0,X2=0;
		X1=(sqrt(Delta)-b[i])/(2*a[i]);
		X2=(-sqrt(Delta)-b[i])/(2*a[i]);
		if(isround(sqrt(Delta))){
			if(X1>X2)v(X1);
			if(X1<=X2)v(X2);
			cout<<endl;
			continue;
		}
		double q1=-b[i]/(2*a[i]);
		double q2=sqrt(Delta)/(2*a[i]);
		if(q1!=0){v(q1);cout<<"+";}
		if(k(q2)==1){cout<<"sqrt("<<Delta<<")"<<endl;continue;}
		if(isround(k(q2))){cout<<k(q2)<<"*sqrt("<<r(q2)<<")"<<endl;continue;}
	}
	return 0;
}
