#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,k;
	cin>>n>>m>>k;
	int u[1000],v[1000],a[1000];
	for(int i=0;i<n;i++){
		cin>>u[i]>>v[i]>>a[i];
	}
	cout<<2*k;
	return 0;
} 
