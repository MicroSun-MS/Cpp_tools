#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	long long n=0;
	cin>>n;
	long long Day=1,ans=0;
	bool wastake=true;
	int liu=0;
	while(n>0){
		if((n+2)%3==0&&wastake){ans=Day;wastake=false;}
		n-=(n+2)/3;
		Day++;
	}
	Day--; 
	cout<<Day<<" "<<ans;
	return 0;
} 
