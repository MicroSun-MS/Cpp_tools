#include <iostream>
#include <cstdio>
#include <cstring>
#include <queue>
#include <vector>
using namespace std;

int n, m, k;
vector<int> d[10005];
int dis[10005];

void bfs() {
	queue<int> q;
	q.push(1);
	dis[1] = 0;
	while (!q.empty()) {
		int x = q.front();
		q.pop();
		for (int i = 0; i < d[x].size(); i++)
			if (dis[d[x][i]] == -1) {
				dis[d[x][i]] = dis[x] + 1;
				q.push(d[x][i]);
			} 
	}
}

int main() {
	freopen("bus.in", "r", stdin);
	freopen("bus.out", "w", stdout);
	cin >> n >> m >> k;
	for (int i = 1; i <= n; i++)
		dis[i] = -1;
	for (int i = 1; i <= m; i++) {
		int u, v, w;
		cin >> u >> v >> w;
		d[u].push_back(v);
	}
	int ans = k;
	bfs();
	if (dis[n] == -1) {
		cout << "-1" << endl;
		return 0;
	}
	if ((ans + dis[n]) % k != 0)
		cout << ans + dis[n] + (k - ((ans + dis[n]) % k)) << endl;
	else
		cout << ans + dis[n] << endl;
	return 0;
} 
//5 5 3
//1 2 0
//2 5 1
//1 3 0
//3 4 3
//4 5 1
