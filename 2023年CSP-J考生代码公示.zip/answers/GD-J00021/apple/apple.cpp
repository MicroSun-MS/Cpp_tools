#include <iostream>
#include <cstdio>
#include <cstring>
using namespace std;

int n;
int vis[1000005];

int main() {
	freopen("apple.in", "r", stdin);
	freopen("apple.out", "w", stdout);
	cin >> n;
	int cnt = 0, need = 0;
	while (true) {
		int id = 1;
		for (int i = 1; i <= n; i++) {
			if (!vis[i]) {
				id++;
				if (id == 2)
					vis[i] = need + 1, id = -1, cnt++;
			}
		}
		need++;
		if (cnt == n)
			break;
	}
	cout << need << " " << vis[n] << endl;
	return 0;
} 
