#include <iostream>
#include <cstdio>
#include <cstring>
#include <cmath>
using namespace std;

int T, a, b, c, M;

int gcd(int a, int b) {
	if (b == 0) return a;
	return gcd(b, a % b);
}

int main() {
	freopen("uqe.in", "r", stdin);
	freopen("uqe.out", "w", stdout);
	cin >> T >> M;
	
	while (T--) {
		cin >> a >> b >> c;
		double dl = b * b - 4 * a * c;
//		cout << "a" << sqrt(dl) << endl;
		if (dl < 0) {
			cout << "NO\n";
			continue;
		}
		else {
			int f1 = -b, f2 = 2 * a;//�����ķ�ĸ���� 
			if (int(sqrt(dl)) * int(sqrt(dl)) == dl) {
				if (f2 < 0)
					f1 -= sqrt(dl);
				else
					f1 += sqrt(dl);
			}
			bool nn = false;
			if (f1 < 0 && f2 < 0)
				f1 = -f1, f2 = -f2;
			else if (f1 < 0 || f2 < 0)
				cout << "-", f1 = abs(f1), f2 = abs(f2);
			if (f1 != 0) {
				if (f2 / gcd(f1, f2) == 1)
					cout << f1 / gcd(f1, f2);
				else
					cout << f1 / gcd(f1, f2) << "/" << f2 / gcd(f1, f2);
				if (int(sqrt(dl)) * int(sqrt(dl)) == dl) {
					cout << endl;
					continue;
				}
				nn = true;
			}
			if (f1 == 0 && int(sqrt(dl)) * int(sqrt(dl)) == dl) {
				cout << "0" << endl;
				continue; 
			}
			f1 = -b, f2 = 2 * a;
			int q = 1;
			int idl = b * b - 4 * a * c;
//			cout << idl << endl;
			int iidl = idl;
			for (int i = 2; i * i <= iidl; i++)
				if (idl % (i * i) == 0)
					idl = idl / (i * i), q *= i;
			for (int i = 2; i * i <= iidl; i++)
				if (idl % (i * i) == 0)
					idl = idl / (i * i), q *= i;
			for (int i = 2; i * i <= iidl; i++)
				if (idl % (i * i) == 0)
					idl = idl / (i * i), q *= i;
			f2 = abs(f2);
			int gc = gcd(q, f2);
			q = q / gc;
			f2 = f2 / gc;
			if (idl == 0) {
				if (!nn)
					cout << 0 << endl;
				continue;
			}
			if (nn)
				cout << "+";
			if (f2 == 1 && q == 1)
				cout << "sqrt(" << idl << ")" << endl;
			else if (f2 == 1)
				cout << q << "*sqrt(" << idl << ")" << endl;
			else if (q == 1)
				cout << "sqrt(" << idl << ")" << "/" << f2 << endl;
			else
				cout << q << "*sqrt(" << idl << ")" << "/" << f2 << endl;
		}
	}
	return 0;
} 
//9 1000
//1 -1 0
//-1 -1 -1
//1 -2 1
//1 5 4
//4 4 1
//1 0 -432
//1 -3 1
//2 -4 1
//1 7 1
