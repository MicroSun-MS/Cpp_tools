#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;

long long n;
long long v[100005], a[100005], pre[100005];
long long pmin[100005];
long long g[100005];
long long d; 

int main() {
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	cin >> n >> d;
	for (int i = 1; i < n; i++)
		cin >> v[i], pre[i] = pre[i - 1] + v[i];
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	a[0] = 1e18;
	for (int i = 1; i <= n; i++) {
		if (a[i] < a[pmin[i - 1]])
			pmin[i] = i;
		else
			pmin[i] = pmin[i - 1];
	} 
	long long oid = n, cnt = 0;
	while (oid >= 1 && pmin[oid] != a[1])
		g[++cnt] = oid, oid = pmin[oid - 1];
	reverse(g + 1, g + cnt + 1);
	long long ans = 0, f = 0;
	for (int i = 2; i <= cnt; i++) {
		long long dis = pre[g[i] - 1] - pre[g[i - 1] - 1];
		long long need = (dis - f) / d;
		if ((dis - f) % d != 0)
			need++, f = d - ((dis - f) % d);
		else
			f = 0;
		ans += a[g[i - 1]] * need;
	}
	cout << ans << endl;
	return 0;
} 
//5 4
//10 10 10 10
//9 9 9 9 9
