#include<bits/stdc++.h>
using namespace std;
int a,b,c,n;
void print(double v){
	int p,q;
	if(int(v)==v){
		cout<<int(v);
		return;
	}
	q=1;p=2;
	if(v<0){
		while(v<=-2.0)v++,q++;
		while(1.0/p!=v){
			p++;
		}
		cout<<q<<'/'<<p;
		return;
	}
	while(v>=2.0)v--,q++;
	while(1.0/p!=v){
		p++;
	}
	cout<<q<<'/'<<p;
}
int main(){
//	freopen("uqe.in","r",stdin);
//	freopen("uqe.out","w",stdout);
	cin>>n;
	while(n--){
		cin>>a>>b>>c;
		double d=b*b-4*a*c;
		if(d<0){
			cout<<"NO"<<endl;
			continue;
		}
		double ansx=(-b+sqrt(d))/(2*a),ansy=(-b-sqrt(d))/(2*a);
		double x=max(ansx,ansy);
		if(d==sqrt(d)*sqrt(d)){
			print(x);
			cout<<endl;
			continue;
		}
		double q1=(-b)/(2*a),q2=1/(2*a);
		if(q1!=0){
			print(q1);
			cout<<'+';
		}
		if(q2==1)cout<<"sqrt("<<d<<")"<<endl;
		else if(int(q2)==q2)cout<<int(q2)<<"*sqrt("<<d<<")"<<endl;
		else if(int(1/q2)==1/q2)cout<<"sqrt("<<d<<")/"<<int(1/q2)<<endl;
		else{
			int cc=1,dd=2;
			while(q2>=2.0)q2--,cc++;
			while(1.0/dd!=q2){
				dd++;
			}
			cout<<cc<<"*sqrt("<<d<<")/"<<dd<<endl;
		}
	}
}
