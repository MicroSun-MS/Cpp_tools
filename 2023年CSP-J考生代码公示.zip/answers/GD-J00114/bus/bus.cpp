#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
int n,m,k;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m>>k;
	cout<<"-1";
}

