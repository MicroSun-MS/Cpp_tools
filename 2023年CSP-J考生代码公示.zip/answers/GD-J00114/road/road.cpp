#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
int dis[100010],a[100010],o[100010],qzh[100010],n,d,ans=0,oil=0,an=0;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=1;i<n;i++){
		cin>>dis[i];
		an+=dis[i];
		qzh[i]=qzh[i-1]+dis[i];
	}
	for(int i=1;i<=n;i++)cin>>a[i];
	int minn=100010,mini;
	for(int i=1;i<=n;i++)if(a[i]<minn){
		minn=a[i];
		mini=i;
	}
	if(mini==1){
		cout<<an/d*a[1];
		return 0;
	}
	for(int i=1;i<=n;i++){	
		minn=100010;
		for(int j=1;j<i;j++)if(a[j]<minn){
			minn=a[j];
			mini=j;
		}
		int tmp=0;
		for(int j=1;j<i;j++){
			tmp+=o[i];
		}
		if(tmp*d<qzh[i-1]){
			if(dis[i-1]%d==0){
				ans+=dis[i-1]/d*minn;
				o[mini]+=dis[i-1]/d;
			}
			else{
				ans+=(dis[i-1]/d+1)*minn;
				o[mini]+=dis[i-1]/d+1;
			}
		}
	}
	for(int i=1;i<=n;i++)cout<<o[i]<<' ';
	cout<<endl<<ans;
	return 0;
}

