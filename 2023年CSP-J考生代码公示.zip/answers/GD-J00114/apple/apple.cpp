#include<iostream>
#include<cstdio>
using namespace std;
bool a[100000000];
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n,ans,i=1,tmp=0,day=0;
	bool f=0,fl=0;
	cin>>n;
	while(1){
		day++;
		tmp=0;
		f=0;
		for(int i=1;i<=n;i++){
			tmp+=(!a[i]);
			if(tmp==1&&!f){
				f=1;
				tmp=0;
				a[i]=1;
			}
			else if(tmp==3){
				tmp=0;
				a[i]=1;
			}
		}
		if(a[n]==1&&!fl){
			ans=day;
			fl=1;
		}
		f=0;
		for(int i=1;i<=n;i++)if(!a[i]){
			f=1;
			break;
		}
		if(!f)break;
		 
	}
	cout<<day<<" "<<ans;
	return 0;
}
