#include<bits/stdc++.h>
using namespace std;
long long n,d,v[100005],a[100005],mi=0x3f3f3f3f;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld%lld",&n,&d);
	for(int i=1;i<n;i++)scanf("%lld",v+i);
	for(int i=1;i<=n;i++)scanf("%lld",a+i);
	long long sum=0,ans=0;
	for(int i=1;i<n;i++){
		if(a[i]<mi)mi=a[i];
		long long tmp=v[i];
		if(sum<tmp){
			tmp-=sum;
			if(tmp%d==0)tmp/=d;
			else tmp=tmp/d+1;
			sum+=tmp*d;
			ans+=1ll*mi*tmp;
		}
		sum-=v[i];
	}
	printf("%lld",ans);
	return 0;
}
