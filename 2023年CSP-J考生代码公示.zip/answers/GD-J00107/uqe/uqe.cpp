#include<bits/stdc++.h>
using namespace std;
long long T,M;
int gc(long long a,long long b){
	return !b?a:gc(b,a%b);
}
void pr(long long p,long long q){
	long long g=gc(p,q);
	p/=g,q/=g;
	if(q<0)p=-p,q=-q;
	if(q==1)printf("%lld",p);
	else printf("%lld/%lld",p,q);
}
long long qp(long long a,long long b){
	long long r=1;
	while(b){
		if(b&1)r*=a;
		b>>=1;
		a=a*a;
	}
	return r;
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%lld%lld",&T,&M);
	while(T--){
		long long a,b,c;
		scanf("%lld%lld%lld",&a,&b,&c);
		if(b*b-4*a*c<0){
			printf("NO\n");
			continue;
		}
		long long d=b*b-4*a*c;
		double sq=sqrt(d);
		if((long long)sq*(long long)sq==d){
			long long p=(long long)sq-b,q=2*a;
			pr(p,q);
			putchar('\n');
			continue;
		}
		long long tmp=d,k=1;
		for(long long i=2;i*i<=tmp;i++){
			long long cnt=0;
			while(tmp%i==0){
				cnt++;
				tmp/=i;
			}
			if(cnt>1)k*=qp(i,(cnt>>1));
		}
		d/=(k*k);
		long long q2=k,r=d,fm=2*a;
		long long tmpg=gc(q2,fm);
		q2/=tmpg,fm/=tmpg;
		long long p=-b,q=2*a;
		if(p!=0){
			pr(p,q);
			putchar('+');
		}
		if(q2<0)q2=-q2;
		if(fm<0)fm=-fm;
		if(q2!=1)printf("%lld*",q2);
		if(fm==1){
			printf("sqrt(%lld)\n",r);
			continue;
		}
		printf("sqrt(%lld)/%lld\n",r,fm);
	}
	return 0;
}
