#include<bits/stdc++.h>
using namespace std;
int n,cnt=1,ans;
bool f;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);
	int tmp=n;
	if(tmp%3==1&&!f){
		ans=cnt;
		f=1;
	}
	while(tmp>0){
		tmp-=((tmp+2)/3);
		cnt++;
		if(tmp%3==1&&!f){
			ans=cnt;
			f=1;
		}
	}
	printf("%d %d",cnt-1,ans);
	return 0;
}
