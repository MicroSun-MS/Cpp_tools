#include <cstdio>
#include <string>
#include <cmath>
using namespace std;
void fio(string file);
typedef long long ll;

const int N = 1e5+5;
const int INF = 0x7fffffff/3;
int a[N], v[N];

int main()
{
	int n, d;
	fio("road");
	scanf("%d %d",&n,&d);
	for (int i=1; i < n; i++) scanf("%d",&v[i]);
	a[0] = INF;
	ll ans = 0, s = 0;
	for (int i=1; i <= n; i++)
	{
		scanf("%d",&a[i]);
		a[i] = min(a[i],a[i-1]);
		if (s < v[i])
		{
			ans += ceil(1.0*(v[i]-s)/d)*a[i];
			s += ceil(1.0*(v[i]-s)/d)*d;
		}
		s -= v[i];
	}
	printf("%lld",ans);
	return 0;
}

void fio(string file)
{
	freopen((file+".in").c_str(),"r",stdin);
	freopen((file+".out").c_str(),"w",stdout);
}
