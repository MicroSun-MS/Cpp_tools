#include <cstdio>
#include <string>
#include <cmath>
using namespace std;
void fio(string file);
void air() {}

int sqr(int x) {return x*x;}

int gcd(int x, int y)
{
	x = abs(x), y = abs(y);
	while (y)
	{
		int r = x%y;
		x = y, y = r;
	}
	return x;
}

class frac
{
public:
	int a, b;
	frac(int a1, int b1)
	{
		int Gcd = gcd(a1,b1);
		a = a1/Gcd, b = b1/Gcd;
		if (b < 0) a = -a, b = -b;
	}
	frac(int a1) {a = a1, b = 1;}
	bool operator==(frac f) {return a == f.a && b == f.b;}
	bool operator!=(frac f) {return a != f.a || b != f.b;}
	frac operator*(frac f) {return frac(a*f.a,b*f.b);}
	void print()
	{
		if (b == 1) printf("%d",a);
		else printf("%d/%d",a,b);
	}
};

void operator*=(frac &a, frac b) {a = a*b;}

int main()
{
	int T;
	fio("uqe");
	scanf("%d %*d",&T);
	int o = 0;
	while (T--)
	{
		o++;
		if (o == 2333)
			air();
		int a, b, c;
		scanf("%d %d %d",&a,&b,&c);
		int delta = sqr(b)-4*a*c;
		if (delta < 0) printf("NO");
		else 
		{
			if (sqr(sqrt(delta)) == delta)
			{
				if (2*a > 0) frac(-b+sqrt(delta),2*a).print();
				else frac(-b-sqrt(delta),2*a).print();
			}
			else 
			{
				frac q1(-b,2*a), q2(1,abs(2*a));
				int r = delta;
				for (int i=sqrt(r); i > 1; i--) if (delta%sqr(i) == 0)
				{
					r /= sqr(i), q2 *= i;
					break;
				}
				if (q1 != 0) q1.print(), printf("+");
				if (q2 == 1) printf("sqrt(%d)",r);
				else if (q2.b == 1) printf("%d*sqrt(%d)",q2.a,r);
				else if (q2.a == 1) printf("sqrt(%d)/%d",r,q2.b);
				else printf("%d*sqrt(%d)/%d",q2.a,r,q2.b);
			}
		}
		printf("\n");
	}
	return 0;
}

void fio(string file)
{
	freopen((file+".in").c_str(),"r",stdin);
	freopen((file+".out").c_str(),"w",stdout);
}
