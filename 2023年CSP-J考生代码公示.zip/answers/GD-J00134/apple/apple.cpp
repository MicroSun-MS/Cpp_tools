#include <cstdio>
#include <cmath>
#include <string>
using namespace std;
void fio(string file);

int main()
{
	int n, ans1 = 0, ans2 = 0;
	fio("apple");
	scanf("%d",&n);
	while (n > 0)
	{
		if (n%3 == 1 && ans2 == 0) ans2 = ans1+1;
		ans1++;
		n -= ceil(n/3.0);
	}
	printf("%d %d",ans1,ans2);
	return 0;
}

void fio(string file)
{
	freopen((file+".in").c_str(),"r",stdin);
	freopen((file+".out").c_str(),"w",stdout);
}

