#include <cstdio>
#include <string>
#include <cmath>
using namespace std;
void fio(string file);

struct node
{
	int x, i;
};

const int N = 1e4+5, P = 105, E = 2e4+5, Q = 1e6+5, INF = 0x7fffffff/3;
int last[N], nx[E], to[E], v[E];
int f[N][P], vis[N][P];
node q[Q];
int tot = 0, num;

void add(int x, int y, int z)
{
	tot++;
	nx[tot] = last[x];
	last[x] = tot;
	to[tot] = y;
	v[tot] = z;
}

int main()
{
	int n, m, p;
	fio("bus");
	scanf("%d %d %d",&n,&m,&p);
	for (int i=1; i <= m; i++)
	{
		int x, y, z;
		scanf("%d %d %d",&x,&y,&z);
		add(x,y,z);
	}
	for (int i=1; i <= n; i++)
		for (int j=0; j < p; j++)
			f[i][j] = INF;
	f[1][0] = 0;
	int head = 1, tail = 1;
	q[tail] = {1,0}, vis[1][0] = true;
	while (head <= tail)
	{
		int x = q[head].x, i = q[head].i;
		for (int e = last[x]; e; e = nx[e])
		{
			int y = to[e], j = (i+1)%p;
			int t = f[x][i]+1;
			if (t < v[e]) t = ceil(1.0*(v[e]-j)/p)*p+j;
			if (t < f[y][j])
			{
				f[y][j] = t;
				if (!vis[y][j])
				{
					q[++tail] = {y,j};
					vis[y][j] = true;
				}
			}
		}
		head++;
		vis[x][i] = false;
	}
	printf("%d",f[n][0]);
	return 0;
}

void fio(string file)
{
	freopen((file+".in").c_str(),"r",stdin);
	freopen((file+".out").c_str(),"w",stdout);
}
