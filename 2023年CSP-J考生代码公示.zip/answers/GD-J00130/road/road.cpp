#include<bits/stdc++.h>
using namespace std;
long long ans,cntd,cnt,a[1000005],v[1000005],n,d;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld%lld",&n,&d);
	for(int i=1;i<n;i++){
		scanf("%lld",&v[i]);
	}
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	for(int i=1;i<n;){
		if(a[i]>=a[i+1]){
			if(cnt>=v[i]){
				cnt-=v[i];
			}
			else{
				ans+=((v[i]-cnt+d-1)/d)*a[i];
				cnt=((v[i]-cnt+d-1)/d)*d-(v[i]-cnt);
			} 
			
			
		//	cout<<ans<<" "<<cnt<<" "<<i<<"&";
			i++;
		}else{
			int j=i+1;
			cntd=v[i];
			while(a[j]>a[i]&&j<n){
				cntd+=v[j];
				j++;
			}
			if(cnt>=cntd) cnt-=cntd;
			else{
				ans+=((cntd-cnt+d-1)/d)*a[i];
				cnt=((cntd-cnt+d-1)/d)*d-(cntd-cnt);	
			}
		//	cout<<ans<<" "<<cnt<<" "<<i<<" ";
			i=j;
		}
	}
	printf("%lld",ans);
	return 0;
}

