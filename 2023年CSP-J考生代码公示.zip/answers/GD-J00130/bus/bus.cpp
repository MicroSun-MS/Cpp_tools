#include<bits/stdc++.h>
using namespace std;
int n,m,k,ans=1e9,h[1000005],kk,x,y,c,ok;
struct vv{
	int r,pre,c;
}d[1000005];
void cun(int x,int y,int c){
	d[++kk].r=y;
	d[kk].pre=h[x];
	d[kk].c=c;
	h[x]=kk;
}
void dfs(int x,int sum){
	if(x==n){
		if(sum%k==0){
			ans=min(ans,sum);
		}
	}
	for(int i=h[x];i;i=d[i].pre){
		int j=d[i].r;
		if(sum>d[i].c)dfs(j,sum+1);
	}
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;i++){
		scanf("%d%d%d",&x,&y,&c);
		cun(x,y,c);
	}
	dfs(1,k);
	if(ans!=1e9)printf("%d",ans);
	else printf("-1");
	return 0;
}

