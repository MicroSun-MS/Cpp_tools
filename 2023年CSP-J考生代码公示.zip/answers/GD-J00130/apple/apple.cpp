#include<bits/stdc++.h>
using namespace std;
int n,sum,k;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);
	while(n){
		sum++;
		if(n%3==1&&!k) k=sum;
		int p=(n+2)/3;
		n-=p;
	}
	printf("%d %d",sum,k);
	return 0;
}

