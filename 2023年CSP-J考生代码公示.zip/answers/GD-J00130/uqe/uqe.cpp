#include<bits/stdc++.h>
using namespace std;
int t,m,a,b,c,l,cnt;
int gcd(int x,int y){
	if(y==0) return x;
	return gcd(y,x%y);
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&t,&m);
	while(t--){
		scanf("%d%d%d",&a,&b,&c);
		if(b*b-4*a*c<0){
			printf("NO\n");
			continue;
		}
		int p=b*b-4*a*c;
		if(!p){
			a*=2;
			int l=gcd(abs(b),abs(a));
			b/=l; a=a/l;
			if(a==-1) b=-b,a=1;
			if(a!=1)printf("%d/%d\n",-b,a);
			else printf("%d\n",-b);
			continue;
		}
		cnt=1;
		for(int i=2;i*i<=m;i++){
			while(p%(i*i)==0){
				p/=(i*i);
				cnt*=i;
			}
		}
		a*=2;
		if(1.0*(-b+cnt*sqrt(p))/(a)>1.0*(-b-cnt*sqrt(p))/(a)){
			if(p==1){
				int l=gcd(abs(cnt-b),abs(a));
				a/=l;
				int x=(cnt-b)/l;
				if(a<0) a=-a,x=-x;
				if(a!=1) printf("%d/%d\n",x,a);
				else printf("%d\n",x);
			}else{
				int aa=a;
				int l=gcd(abs(-b),abs(a));
				b/=l; a/=l;
				int ll=gcd(abs(cnt),abs(aa));
				aa/=ll; cnt/=ll;
				if(a<0) a=-a,b=-b;
				if(aa<0) aa=-aa,cnt=-cnt;
				if(b&&abs(a)==1) printf("%d",-b);
				if(b&&abs(a)!=1) printf("%d/%d",-b,a);
				if(cnt<0) printf("-");
				else printf("+");
				if(abs(cnt)!=1) printf("%d*",cnt);
				printf("sqrt(%d)",p);
				if(abs(aa)!=1) printf("/%d",aa);
				printf("\n");
			}
		}else{
			if(p==1){
				int l=gcd(abs(cnt+b),abs(a));
				a/=l;
				int x=(cnt+b)/l;
				if(a<0) a=-a,x=-x;
				if(a!=1) printf("%d/%d\n",x,a);
				else printf("%d\n",x);
			}else{
				int aa=a;
				int l=gcd(abs(-b),abs(a));
				b/=l; a/=l;
				int ll=gcd(abs(cnt),abs(aa));
				aa/=ll; cnt/=ll;
				if(a<0) a=-a,b=-b;
				if(aa<0) aa=-aa,cnt=-cnt;
				if(b&&abs(a)==1) printf("%d",-b);
				if(b&&abs(a)!=1) printf("%d/%d",-b,a);
				if(cnt<0) printf("+");
				else printf("-");
				if(abs(cnt)!=1) printf("%d*",abs(cnt));
				printf("sqrt(%d)",p);
				if(abs(aa)!=1) printf("/%d",aa);
				printf("\n");
			}
		}
	}
	return 0;
}

