#include <bits/stdc++.h>
using namespace std;
#define int long long

signed main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cout<<-1;
	return 0;
}  
