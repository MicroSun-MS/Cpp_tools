#include <bits/stdc++.h>
using namespace std;
#define int long long
int n,d;
signed main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	queue <int> q;
	for(int i=1;i<=n;i++){
		q.push(i);
	}
	int curd=0;
	while(!q.empty()){
		curd++;
		int curs = q.size();
		for(int i=1;i<=curs;i++){
			if(i%3==1){
				if(q.front()==n)	d=curd;
				q.pop();
				if(q.empty())	break;
			}
			else{
				int h=q.front();
				q.pop();q.push(h);
			}
		}
	}
	cout<<curd<<" "<<d;
	return 0;
} 
