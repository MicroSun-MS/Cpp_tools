#include <bits/stdc++.h>
using namespace std;
#define int long long
int T,M,a,b,c;

signed main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>T>>M;
	while(T--){
		cin>>a>>b>>c;
		int k=b*b-4*a*c;
		if(k<0){
			cout<<"NO"<<endl;continue;
		}
		
		if(sqrt(k)-(int)(sqrt(k))==0){//x���� 
			int sk=sqrt(k);
			if((-b+sk)/(2*a)*(2*a)!=(-b+sk)){//x������������Ҫ������ʽ��� 
				
				//int x=(a>0)?(-b+sk):(-b-sk),y=(2*a);
				int x=150,y=18;
				for(int i=min(x,y);i>=1;i--){
					if(x%i==0&&y%i==0){
						cout<<x/i<<"/"<<y/i<<"\n";
						break;
					}
				}	
			}
			else if(a>0)	cout<<(-b+sk)/(2*a);
			else	cout<<(-b-sk)/(2*a);
			cout<<"\n";
		}
	} 
	return 0;
} 
