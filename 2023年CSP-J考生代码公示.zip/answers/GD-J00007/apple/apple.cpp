#include<bits/stdc++.h> 
using namespace std;
const int A = 1000000001;
struct apple{
	bool isnz=0;
}a[A];
int n,nz_day,c=0,d=0;

bool isak(int n){
	int x=0;
	for(int i=1;i<=n;i++){
		if(a[i].isnz){
			x++;
		}
	}
	if(x == n){
		return true;
	}
	else{
		return false;
	}
}
int main(){
	freopen("apple.in", "r", stdin);
	freopen("apple.out", "w", stdout);
	cin>>n;
	while(!isak(n)){
		c++;
		for(int i=1;i<=n;i++){
			int level=1;
			if(a[i].isnz){
				continue;
			}
			if(level %3==1){
				a[i].isnz = 1;
				if(i==n){
					nz_day=c;
				}
			}
			level++;
		}
    }
	cout<<c<<" "<<nz_day; 
	return 0; 
} 
