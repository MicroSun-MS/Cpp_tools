#include<bits/stdc++.h> 
using namespace std;
struct yyecfc{
	int a,b,c;
	double t,x;
	bool ywsj;
}a[5001];

bool gcd(int a,int b){
	if(a==b||a==1||b==1){
		return true;
	}
	for(int i=2;i<=sqrt(max(a,b));i++){
		if(a % i == 0&&b%i==0){
			return false;
		}
	}
	return true;
}

int t,m;
int main(){
//	freopen("uqe.in","r",stdin);
//	freopen("uqe.out","w",stdout);
	cin>>t>>m;
	for(int i=1;i<=t;i++){
		cin>>a[i].a>>a[i].b>>a[i].c;
		a[i].t = a[i].b*a[i].b - 4*a[i].a*a[i].c;
		if(a[i].t<0){
			a[i].ywsj = false;
		}
		else{
			a[i].ywsj = true;
		}
	}
	for(int i=1;i<=t;i++){
		if(!a[i].ywsj){
			cout<<"NO"<<endl;
		}
		else{
			a[i].x = max(((0-a[i].b)+sqrt(a[i].t))/2/a[i].a,  ((0-a[i].b)-sqrt(a[i].t))/2/a[i].a);
			int p,q;
			for(p=1;p<=sqrt(a[i].x);p++){
				for(q=1;q<=sqrt(a[i].x);q++){
					if(gcd(p,q)&&a[i].x == p/q){
						break;
					}
				}
			}
			if(p==floor(sqrt(a[i].x)&&q == sqrt(a[i].x)){
				//������ 
				int  q1,q2,q3,r;
				int c1,d1;
				for(q1=1;q1<=a[i].x;q1++){
					for(q2=1;q2<=a[i].x;q2++){
						for(r=1;r<=a[i].x;r++){
							if(a[i].x == q1+q2*sqrt(r)){
								break;
							}
						}
					}
				}
				q3 = 1/double(q2);
				if(q2 == 1){
					cout<<"sqrt("<<r<<")"<<endl;
				}
				else if(q2 % 1 == 0){
					cout<<q2<<"*sqrt("<<r<<")"<<endl;
				}
				else if(q3 % 1 == 0){
					cout<<"*sqrt("<<r<<")/"<<q3<<endl;
				}
				else{
					for(c1=1;c1<=q2;c1++) {
						for(d1=1;d1<=q2;d1++){
							if(gcd(c1,d1) && q2 == c1/d1){
								break;
							}
						}
					}
					cout<<c1<<"*sqrt("<<r<<")/"<<d1<<endl; 
				}
			}
			else{//������ 
				cout<<a[i].x<<endl;
		    }
		}
	}
	return 0;
}//��д������ĳ���[Ц] 

