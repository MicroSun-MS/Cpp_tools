#include<bits/stdc++.h>
using namespace std;
int n,d,v[100000],a[100001],money=0;
double sy=0;
int main(){
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	cin>>n>>d;
	for(int i=1;i<=n-1;i++){
		cin>>v[i];
	}
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n-1;i++){
		int cs; 
		if(a[i+1]> a[i]) {
			cs= ceil((v[i]+v[i+1]-sy)/double(d));
		}
		else{
		    cs= ceil((v[i]-sy)/double(d));
			sy =(cs*d-v[i])/double(d);
			money+= cs*a[i];
	    }	
	}
	cout<<money<<endl;
} 
