#include<bits/stdc++.h>
using namespace std;
int n,m;
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);	
	cin>>n>>m;
	for(int i=1;i<=n;i++)
	{
		int a,b,c;
		cin>>a>>b>>c;
		if(abs(a)>m || abs(b)>m || abs(c)>m)
		{
			cout<<"NO"<<endl;
			continue;
		}
		else
		{
			int dertar=abs(b*b)-(4*a*c);
			if(dertar<0)
			{
				cout<<"NO"<<endl;
				continue;
			}
			else
			{
				int gen1=(b*-1)+sqrt(dertar),gen2=(b*-1)-sqrt(dertar);
				int xx1=gen1/(2*a);
				int xx2=gen2/(2*a);
				if(xx1>xx2)cout<<xx1<<endl;
				else cout<<xx2<<endl;		
			}
		}
	}
	return 0;
} 
