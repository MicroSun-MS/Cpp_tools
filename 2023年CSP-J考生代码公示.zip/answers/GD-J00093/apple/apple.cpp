#include<bits/stdc++.h>
using namespace std;
int n;
int ans;
queue<int> num;
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);	
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		num.push(i); 
	}
	int flag=1;
	int day=1;
	int lengs=num.size();
	while(!num.empty())
	{
		if(flag>lengs)
		{
			day++;
			lengs=num.size();
			flag=1;
		}
		if((flag-1)%3==0)
		{
			int kk=num.front();
			if(kk==n)ans=day;
			num.pop();
		}
		else
		{
			num.push(num.front());
			num.pop();
		}
		flag++;
	}
	cout<<day<<endl<<ans;
	return 0;
} 
