#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int ans=9999999;
int arr[20002][20002];
struct node2
{
	int chufa;
	int mudidi;
	int time;
};
queue<node2> dp;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);	
	cin>>n>>m>>k;
	memset(arr,-1,sizeof arr);
	for(int i=1;i<=m;i++)
	{
		int a,b,c;
		cin>>a>>b>>c;
		arr[a][b]=c;
		if(a==1)
		{
			dp.push({a,b,k});
		}
	}
	while(!dp.empty())
	{
		node2 kk=dp.front();
		dp.pop();
		int x=kk.chufa,y=kk.mudidi,t=kk.time;
		if(t>=arr[x][y])t+=1;
		else t=arr[x][y]+1;
		if(y>=n)
		{
			if(t%k==0)ans=min(ans,t);
			else ans=min(ans,((t/k)+1)*k);
		}
		for(int i=1;i<=n;i++)
		{
			if(arr[y][i]!=-1)
			{
				dp.push({y,i,t});
			}
		}
	}
	cout<<ans;
	return 0;
} 

