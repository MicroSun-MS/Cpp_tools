#include<bits/stdc++.h>
using namespace std;
int n,d;
int arr[10002];
int price[10002];
long long ans=0;
int low_price=999999;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);	
	cin>>n>>d;
	for(int i=1;i<=n-1;i++)
	{
		cin>>arr[i];
	}
	for(int i=1;i<=n;i++)
	{
		cin>>price[i]; 
	} 
	for(int i=1;i<=n-1;i++)
	{
		if(price[i]<low_price)
		{
			low_price=price[i];
		}
		int kk=( (arr[i]/d) + (arr[i]%d!=0) );
		ans+=(kk*low_price);
		if(kk>(arr[i]/d))
		{
			arr[i+1]-=(kk*d-arr[i]);
		}
	}
	cout<<ans;
	return 0;
} 
