#include <bits/stdc++.h>
using namespace std;

long long a , b , awa[100005] , qwq[100005] , h = 99999999 , g;

void srh(long long x , long long y , long long z){
	if(x == a){
		cout << y << endl;
		return ;
	}
	
	if(awa[x] - z <= 0){
		srh(x + 1 , y , z - awa[x]);
		return ;
	}
	
	if(h > qwq[x]){
		h = qwq[x];
	}
	
	g = (awa[x] - z) / b;
	
	if((awa[x] - z) % b == 0){
		srh(x + 1 , y + g * h , 0);
	}
	else{
		srh(x + 1 , y + (g + 1) * h , z + (g + 1) * b - awa[x]);
	}
}

int main(){
	freopen("road.in" , "r" , stdin);
	freopen("road.out" , "w" , stdout);
	
	cin >> a >> b;
	
	for(int i = 1;i < a;i++){
		cin >> awa[i];
	}
	for(int i = 1;i <= a;i++){
		cin >> qwq[i];
	}
	
	srh(1 , 0 , 0);
	
	return 0;
}
