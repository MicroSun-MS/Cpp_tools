#include <bits/stdc++.h>
using namespace std;

long long a , b , c , awa[20005][3];

long long h = 99999999;

void srh(int x , int y){
	if(x == a){
		if(y % c == 0){
			if(h > y){
				h = y;
			}
		}
		return ;
	}
	
	for(int i = 1;i <= a;i++){
		if(awa[i][0] == x){
			srh(awa[i][1] , y + 1);
		}
	}
	
}

int main(){
	freopen("bus.in" , "r" , stdin);
	freopen("bus.out" , "w" , stdout);
	cin >> a >> b >> c;
	for(int i = 1;i <= b;i++){
		cin >> awa[i][0] >> awa[i][1] >> awa[i][2];
	}
	srh(1 , c);
	cout << h << endl;
	return 0;
} 
