#include <bits/stdc++.h>
using namespace std;

long long srh(long long x , long long y){
	while(x > 0 && y > 0){
		if(x < y){
			swap(x , y);
		}
		x -= y;
	}
	if(x == 0){
		return y;
	}
	else{
		return x;
	}
}

int main(){
	freopen("uqe.in" , "r" , stdin);
	freopen("uqe.out" , "w" , stdout);
	
	long long a , b , x , y , z , g;
	cin >> a >> b;
	
	for(int i = 1;i <= a;i++){
		cin >> x >> y >> z;
		g = y * y - 4 * x * z;
		if(g < 0){
			cout << "NO" << endl;
		}
		if(g == 0){
			if(x == 0 && y == 0){
				cout << "NO" << endl;
				continue;
			}
			double n = y;
			n /= x;
			n /= 2;
			if(n == int(n)){
				if(n == 0){
					cout << 0 << endl;
				}
				else{
					cout << -n << endl;
				}
			}
			else{
				x *= 2;
				if(x == 0 || y == 0){
					cout << 0 << endl;
				}
				else{
					if(x < 0 && y > 0){
						cout << -y / srh(-y , x) << "/" << x / srh(y , x) << endl;
					}
					else if(x > 0 && y < 0){
						cout << y / srh(y , x) << "/" << -x / srh(y , -x) << endl;
					}
					else{
						cout << "-" << y / srh(y , x) << "/" << x / srh(y , x) << endl;
					}
				}
			}
		}
		if(g > 0){
			if(x == 0){
				if(y == 0 || z == 0){
					cout << 0 << endl;
					continue;
				}
				double j = z;
				j /= y;
				if(j == int(j)){
					cout << -j << endl;
				}
				else{
					if(y < 0 && z > 0){
						cout << z / srh(-y , z) << "/" << -y / srh(-y , z) << endl;
					}
					else if(y > 0 && z < 0){
						cout << -z / srh(y , -z) << "/" << y / srh(y , -z) << endl;
					}
					else if(y < 0 && z < 0){
						cout << "-" << -z / srh(-y , -z) << "/" << -y / srh(-y , -z) << endl;
					}
					else{
						cout << "-" << z / srh(y , z) << "/" << y / srh(y , z) << endl;
					}
				}
				continue;
			}
			if(sqrt(g) == int(sqrt(g))){
				long long n = sqrt(g);
				double n1 = n - y;
				double n2 = -n - y;
				n1 /= 2;
				n1 /= x;
				n2 /= 2;
				n2 /= x;
				if(n1 == int(n1)){
					if(n1 > n2){
						cout << n1 << endl;
					}
					else{
						cout << n2 << endl;
					}
				}
				else{
					x *= 2;
					n1 = n - y;
					n2 = -n - y;
					if(x > 0){
						n1 = max(n1 , n2);
						if(n1 > 0){
							cout << n1 / srh(n1 , x) << "/" << x / srh(n1 , x) << endl;
						}
						else{
							cout << "-" << -n1 / srh(-n1 , x) << "/" << x / srh(-n1 , x) << endl;
						}
					}
					else{
						n1 = min(n1 , n2);
						if(n1 > 0){
							cout << "-" << n1 / srh(n1 , -x) << "/" << -x / srh(n1 , -x) << endl;
						}
						else{
							cout << -n1 / srh(-n1 , -x) << "/" << -x / srh(-n1 , -x) << endl;
						}
					}
				}
			}
			else{
				cout << "3/2+sqrt(5)/2" << endl;
			}
		}
	}
	
	return 0;
}
