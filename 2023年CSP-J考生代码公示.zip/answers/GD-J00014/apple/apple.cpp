#include <bits/stdc++.h>
using namespace std;

int main(){
	freopen("apple.in" , "r" , stdin);
	freopen("apple.out" , "w" , stdout);
	
	long long a;
	cin >> a;
	long long h1 = 0 , h2 = 0 , d2 = 0;
	
	
	while(a > 0){
		h2++;
		if(a % 3 == 0){
			a -= a / 3;
		}
		else{
			if(a % 3 == 1){
				if(d2 == 0){
					d2 = h2;
				}
			}
			a -= a / 3;
			a--;
		}
		h1++;
	}
	
	cout << h1 << " " << d2 << endl;
	
	return 0;
} 
