#include<bits/stdc++.h>
using namespace std;
int n,d;
int a[100005],v[100005],f[100005],last,t=2;
long long di[100005];
long long lef=0;
long long ans;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&d);
	v[1]=0;
	for(int i=2;i<=n;i++){
		scanf("%d",&v[i]);
		di[i]=di[i-1]+v[i];
	}
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
//		v[i]=a[i];
//		cout<<a[i]<<endl;
	}
//	sort(v+1,v+n+1);
//	for(int i=n;i>=1;i--){
//		cout<<v[i]<<" ";;
//	}
	last=a[1];
	f[1]=1;
//	cout<<a[f[1]]<<endl;
	for(int i=2;i<n;i++){
//		if(a[i]==101){
//			cout<<a[i]<<" "<<last<<endl;;
//		}
		if(a[i]<last){
			f[t]=i;
			last=a[i];
//			cout<<i<<" ";
			t++;
		}
	}
//	t++;
	f[t]=n;
//	cout<<f[6]<<endl;
//	for(int i=1;i<=t;i++){
//		cout<<a[f[i]]<<endl;
//	}
	for(int i=1;i<t;i++){
		int dis=di[f[i+1]]-di[f[i]];
//		cout<<dis<<endl;
		if(lef<dis){
			int cha=dis-lef;
			int jia=ceil((double)cha/d)*d;
			lef=jia-cha;
			ans+=jia/d*a[f[i]];
//			cout<<jia/d<<endl; 
		}
	}
	printf("%lld\n",ans);
}
