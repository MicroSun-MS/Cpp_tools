#include<bits/stdc++.h>
using namespace std;
int n,ans1,m,ans2;
bool found=false;
int a[100005];
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);
	m=n;
	while(n>0){
		if(n%3==1 and found==false)ans2=ans1,found=true;
		ans1+=1;
		n-=(n-1)/3+1;
	}
	printf("%d %d",ans1,ans2+1);
} 
