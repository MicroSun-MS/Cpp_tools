#include<bits/stdc++.h>
using namespace std;
int a,b,c;
int t1,t2,t3;
int gcd(int x,int y){
	x=abs(x);
	y=abs(y);
	while(x!=y){
		if(x<y)swap(x,y);
		x=x-y;
	}
	return x;
}
int findpow(int x){
	int p=sqrt(x);
	for(int i=p;i>=1;i--){
		if(x%(i*i)==0){
			return i;
		}
	}
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int T,m;
	scanf("%d%d",&T,&m);
	while(T--){
	scanf("%d%d%d",&a,&b,&c);
	if(a<0){
		a=-a;
		b=-b;
		c=-c;
	}
	t1=2*a;
	t2=b;
	t3=b*b-4*a*c;
	if(t3<0){
		printf("NO\n");
	} 
	else if(b==0 and c==0){
		printf("0\n");
	}
	else if(t3==0){
		int tmp1=gcd(t2,t1);
		if(tmp1!=1){
			if(t2%t1==0){
				cout<<-t2/t1<<endl;
			}
			else{
				t1/=tmp1;
				t2/=tmp1;
				cout<<-t2<<"/"<<t1<<endl;
			}
		}
	}
	else if(t2==0){
		int p1=findpow(t3),p2=t3/p1/p1;
//		cout<<p1<<" "<<p2<<endl;
		int tmp2=gcd(p1,t1);
			if(tmp2!=1){
				if(p1%t1==0){
					if(p2!=1)
						cout<<p1/t1<<"*sqrt("<<p2<<")"<<endl;
					else
						cout<<p1/t1<<endl;
				}
				else{
					p1/=tmp2;
					t1/=tmp2;
					if(p1==1){
						if(p2!=1)
						cout<<"sqrt("<<p2<<")/"<<t1<<endl;
						else
						cout<<"1/"<<t1<<endl;
					}
					else{ 
						if(p2!=1)
						cout<<p1<<"*sqrt("<<p2<<")/"<<t1<<endl;
						else
						cout<<p1<<"/"<<t1<<endl;
						} 
				}
			}
			else{
				if(p1==1){
					if(p2!=1)
					
						cout<<"sqrt("<<p2<<")/"<<t1<<endl;
						else cout<<"1/"<<t1<<endl;
					else{
						if(p2!=1)
						cout<<p1<<"*sqrt("<<p2<<")/"<<t1<<endl;
						else
						cout<<p1<<"/"<<t1<<endl;
						} 
				
			}
	}
	else{
		int tmp1=gcd(t2,t1);
		int p1=findpow(t3),p2=t3/p1/p1;
//		cout<<p1<<" "<<p2<<endl;
//		cout<<tmp1<<endl;
		if(p2==1){
			int p3=p1-t2;
//			cout<<p3<<endl;
			if(p3==0){
				cout<<0<<endl;
			}
			else{
			int tmp2=gcd(p3,t1);
			if(p3%t1==0){
				cout<<p3/t1<<endl;
			}
			else{
				p3/=tmp2;
				t1/=tmp2;
				cout<<p3<<"/"<<t1<<endl;
			}
			}
		}
		else{
			if(tmp1!=1){
				if(t2%t1==0){
					cout<<-t2/t1<<"+";
				}
				else if(t2!=0){
//					t1/=tmp1;
//					t2/=tmp1; 
					cout<<-t2/tmp1<<"/"<<t1/tmp1<<"+";
				}
			}
			else{
				cout<<-t2<<"/"<<t1<<"+";
			}
			int tmp2=gcd(p1,t1);
			if(tmp2!=1){
				if(p1==t1){
					cout<<"sqrt("<<p2<<")"<<endl;
				}
				else if(p1%t1==0){
					cout<<p1/t1<<"*sqrt("<<p2<<")"<<endl;
				}
				else{
					p1/=tmp2;
					t1/=tmp2;
					if(p1==1){
						cout<<"sqrt("<<p2<<")/"<<t1<<endl;
					}
					else
						cout<<p1<<"*sqrt("<<p2<<")/"<<t1<<endl;
				}
			}
			else{
				if(p1==1){
						cout<<"sqrt("<<p2<<")/"<<t1<<endl;
					}
					else
						cout<<p1<<"*sqrt("<<p2<<")/"<<t1<<endl;
			}
		}
	}
}
}
