#include<iostream>
#include<stdio.h> 
using namespace std;
const int Z=100005;
int n,d,money=0,k,S=0,yl;
int v[Z],a[Z];
bool gxd=false;
int main(){
	freopen("road.in","w",stdin);
	freopen("road.out","r",stdout);
	cin>>n>>d;
	for(int i=1;i<n;i++){
		cin>>v[i];
	}for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		gxd=false;
		S=0;
		for(int j=i;j<n;j++){
			S+=v[j-1];
			v[j-1]=0;
			if(a[j]<a[i]){
				k=j;
				gxd=true;
				break;
			}
		}if(S==0){
			S=v[i];
		}
			if(S%d==0){		
				money+=(S/d)*a[i];
			}else{
				money+=(S/d+1)*a[i];
			}
		
		if(gxd==false){
			cout<<money;
			return 0;
		}else{
			i=k;
		}
	}
return 0;		
}
