#include<iostream>
#include<stdio.h> 
using namespace std;
int n,jj,a[100000],N,k,iq;
int main(){
	freopen("apple.in","w",stdin);
	freopen("apple.out","r",stdout);
	cin>>n;
	N=n;
	for(int i=1;i<=N;i++){
		a[i]=i;
	}
	for(int j=1;j<=N;j++){
		k=0;
		for(int i=1;i<=N;i++){
			if(a[i]!=0){
				k++;
				if(k%3==1){
					if(a[i]==N){
						jj=j;
					}
					a[i]=0;
					n--;
				}
			}
		}
		if(n==0){
			cout<<j<<" "<<jj;
			return 0;
		}
	}
return 0;		
}
