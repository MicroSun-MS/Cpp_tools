#include<iostream>
#include<stdio.h> 
using namespace std;
int T,M,a,b,c;
int YY(int a,int b,int c){
	int x;
	int y,p,q;
	y=b*b+4*a*c;
	if(y<0){
		cout<<"NO"<<endl;
		return 0;
	} else{
		if(gcd(p,q)==1){
		x=p/q;
	}
		
	}	
}
int gcd(int p,int q){
	if(q==1){
		return p;
	}else{
		return gcd(q,p%q);
	}
}
int main(){
	freopen("uqe.in","w",stdin);
	freopen("uqe.out","r",stdout);
	cin>>T>>M;
	for(int i=1;i<=T;i++){
		cin>>a>>b>>c;
		YY(a,b,c);
	}
return 0;		
}
