#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=100010;
inline int read(){
	int x=0,fl=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')fl=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+(ch-'0');ch=getchar();}
	return x*fl;
}

int n,d;
int a[maxn],s[maxn];
int st[maxn],tp;
int ans,cur;
signed main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read();d=read();
	for(int i=2;i<=n;i++)s[i]=read()+s[i-1];
	for(int i=1;i<=n;i++)a[i]=read();
	st[++tp]=1;
	for(int i=2;i<n;i++)if(a[i]<a[st[tp]])st[++tp]=i;
	st[++tp]=n;
	for(int i=1;i<tp;i++){
		int dis=s[st[i+1]]-s[st[i]];
		if(cur>=dis){
			cur-=dis;
		}
		else{
			int num=(dis-cur+d-1)/d;
			ans+=num*a[st[i]];cur+=num*d;
			cur-=dis;
		}
		// cout<<ans<<" "<<cur<<" "<<dis<<"\n";
	}
	printf("%lld\n",ans);
}