#include<bits/stdc++.h>
#define int long long
using namespace std;
inline int read(){
	int x=0,fl=1;char ch=getchar();
	while(ch<'0'||ch>'9'){if(ch=='-')fl=-1;ch=getchar();}
	while(ch>='0'&&ch<='9'){x=x*10+(ch-'0');ch=getchar();}
	return x*fl;
}

int n,m,ans;
signed main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	n=read();m=n;
	while(n){
		n-=(n+2)/3;
		++ans;
	}
	printf("%lld ",ans);
	ans=0;while(m){
		++ans;
		if((m+2)%3==0)break;
		m-=(m+2)/3;
	}
	printf("%lld\n",ans);
}
