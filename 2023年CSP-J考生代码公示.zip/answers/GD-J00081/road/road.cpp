#include<bits/stdc++.h>
using namespace std;
long long n=0,d=0,i=0,j=0,k=0,s=0,c=0,f=0,e=0;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld%lld",&n,&d);
	long long v[n-1],a[n];
	for(i=0;i<n-1;i++){
		scanf("%lld",&v[i]);
	}
	for(i=0;i<n;i++){
		scanf("%lld",&a[i]);
	}
	i=0;
	while(i<n-1){
		j=i+1;
		while(a[j]>=a[i] && j<n-1){
			j++;
		}
		s=0;
		for(k=j-1;k>=i;k--){
			s+=v[k];
		}
		s-=e;
		if(s%d==0){
			f=s/d;
			c+=f*a[i];
		}
		else{
			f=s/d+1;
			c+=f*a[i];
		}
		e=f*d-s;
		i=j;
	}
	printf("%lld\n",c);
} 
