#include<bits/stdc++.h>
using namespace std;
long long c=0;
int main(){
	for(long long i=0;i<=10000;i++){
		c++;
	}
	printf("-1\n");
}
