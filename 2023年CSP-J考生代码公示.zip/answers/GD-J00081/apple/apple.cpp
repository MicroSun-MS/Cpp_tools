#include<bits/stdc++.h>
using namespace std;
long long n=0,c=0,a=0,b=0;
bool d=1;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%lld",&n);
	while(n){
		a=n/3;
		if(n%3==1 && d==1){
			b=c+1;
			d=0;
		}
		if(n%3==0){
			n-=a;
		}
		else{
			n-=a+1;
		}
		c+=1;
	}
	printf("%lld %lld\n",c,b);
} 
