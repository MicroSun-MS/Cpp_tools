#include<stdio.h>
long long t,m,a,b,c;
long long gcdsss(long long aaa,long long bbb)
{while(bbb){long long rrr=aaa%bbb;aaa=bbb,bbb=rrr;} return aaa;}
long long sqrtsss(long long num)
{long long i=1; while(i*i<=num) i++; return i-1;}
long long absss(long long num){return num>0?num:-num;}
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%lld%lld",&t,&m);
	while(t--)
	{
		scanf("%lld%lld%lld",&a,&b,&c);
		if(b*b-4*a*c<0) {printf("NO\n");continue;}
		long long num=sqrtsss(b*b-4*a*c);
		if(num*num==b*b-4*a*c)
		{
			if(2*a>0&&-b+num>-b-num||2*a<0&&-b+num<-b-num)
			{
				if((-b+num)%(2*a)==0) printf("%lld\n",(-b+num)/(2*a));
				else
				{
					long long hme1=-b+num,hme2=2*a;
					if(2*a<0) hme1=-hme1,hme2=-hme2;
					long long gcder=gcdsss(absss(hme1),absss(hme2));
					printf("%lld/%lld\n",hme1/gcder,hme2/gcder);
				}
			}
			else
			{
				if((-b-num)%(2*a)==0) printf("%lld\n",(-b-num)/(2*a));
				else
				{
					long long hme1=-b-num,hme2=2*a;
					if(2*a<0) hme1=-hme1,hme2=-hme2;
					long long gcder=gcdsss(absss(hme1),absss(hme2));
					printf("%lld/%lld\n",hme1/gcder,hme2/gcder);
				}
			}
		}
		else
		{
			long long q1zi=-b,q1mu=2*a,q2zi=1,q2mu=2*a,r=b*b-4*a*c;
			for(int i=2;i*i<=r;i++) while(r%(i*i)==0) q2zi*=i,r/=(i*i);
			if(q1zi!=0)
			{
				if(q1zi%q1mu==0) printf("%lld+",q1zi/q1mu);
				else
				{
					long long hme1=q1zi,hme2=q1mu;
					if(hme2<0) hme1=-hme1,hme2=-hme2;
					long long gcder=gcdsss(absss(hme1),absss(hme2));
					printf("%lld/%lld+",hme1/gcder,hme2/gcder);
				}
			}
			if(((q2zi<0)+(q2mu<0)+(r<0))&1) q2zi=-q2zi;
			if(q2zi==q2mu) printf("sqrt(%lld)\n",r);
			else if(q2zi%q2mu==0) printf("%lld*sqrt(%lld)\n",q2zi/q2mu,r);
			else if(q2mu%q2zi==0) printf("sqrt(%lld)/%lld\n",r,q2mu/q2zi);
			else
			{
				long long hme1=q2zi,hme2=q2mu;
				if(hme2<0) hme1=-hme1,hme2=-hme2;
				long long gcder=gcdsss(absss(hme1),absss(hme2));
				printf("%lld*sqrt(%lld)/%lld\n",hme1/gcder,r,hme2/gcder);
			}
		}
	}
}
