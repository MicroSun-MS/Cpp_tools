#include<stdio.h>
#include<string.h>
long long n,m,k,first[10005],num,a,b,c,f[10005],ff=1;
struct sss{long long end,next,could;}bian[20005];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k),memset(f,0x3f,sizeof(f)),f[1]=0;
	for(int i=1;i<=m;i++) scanf("%lld%lld%lld",&a,&b,&c),ff=(c==0)?ff:0,
	bian[++num].end=a,bian[num].next=first[b],bian[num].could=c,first[b]=num;
	if(k==1&&ff) {for(int i=2;i<=n;i++) for(int j=first[i];j;j=bian[j].next)
	if(f[i]>(f[j]+1<bian[j].could?bian[j].could:f[j]+1))
	f[i]=(f[j]+1<bian[j].could?bian[j].could:f[j]+1);}
	else f[n]=-1;
	printf("%lld",f[n]);
}
