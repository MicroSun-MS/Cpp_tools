#include<stdio.h>
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	long long n,ans=0,anss=-1;
	scanf("%lld",&n);
	while(n)
	{
		if(n%3==1&&anss==-1) anss=ans+1;
		ans++,n-=(n/3+(n%3==0?0:1));
	}
	printf("%lld %lld",ans,anss);
}
