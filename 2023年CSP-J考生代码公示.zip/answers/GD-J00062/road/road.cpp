#include<stdio.h>
long long n,num,money[100005],juli[100005],ans,shengyu,last=1;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld%lld",&n,&num);
	for(int i=1;i<n;i++) scanf("%lld",&juli[i]);
	for(int i=1;i<=n;i++) scanf("%lld",&money[i]);
	for(int i=2;i<=n;i++)
	{
		if(money[last]>money[i-1]) last=i-1;
		long long need=juli[i-1]-shengyu;
		if(need%num==0) ans+=need/num*money[last],shengyu=0;
		else ans+=(need/num+1)*money[last],shengyu=num-need%num;
	}
	printf("%lld",ans);
}
