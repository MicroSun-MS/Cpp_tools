#include<bits/stdc++.h>
using namespace std;

int n;
int cnt,ans;

signed main()
{
	freopen("apple.in","r",stdin);
//	freopen("apple2.in","r",stdin);
//	system("fc apple.out apple2.ans");
//	return 0;
	freopen("apple.out","w",stdout);
	
	scanf("%d",&n);
	
	while(n)
	{
		cnt++;
		if(ans==0&&n%3==1) ans=cnt;
		n=n*2/3;
	}
	
	printf("%d %d",cnt,ans);
	
	return 0;
}
