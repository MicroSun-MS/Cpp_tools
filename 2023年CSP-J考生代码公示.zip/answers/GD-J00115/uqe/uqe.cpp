#include<bits/stdc++.h>
using namespace std;

int gcd(int a,int b)
{
	if(a%b==0) return b;
	else return gcd(b,a%b);
}
inline void print(int x,int y)
{
	int tmp=gcd(x,y);
	x/=tmp,y/=tmp;
	if(y<0) x=-x,y=-y;
	if(y==1) printf("%d",x);
	else printf("%d/%d",x,y);
}

signed main()
{
	freopen("uqe.in","r",stdin);
//	freopen("uqe1.in","r",stdin);
//	system("fc uqe.out uqme1.ans");
//	return 0;
	freopen("uqe.out","w",stdout);
	
	int T,m;
	int a,b,c;
	int d,sq;
	int td,tmp;
	int x,y;
	scanf("%d%d",&T,&m);
	while(T--)
	{
		scanf("%d%d%d",&a,&b,&c);
		d=b*b-4*a*c;
		if(d<0) printf("NO");
		else if(d>=0)
		{ 
			sq=1,td=d;
			for(int i=2;i*i<=td;i++)
			{
				tmp=0;
				while(td%i==0)
				{
					if(tmp) sq*=i;
					tmp^=1;
					td/=i;
				}
			}
			if(a<0) sq=-sq;
			if(d==0) print(-b,2*a);
			else if(sq*sq==d) print(-b+sq,2*a);
			else
			{
				d/=sq*sq; 
				if(b!=0) print(-b,2*a),printf("+");
				
				x=sq,y=2*a;
				int tmp=gcd(x,y);
				x/=tmp,y/=tmp;
				if(y<0) x,y=-y;
				if(x==1&&y==1) printf("sqrt(%d)",d);
				else if(x==1) printf("sqrt(%d)/%d",d,y);
				else if(y==1) printf("%d*sqrt(%d)",x,d);
				else printf("%d*sqrt(%d)/%d",x,d,y);
			}
		}
		printf("\n");
	}
	
	
	return 0;
}
