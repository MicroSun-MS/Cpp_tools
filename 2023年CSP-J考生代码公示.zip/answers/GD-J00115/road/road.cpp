#include<bits/stdc++.h>
using namespace std;

#define int long long
const int maxn=1e5;

int n,d;
int v[maxn+5],a[maxn+5];

int sum[maxn+5];
int ve[maxn+5],vet;
int ans,to,ned;

signed main()
{
	freopen("road.in","r",stdin);
//	freopen("road2.in","r",stdin);
//	system("fc road.out road2.ans");
//	return 0;
	freopen("road.out","w",stdout);
	
	scanf("%lld%lld",&n,&d);
	for(int i=2;i<=n;i++)
	{
		scanf("%lld",&v[i]);
		sum[i]=sum[i-1]+v[i];
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
		if(vet==0||a[ve[vet-1]]>a[i]) ve[vet++]=i;
	}
	
	ve[vet]=n;
	for(int i=0;i<vet;i++)
	{
		if(to>=sum[ve[i]+1]) continue;
		ned=ceil((sum[ve[i+1]]-to)*1.0/d);
		ans+=a[ve[i]]*ned;
		to+=ned*d;
	}
	
	printf("%lld",ans);
	
	return 0;
}
