#include<bits/stdc++.h>
using namespace std;

const int maxn=2*1e4;
const int maxk=1e2;

int n,m,K;
struct Edge{int v,w,nxt;};
Edge e[maxn+5];
int hd[maxn+5],et;

struct Point
{
	int x,y,w;
	Point(int ix=0,int iy=0,int iw=0){x=ix,y=iy,w=iw;}
	bool operator <(const Point &a)const{return w*K+y>a.w*K+a.y;}
};
int dis[maxn+5][maxk+5];
bool vis[maxn+5][maxk+5];
priority_queue<Point> qu;

inline void Adde(int u,int v,int w)
{
	e[et].v=v,e[et].w=w;
	e[et].nxt=hd[u],hd[u]=et++;
}

inline void Dijstra()
{
	Point t;
	int u,r,v,w;
	memset(dis,0x3f,sizeof(dis));
	dis[1][0]=0;
	qu.push(Point(1,0,0));
	while(!qu.empty())
	{
		t=qu.top();
		u=t.x;
		qu.pop();
		if(vis[u][t.y]) continue;
		vis[u][t.y]=1;
		for(int i=hd[u];~i;i=e[i].nxt)
		{
			v=e[i].v;
			w=t.w;
			r=t.y;
			if(w*K+t.y<e[i].w) w+=ceil((e[i].w-w*K-t.y)*1.0/K);
			if((r+1)%K==0)  w++,r=0;
			else r=(r+1)%K;
			if(dis[v][r]>w)
			{
				dis[v][r]=w;
				qu.push(Point(v,r,w));
			}
		}
	}
}


signed main()
{
	freopen("bus.in","r",stdin);
//	freopen("bus1.in","r",stdin);
//	system("fc bus.out bus1.ans");
//	return 0;
	freopen("bus.out","w",stdout);
	
	int u,v,w;
	memset(e,-1,sizeof(e));
	memset(hd,-1,sizeof(hd));
	scanf("%d%d%d",&n,&m,&K);
	while(m--)
	{
		scanf("%d%d%d",&u,&v,&w);
		Adde(u,v,w);
	}
	
	Dijstra();
	
	if(dis[n][0]==dis[0][0]) printf("-1");
	else printf("%d",dis[n][0]*K);
	
	return 0;
}
