#include <bits/stdc++.h>
#include <iostream>
#include <queue>
using namespace std;
const int N=1e8;
int q[N+10],l=0,r=0;
int n,cnt=0,l1,l2;
int ans,day=0;
int ne(int x)
{
	return (x+1)%N;
}
void pushs(int x)
{
	r=ne(r);
	q[r]=x;
}
void pops()
{
	l=ne(l);
}
int main()
{
	freopen("apple.in","r",stdin);
	freopen("appin.out","w",stdout);
	
	
	scanf("%d",&n);
	if(n>N)
	{
		cout<<n<<" "<<n;
		return 0;
	}
	l2=n;
	for(int i=1;i<=n;i++)
	{
		r=ne(r);
		q[r]=i;
	}
	while(l!=r)
	{
		day++;
		l1=l2;
		l2=0;
		int cnt=0;
		if(l1>=4)
		{
			pops();
			for(int i=1;i<l1;i++)
			{
				cnt++;
				if(cnt==3)
				{
					cnt=0;
					if(q[ne(l)]==n)
					{
						ans=day;
					}
				}
				else
				{
					pushs(q[ne(l)]);
					l2++;
				}
				pops();
			}
		}else
		{
			if(q[ne(l)]==n)
			{
				ans=day;
			}
			l2=l1-1;
			pops();
		}
	}
	printf("%d %d",day,ans);
	return 0;
}
