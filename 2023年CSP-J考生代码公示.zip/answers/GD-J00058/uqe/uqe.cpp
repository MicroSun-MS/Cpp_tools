#include <bits/stdc++.h>
#include <iostream>
using namespace std;
int n,m,a,b,c;
int ch;
int p[1010],g[1010],k=0;
class root
{
	public:
		int p,q,r;
};
int gcd(int x,int y)
{
	if(y==0)return x;
	else return gcd(y,x%y);
}
void gc(int &p,int &q)
{
	bool flag=false;
	if(p*q<0)flag=true;
	p=abs(p);q=abs(q);
	int g=gcd(p,q);
	p/=g,q/=g;
	if(flag==true)p=-p;
}
void fun(root &a)
{
	if(a.q<0)a.r*=-1;
	if(a.p<0)a.r*=-1;
	a.q=abs(a.q),a.p=abs(a.p);
	for(int i=1;i<=k;i++)
	{
		if(a.r%p[i]==0)
		{
			a.r/=p[i];
			a.p*=g[i];
		}
	}
	int g=gcd(a.p,a.q);
	a.p/=g,a.q/=g;
}
void init()
{
	for(int i=1;i*i<=m;i++)
	{
		p[++k]=i*i;
		g[k]=i;
	}
}
void print(root a)
{
	cout<<a.p<<" "<<a.q<<" "<<a.r<<endl;
}
bool check(int x)
{
	if(x==0)return true;
	for(int i=1;i<=k;i++)
	{
		if(x==p[i])return true;
	}
	return false;
}
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	
	
	scanf("%d%d",&n,&m);
	init();
	
	
	
	
	while(n--)
	{
		scanf("%d%d%d",&a,&b,&c);
		ch=b*b-4*a*c;
		if(ch<0)
		{
			printf("NO\n");
		}else
		{
			if(check(ch)) 
			{
				int sq=sqrt(ch);
				if((sq-b)%(2*a)==0)
				{
					printf("%d\n",(-b+sq)/2/a);
				}else 
				{
					int p=sq-b;
					int q=2*a;
					gc(p,q);
					printf("%d/%d\n",p,q);
				}
			}else
			{
				int p=-b;
				int q=2*a;
				gc(p,q);
				if(p!=0)
				{
					if(p%q!=0)printf("%d/%d+",p,q);
					if(p%q==0)printf("%d+",p/q);
				}
				
				root r={1,2*a,ch};
				fun(r);
				if(r.p==r.q)printf("sqrt(%d)\n",ch);
				else if(r.p%r.q==0)printf("%d*sqrt(%d)\n",r.p/r.q,r.r);
				else if(r.p==1)printf("sqrt(%d)/%d\n",r.r,r.q);
				else printf("%d*sqrt(%d)/%d\n",r.p,r.r,r.q);
			}
		}
	}
	return 0;
}
