#include <bits/stdc++.h>
#include <iostream>
using namespace std;
const int N=1e4+10;
const int M=2e4+10;
const int Q=1e6;
class node
{
	public:
		int to;
		int next;
		int time;
};
class point
{
	public:
		int num;
		int time;
};
point q[Q+10];
int l=1,r=1;
node e[M];
int pre[N],idx=0;
int n,m,k;
int x,y,t;
int cnt=0;
int ans=1e8;
void add(int u,int v,int time)
{
	e[++idx]={v,pre[u],time};
	pre[u]=idx;
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d%d",&x,&y,&t);
		add(x,y,t);
	}
	q[l]={1,k};
	while(cnt<=1e6)
	{
		cnt++;
		int p=q[l].num,t=q[l].time;
		if(p==n&&t%k==0)
		{
			ans=min(ans,t);
		}
		for(int i=pre[p];i;i=e[i].next)
		{
			int to=e[i].to;
			if(t>=e[i].time)q[++r]={to,t+1};
			else q[++r]={to,e[i].time+1};
		}
		l++;
	};
	if(ans==1e8)printf("NO");
	else printf("%d",ans);
	return 0;
}
