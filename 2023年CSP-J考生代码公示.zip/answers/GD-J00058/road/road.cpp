#include <bits/stdc++.h>
#include <iostream>
using namespace std;
const int N=1e5+10;
int a[N],v[N];
long long sum[N];
int n,d,mi=INT_MAX;
long long ex(long long x,long long y)
{
	if(x%y==0)return x/y;
	return x/y+1;
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	
	scanf("%d%d",&n,&d);
	for(int i=1;i<n;i++)
	{
		scanf("%d",&v[i]);
		sum[i+1]=v[i];
		sum[i+1]+=sum[i];
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		mi=min(a[i],mi);
	}
	if(mi==a[1])
	{
		long long s=0;
		for(int i=1;i<=n;i++)s+=v[i];
		long long ans=ex(s,d)*mi;
		printf("%lld",ans);
		return 0;
	}
	int p=0,st=1;
	long long ans=0;
	for(int i=1;i<=n-1;i++)
	{
		if(i<=n-2&&a[i+1]<a[i])continue;
		long long e=ex(sum[i]-p,d);
		p=e*d+p;
		ans=ans+e*a[st];
		st=i;
	}
	ans=ans+ex(sum[n]-p,d)*a[st];
	printf("%lld",ans);
	return 0;
}
