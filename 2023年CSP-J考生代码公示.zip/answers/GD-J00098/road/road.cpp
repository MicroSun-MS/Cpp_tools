#include<bits/stdc++.h> 
using namespace std;
int n,ans=0,x,y,m,d;
struct car{
	int lc,q;
}a[100005];
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&d);
	for(int i=1;i<=n-1;i++)
		scanf("%d",&a[i].lc );
	for(int i=1;i<=n;i++)
		scanf("%d",&a[i].q ); 
		int i;
	for(i=1;i<=n;i++){
		if(y>=a[i].lc ){
			y-=a[i].lc ;
			continue;
		}
		x=1;
		while(a[i].q<=a[i+x].q ){
			a[i].lc +=a[i+x].lc ;
			a[i+x].lc =0;
			x++; 
		}
		m=a[i].lc /d;
		if(m*d+y<a[i].lc )
			m++;
		ans+=m*a[i].q ;
		y+=m*d;
		y-=a[i].lc ;
	}
	cout<<ans;
	return 0;
}
