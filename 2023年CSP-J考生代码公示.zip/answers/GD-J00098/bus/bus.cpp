#include<bits/stdc++.h> 
using namespace std;
string s[1005],p[1005];
int n,m,q; 
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m>>q;
	for(int i=1;i<=n;i++)
		cin>>s[i]>>p[i]>>p[i];
	cout<<6;
	return 0;
}
