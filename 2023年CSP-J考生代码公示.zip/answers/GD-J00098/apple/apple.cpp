#include<bits/stdc++.h> 
using namespace std;
int n,ans=0,x,p,t,h=1;
bool b[1000000001];
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);
	while(p<n){
		ans++;
		while(b[h]==1)
			h++;
		for(int i=h;i<=n;){
			while(b[i]){
				i++;
			}
			b[i]=1;
			p++;
			if(i==n)
				x=ans;
			int s=1; 
			while(s<=3){
				i++;
				if(!b[i])
					s++;
			}
		}
	} 
	printf("%d %d",ans,x);
	return 0;
}
