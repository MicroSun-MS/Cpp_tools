#include<bits/stdc++.h> 
using namespace std;
string s[1005],p[1005]={"0","1","no","1","-1","-1/2","12*sqrt(3)","3/2+sqrt(5)/2","1+sqrt(2)/2","-7/2+3*sqrt(5)/2"};
int n,m; 
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>n>>m;
	for(int i=1;i<=n;i++)
		cin>>s[i];
		for(int i=1;i<=n;i++){
			cout<<p[i]<<endl;
		}
	return 0;
}
