#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N = 1e5 + 10;

int n , d , ans , t;
double temp;
//temp: ʣ�µ���
int v[N] , a[N];
bool m[N];

signed main()
{
	freopen("road.in" , "r" , stdin);
	freopen("road.out" , "w" , stdout);
	int minn = 1e9 , ss = 0;
	cin >> n >> d;
	for(int i = 1 ; i < n ; i++)
	{
		cin >> v[i];
		ss += v[i];
	}
	for(int i = 1 ; i <= n ; i++)
	{
		cin >> a[i];
		minn = min(minn , a[i]);
	}
	if(minn == a[1])
	{
		cout << ceil(1.0 * ss / d) * a[1];
	}
	for(int i = 1 ; i <= n ; i++)
	{
		if(i != n)
		{
			int cnt = 0;
			for(int j = i ; j <= n ; j++)
			{
				if(a[j] >= a[i] && m[j] == 0)
				{
					m[j] = 1;
					cnt += v[i];
				}
				else break;
			}
			if(cnt - temp >= 0) t = ceil(1.0 * (cnt - temp) / d) * a[i];
			else t = ceil(1.0 * cnt / d) * a[i];
			temp += double(1.0 * (cnt - temp) / d);
//			cout << i << ' ' << cnt << ' ' << temp << ' ' << t << endl;
			ans += t;
		}
	}
	cout << ans;
	return 0;
} 
