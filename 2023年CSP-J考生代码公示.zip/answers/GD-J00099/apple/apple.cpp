#include<bits/stdc++.h>
#define int long long
using namespace std;

int n;
int ans1 , ans2;
bool f = 0;

signed main()
{
	freopen("apple.in" , "r" , stdin);
	freopen("apple.out" , "w" , stdout);
	cin >> n;
	for(int i = 1 ; n ; i++)
	{
		if(n % 3 == 1 && f == 0)
		{
			ans2 = i;
			f = 1;
		}
		if(n <= 3) n--;
		else n -= ceil(1.0 * double(n / 3) + 1);
		ans1++;
	}
	cout << ans1 << ' ' << ans2;
	return 0;
}
//csp-j���� rp += INF 
