#include<bits/stdc++.h>
#define int long long
using namespace std;

int T;

signed main()
{
	freopen("uqe.in" , "r" , stdin);
	freopen("uqe.out" , "w" , stdout);
	cin >> T;
	while(T--)
	{
		cout << 0 << '\n';
	}
	return 0;
} 
