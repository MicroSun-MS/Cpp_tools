#include <bits/stdc++.h>
using namespace std;

const int maxn = 1e4+10;
vector<int> a[maxn];
int n,m,k,ans=1e9;
void dfs(int t,int ti){
	if (t==n && ti%k==0){
		ans=min(ti,ans);
		return ;
	}
	for (int i=0;i<a[t].size();i++){
		dfs(a[t][i],ti+1);
	}
}
int main() {
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin >> n >> m >> k;
	int x,y,z;
	for (int i=1;i<=m;i++){
		cin >> x >> y >> z;
		a[x].push_back(y);
	}
	dfs(1,0);
	if (ans!=1e9) cout << ans;
	else cout << -1;
	fclose(stdin);
	fclose(stdout);
}
