#include <bits/stdc++.h>
using namespace std;
int n,m,cnt,ans,temp,flag;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
  	cin >> n;
  	int m=n;
  	while (n>0){
  		if (m%3==1 && flag==0){
  			ans=cnt+1;
  			flag=1;
		} 
		temp=(n-1)/3+1;
  		n-=temp;
  		m=n;
  		cnt++;
	}
	cout << cnt << " " << ans;
	fclose(stdin);
	fclose(stdout);
}
