#include <bits/stdc++.h>
using namespace std;

const int maxn = 1e5+10;
int a[maxn],v[maxn];
int cnt;
long long n,d,las;
int count(int st,int end){
	int p=0;
	for (int i=st;i<end;i++){
		p+=v[i];
	}
	p-=las;
	if (p%d==0) return p/d;
	las=p%d;
	return p/d+1;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
  	cin >> n >> d;
	for (int i=1;i<n;i++) cin >> v[i];
	for (int i=1;i<=n;i++) cin >> a[i];
	int way=1,cost=0;
	while (way<n){
		cnt=way+1;
		while (a[way]<a[cnt] && cnt<=n) cnt++;
		cost+=(count(way,cnt)*a[way]);
		way=cnt;
	}
	cout << cost;
	fclose(stdin);
	fclose(stdout);
}
