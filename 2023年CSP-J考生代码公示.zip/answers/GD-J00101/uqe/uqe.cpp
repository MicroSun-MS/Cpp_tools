#include <cstdio>
#include <cmath>
#include <algorithm>
using namespace std;
int T,M;
int gcd(int x,int y)
{
	while(x!=0)
	{
		int tmp=y%x;
		y=x;
		x=tmp;
	}
	return y;
}
void outp(int x,int y)
{
	int gc=gcd(x,y);
	x/=gc,y/=gc;
	if(y<0)x=-x,y=-y;
	if(y==1)printf("%d",x);
	else printf("%d/%d",x,y);
}
void outp_rr(int x,int rr,int y)
{
	int gc=gcd(x,y);
	x/=gc,y/=gc;
	x=abs(x),y=abs(y);
	if(x==1&&y==1)printf("sqrt(%d)",rr);
	else if(y==1)printf("%d*sqrt(%d)",x,rr);
	else if(x==1)printf("sqrt(%d)/%d",rr,y);
	else if(x!=1&&y!=1) printf("%d*sqrt(%d)/%d",x,rr,y);
}
int main()
{
	freopen("uqe2.in","r",stdin);
	freopen("uqe2.out","w",stdout);
	scanf("%d%d",&T,&M);
	while(T--)
	{
		int a,b,c;
		scanf("%d%d%d",&a,&b,&c);
		int dlt=b*b-4*a*c;
		if(dlt<0)
		{
			printf("NO\n");
			continue;
		}
		int sqdl=sqrt(dlt);
		if(sqdl*sqdl==dlt)
		{
			if(2*a<0)outp(min(-b+sqdl,(-b-sqdl)),2*a);
			else outp(max(-b+sqdl,(-b-sqdl)),2*a);
			printf("\n");
			continue;
		}
		if((-b)*1.0/(2*a)!=0)
		{
			outp((-b),2*a);
			printf("+");
		}
		int q2,rr;
		for(int i=1; i*i<=dlt; ++i)
		{
			if(dlt%(i*i)==0)
			{
				q2=i;
				rr=dlt/(i*i);
			}
		}
		outp_rr(q2,rr,2*a);
		printf("\n");
	}
	return 0;
}
