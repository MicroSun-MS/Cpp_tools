#include <cstdio>
using namespace std;
int n,tn,cnt,ans;
bool flag=0;
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);
	int tn=n;
	for(cnt=0; tn;)
	{
		++cnt;
		if(tn%3==1&&!flag)
		{
			flag=1;
			ans=cnt;
		}
		if(tn%3>0)tn-=tn/3+1;
		else tn-=tn/3;
	}
	printf("%d %d",cnt,ans);
	return 0;
}
