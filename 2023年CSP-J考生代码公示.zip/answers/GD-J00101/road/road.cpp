#include <cstdio>
using namespace std;
const int N=1e5;
int a[N],b[N],n,m,ans,minn=2147483647,fueltk;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;++i)scanf("%d",&a[i]);
	for(int i=1;i<=n;++i)scanf("%d",&b[i]);
	for(int i=1;i<=n;++i)
	{
		if(b[i]<minn)minn=b[i];
		if(fueltk>=a[i]){fueltk-=a[i];continue;}
		int x1=a[i]-fueltk;
		int ol=x1%m?x1/m+1:x1/m;
		fueltk=ol*m-x1;
		ans+=minn*ol;
	}
	printf("%d",ans);
	return 0;
}
