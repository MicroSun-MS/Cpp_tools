#include<iostream>
#include<cstdio>
#define maxn 1000000002
using namespace std;
int n,m,days1=0,days2=0;
bool a[maxn];
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	m=n;
	for(int i=1;i<=n;i++)  a[i]=true;
	while(m>0)
	{
		days1++;
		int l=1;
		for(int i=1;i<=n;i++)
		{
			if(a[i]!=false)
			{
			    if(l>3)  l=1;
			    if(l==1)  
			    {
			        a[i]=false;
			        if(i==n)  days2=days1;
			        m--;
			    }
			    l++;
			}
			else  continue;
		}
	}
	cout<<days1<<" "<<days2<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
