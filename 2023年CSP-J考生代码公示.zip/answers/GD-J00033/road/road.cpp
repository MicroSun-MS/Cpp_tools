#include<iostream>
#include<cstdio>
#include<iomanip>
using namespace std;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,d,v[100002],a[100002],nextsta=1,nowsta=1,m=0;int oil2=0;double oil1=0,oil3=0;
	cin>>n>>d;
	for(int i=1;i<=n;i++)
	{
		if(i<n)  cin>>v[i];
		else  v[i]=0;
	}
	for(int i=1;i<=n;i++)  cin>>a[i];
	while(nowsta!=n)
	{
		int dis=0;
		for(int i=nowsta+1;i<=n;i++)
		{
			dis+=v[i-1];
			if(a[i]<a[nowsta])
			{
				nextsta=i;
				break;
			}
			else  continue;
		}
		oil3=(double)dis/d;
		if((oil3-(oil1/1))-(oil3/1)!=0) 
		{
			oil2=oil3-(oil1/1)+1;
		}
		else  oil2=oil3-(oil1/1);
		m+=oil2*a[nowsta];
		nowsta=nextsta;
		oil1+=(double)oil2-oil3;
		oil2=0,oil3=0;
	}
	cout<<m<<endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
