#include<bits/stdc++.h>
using namespace std;

int t,m;

bool is(double a){
	int b=a;
	return (a==b ? true : false);
}

int find(int a){
	int out=0;
	for(int i=2;i<=sqrt(m);i++){
		if(a%(i*i)==0){
			out=i;
		}
	}
	return out;
}



int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	double san,x;
	int a,b,c;
	cin>>t>>m;
	
	for(int i=0;i<t;i++){
		cin>>a>>b>>c;
		san=b*b-4*a*c;
		if(san<0){
			cout<<"NO"<<endl;
			continue;
		}
		double linshi=(-b+sqrt(san))/(2*a);
		if(is(linshi)){
			cout<<linshi<<endl;
			continue;
		}
		else if(b==0){
			int zzz=find(-c/a);
			cout<<zzz<<"*sqrt("<<-c/a/zzz/zzz<<")"<<endl;
			continue;
		}
	}

	return 0;
}
