#include<bits/stdc++.h>
using namespace std;
long long day=0,n;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);

	bool temp=true;
	int ans;
	cin>>n;
	
	
	while(n!=0){
		if(n<=3){
			day+=n;
			if(temp){
				ans=day;
				
			}
			break;
		}
		if(temp){
			if(n%3==1){
				temp=false;
				ans=day+1;
			}
		}
		if(n/3==0){
			n-=n/3;
		}
		else{
			n-=n/3+1;
		}
		day++;
	}
	
	cout<<day<<" "<<ans;
	return 0;
}
