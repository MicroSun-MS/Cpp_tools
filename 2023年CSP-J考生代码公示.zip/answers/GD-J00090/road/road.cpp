#include<bits/stdc++.h>
using namespace std;
int v[100005],s[100005];

int dis(int a,int b){
	int dis=0;
	for(int i=a;i<b;i++){
		dis+=s[i];
	}
	return dis;
}

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	int n,d,ky=0,next=2,now=1,total=0,disnext=0,you=0,diss=0;
	cin>>n>>d;
	for(int i=1;i<n;i++){
		cin>>s[i];
	}
	for(int i=1;i<=n;i++){
		cin>>v[i];
	}
	while(now<n){
		//cout<<now<<" "<<next<<" "<<total<<endl;
		while(v[next]>=v[now] && next<=n){
			next++;
		}
		if(next>=n){
			total=total+( ( (dis(now,n) -ky)%d==0) ? (dis(now,n) -ky)/d : (dis(now,n) -ky)/d+1) *v[now];
			break; 
		}
		else{
			diss=dis(now,next);
			you=( ( (dis(now,next) -ky)%d==0) ? (dis(now,next) -ky)/d : (dis(now,next) -ky)/d+1);
			total=total+you*v[now]; 
			ky=you*d-diss+ky;
			now=next;
			next++;
		}
	}
	
	cout<<total;
	
	return 0;
}
