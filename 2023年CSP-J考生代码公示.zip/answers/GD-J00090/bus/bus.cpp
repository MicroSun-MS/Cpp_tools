#include<bits/stdc++.h>
using namespace std;
int n,m,k,s,e,t,maxn=0;
int a[10099][10099];
int lu=0;
void find(int s){
	if(s==n){
		return;
	}
	else{
		for(int i=n;i>s;i--){
			if(a[s][i]==1){
				lu++;
				find(i);
				break;
			}
		}
	}
	return;
}

int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	
	cin>>n>>m>>k;
	for(int i=1;i<=n;i++){
		cin>>s>>e>>t;
		if(t>maxn){
			maxn=t;
		}
		a[s][e]=1;
	}
	if(k==1){
		cout<<lu+maxn;
	}
	else{
		cout<<k;
	}
	
	return 0;
}
