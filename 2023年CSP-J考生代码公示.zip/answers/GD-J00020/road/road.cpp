#include<bits/stdc++.h>
using namespace std;
int n,s,now = 0;
int d[100005],v[100005];
int f[100005];
long long ans = 0;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&s);
	memset(f,0,sizeof(f));
	for(int i = 1;i<n;++i){
		scanf("%d",&d[i]);
	}
	for(int i = 1;i<=n;++i){
		scanf("%d",&v[i]);
	}
	f[1] = v[1];
	for(int i = 2;i<=n;++i){
		if(v[i]<f[i-1]){
			f[i] = v[i];
		}else{
			f[i] = f[i-1];
		}
	}
	for(int i = 1;i<n;++i){
		int y = (d[i]-now+s-1)/s;
		ans+=f[i]*y; 
		now = y*s-d[i]+now;
	}
	printf("%lld",ans);
	return 0;
} 

