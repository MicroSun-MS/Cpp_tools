#include<bits/stdc++.h>
using namespace std;
long long n,ans,t;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%lld",&n);
	long long m = n;
	long long cnt = 0;
	bool b = true;
	while(m){
		++cnt;
		if(n%3==1&&b){
			t = cnt;
			b = 0;
		}
		m-=n/3;
		if(n%3!=0)m--;
		n = m;
	}
	ans = cnt;
	printf("%lld %lld",ans,t);
	return 0;
} 
