#include<bits/stdc++.h>
using namespace std;
int t,m;
int a,b,c;
int gcd(int a,int b){
	if(abs(a)<abs(b)){
		swap(a,b);
	}
	if(a%b==0){
		return b;
	}
	return gcd(a%b,b);
}
int gen(int x){
	int ans = 1;
	for(int i = 2;i*i<=x;++i){
		if(x%(i*i)==0){
			ans = i;
		}
	}
	return ans;
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&t,&m);
	while(t--){
		scanf("%d%d%d",&a,&b,&c);
		if(a<0){
			a = -a,b = -b,c = -c;
		}
		if(b*b-4*a*c<0){
			printf("NO\n");
			continue;
		}
		int d = b*b-4*a*c;
		b = -b;
		a*=2;
		if(b==0){
			if(d==0){
				printf("0");
			}else if(d/gen(d)==gen(d)){
				d = gen(d);
				int x = gcd(a,d);
				printf("%d/%d",d/x,a/x);
			}else{
				int x = gen(d),y = d/(x*x);
				if(x%a==0){
					if(x==a){
						printf("sqrt(%d)",y);
					}else{
						printf("%d*sqrt(%d)",x/a,y);
					}
				}else{
					int o = gcd(a,b);
					printf("%d*sqrt(%d)/%d",x/o,y,a/o);
				}
			}
		}else if(d/gen(d)==gen(d)){
			d = gen(d);
			b+=d;
			if(b%a==0){
				printf("%d",b/a);
			}else{
				int x = gcd(a,b);
				printf("%d/%d",b/x,a/x);
			}
		}else{
			//cout<<31111;
			if(b%a==0){
				printf("%d",b/a);
			}else{
				int x = gcd(a,b);
				//cout<<x<<endl;
				if(x<0)x = -x;
				printf("%d/%d",b/x,a/x);
			}
			//cout<<1111111;
			int x = gen(d),y = d/(x*x);
			if(d==0||x==0){
				//printf("0");
			}else if(x%a==0){
				if(x==a){
					printf("+sqrt(%d)",y);
				}else{
					printf("+%d*sqrt(%d)",x/a,y);
				}
			}else{
				printf("+");
				int o = gcd(a,x);
				if(x==1||x/o==1){
					printf("sqrt(%d)/%d",y,a/o);
				}else{
					printf("%d*sqrt(%d)/%d",x/o,y,a/o);
				}
			}
		}
		printf("\n");
	}
	return 0;
} 

