#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	long long n,cnt=0,i=0;
	cin>>n;
	while(true){
		i++;
		if((n-1)%3==0&&cnt==0)cnt=i;
		if((n-1)/3*2+(n-1)%3==0){
			break;
		}
		n=(n-1)/3*2+(n-1)%3;
	}
	cout<<i<<" "<<cnt<<endl;
	return 0;
} 
