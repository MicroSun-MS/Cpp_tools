#include<bits/stdc++.h>
using namespace std;
int t,a,b,c,m,aa,bb,cc,dd,ee;
int gcd(int x,int y){
	if(x<y)swap(x,y);
	while(y!=0){
		int k=x%y;
		x=y;
		y=k;
	}
	return x;
}
void hua1(int a,int b){
	aa=a/gcd(a,b);
	bb=b/gcd(a,b);
	return;
}
void hua2(int a,int b){
	for(int i=1;i*i<=a;i++){
		if(a%(i*i)==0)cc=i;
	}
	dd=a/cc/cc;
	int k=cc;
	cc/=gcd(cc,b);
	ee=b/gcd(k,b);
	return;
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>t>>m;
	for(int i=1;i<=t;i++){
		cin>>a>>b>>c;
		aa=bb=cc=dd=ee=0;
		int x=b*b-4*a*c;
		if(x<0)cout<<"NO"<<endl;
		else if(x==0){
			hua1(-b,2*a);
			if(aa%bb==0){
				cout<<aa/bb<<endl;
			}
			else{
				if(bb<0){
					if(aa<0){
						cout<<-aa<<"/"<<-bb<<endl;
					}
					else if(aa==0)cout<<0<<endl;
					else if(aa>0)cout<<-aa<<"/"<<-bb<<endl;
				}
				if(bb>0){
					cout<<aa<<"/"<<bb<<endl;
				}
			}
		}
		else if(x>0){
			if(int(sqrt(x))*int(sqrt(x))==x){
				if((-b+sqrt(x))/(2*a)>(-b-sqrt(x))/(2*a)){
					hua1(-b+sqrt(x),2*a);
					if(aa==0)cout<<0;
					else if(bb==1)cout<<aa;
					else if(aa==bb)cout<<"1";
					else if(bb<0)cout<<"-"<<aa<<"/"<<abs(bb);
					else if(aa<0&&bb<0)cout<<abs(aa)<<"/"<<abs(bb);
					else if(aa!=0&&bb!=0)cout<<aa<<"/"<<bb;
				}
				else{
					hua1(-b-sqrt(x),2*a);
					if(aa==0)cout<<0;
					else if(bb==1)cout<<aa;
					else if(aa==bb)cout<<"1";
					else if(bb<0)cout<<"-"<<aa<<"/"<<abs(bb);
					else if(aa<0&&bb<0)cout<<abs(aa)<<"/"<<abs(bb);
					else if(aa!=0&&bb!=0)cout<<aa<<"/"<<bb;
				}
				cout<<endl;
			}
			else{
				hua1(-b,2*a);
				hua2(x,2*a); 
				if(bb==1&&aa!=0)cout<<aa<<"+";
				else if(aa==bb&&aa!=0)cout<<"1+";
				else if(bb<0&&aa!=0)cout<<"-"<<aa<<"/"<<abs(bb)<<"+";
				else if(aa<0&&bb<0)cout<<abs(aa)<<"/"<<abs(bb)<<"+";
				else if(aa!=0&&bb!=0)cout<<aa<<"/"<<bb<<"+";
				if(cc<0)cc=abs(cc);
				if(cc!=0&&cc!=1)cout<<cc<<"*";
				cout<<"sqrt("<<dd<<")";
				if(ee<0)ee=abs(ee);
				if(ee!=1)cout<<"/"<<ee<<endl;
				else cout<<endl;
			}
		}
	}
	return 0;
}
