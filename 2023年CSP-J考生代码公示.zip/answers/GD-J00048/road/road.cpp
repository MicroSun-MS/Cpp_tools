#include<bits/stdc++.h>
using namespace std;
int n,d,a[100005],w[100005];
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=1;i<n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		cin>>w[i];
	}
	int i=1,cnt=0,s=0;
	while(i<n){
		int sum=0,j=i+1;
		for(;j<=n;j++){
			if(w[j]>=w[i]){
				sum+=a[j-1];
			}
			else break;
		}
		sum+=a[j-1];
		if((sum-s)%d==0)cnt+=(sum-s)/d*w[i];
		else cnt+=((sum-s)/d+1)*w[i];
		s=d-(sum-s)%d;
		i=j;
	}
	cout<<cnt<<endl;
	return 0;
}
