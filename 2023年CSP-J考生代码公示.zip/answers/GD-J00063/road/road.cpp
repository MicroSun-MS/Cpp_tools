#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int n,d;
int a[N],v[N];
struct node{
	int val;
	int pre;
}b[N];
bool cmp(node x,node y){
	if(x.val==y.val) return x.pre<y.pre;
	return x.val<y.val;
}
int id[N];
long long sum=0,ans=1e10;
long long pr,now,l;
bool flag=0;
void dfs(int x,long long w,long long mon){
	if(x==n){
		ans=min(ans,mon);
		return ;
	}
	for(int i=0;i<=l;++i){
		if((i+w)*d>=v[x]){
			dfs(x+1,w+i-(ceil)(1.0*v[x]/d),mon+a[x]*i);
		}
	}
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&d);
	for(int i=1;i<n;++i){
		scanf("%d",v+i);
		sum+=v[i];
		if(v[i]%d!=0) flag=1;
	}
	for(int i=1;i<=n;++i){
		scanf("%d",a+i);
		b[i].val=a[i];
		b[i].pre=i;
	}
	sort(b+1,b+1+n,cmp);
	for(int i=1;i<=n;++i) id[b[i].pre]=i;
	if(id[1]==1){
		ans=ceil(1.0*sum/d)*a[1];
		printf("%lld\n",ans);
		return 0;
	}
	if(flag==0){
		ans+=a[1]*v[1]/d;
		cout<<ans<<endl;
		now=a[1];
		for(int i=2;i<n;++i){
			now=min(now,(long long)a[i]);
			ans+=v[i]/d*now;
		}
		printf("%lld\n",ans);
		return 0;
	}
	l=ceil(1.0*sum/d);
	dfs(1,0,0);
	printf("%lld\n",ans);
	return 0;
}

