#include<bits/stdc++.h>
using namespace std;
const int N=1e6+5;
bool vis[N];
int a[N],ans;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n;
	scanf("%d",&n);
	int flag=-1;
	int cnt=0,q=1;
	while(cnt!=n){
		flag=-1;
		for(int i=1;i<=n;++i){
			if(vis[i]) continue;
			if(flag==-1){
				if(i==n) ans=q;
				a[i]=q;
				vis[i]=1;
				flag=0;
				++cnt;
			}else if(flag==2){
				vis[i]=1;
				if(i==n) ans=q; 
				a[i]=q;
				++cnt;
				flag=0;
			}else{
				++flag;
			}
		}	
		++q;
	}
	printf("%d %d\n",q-1,ans);
	return 0;
}

