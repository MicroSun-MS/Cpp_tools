#include<bits/stdc++.h>
using namespace std;
const int N=1e7+10;
int gcd(int x,int y){
	if(y==0) return x;
	else return gcd(y,x%y);
}
int g[N];
int a,b,c;
int delta,tmp;
int p,q,h,m;
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int T,M;
	scanf("%d%d",&T,&M);
	for(int i=5*M;i>=2;--i){
		tmp=M*M*5/i/i;
		for(int j=1;j<=tmp;++j){
			if(g[j*i*i]==0) g[j*i*i]=i;
			if(gcd(g[j*i*i],i)==1) g[j*i*i]*=i;
		}
	}
	while(T--){
		scanf("%d%d%d",&a,&b,&c);
		delta=b*b-4*a*c;
		if(delta<0){
			printf("NO\n");
			continue;
		}
		int sq=sqrt(delta);
		if(sq*sq==delta){
			if(a>0) p=-b+sq;
			else p=-b-sq;
			q=2*a;
			if(q<0){
				p=-p;
				q=-q;
			}
			h=gcd(p,q);
			if(h<0) h=-h;
			p/=h; q/=h;
			if(q==1){
				printf("%d\n",p);
			}else{
				printf("%d/%d\n",p,q);
			}
		}else{
			if(g[delta]!=0){
				m=g[delta];
				delta=delta/m/m;	
			}else{
				m=1;
			}
			// sqrt(delta) = m*now_delta
			p=-b; q=2*a;
			if(q<0){
				p=-p;
				q=-q;
			}
			h=gcd(p,q);
			if(h<0) h=-h;
			p/=h; q/=h;
			if(p!=0){
				if(q==1){
					printf("%d+",p);
				}else{
					printf("%d/%d+",p,q);
				}
			}
			p=m;
			q=2*a;
			if(q<0){
				q=-q;
			}
			h=gcd(p,q);
			if(h<0) h=-h;
			p/=h; q/=h;
			if(p==1&&q==1){
				printf("sqrt(%d)\n",delta);
				continue;
			}
			if(p==1){
				printf("sqrt(%d)/%d\n",delta,q);
			}else if(q==1){
				printf("%d*sqrt(%d)\n",p,delta);
			}else{
				printf("%d*sqrt(%d)/%d\n",p,delta,q);
			}
		}
	}
	return 0;
}

