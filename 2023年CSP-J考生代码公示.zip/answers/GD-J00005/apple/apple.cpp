#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=500005;
const ll mod=998244353;
int n,m,ans1,ans2;
int main(){
	freopen("apple.in","r",stdin),freopen("apple.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>n;
	for(int i=1;n;i++){
		if(n%3==1&&!ans2)ans2=i;
		n-=((n-1)/3+1),ans1=i;
	}
	cout<<ans1<<' '<<ans2;
	return 0;
}
