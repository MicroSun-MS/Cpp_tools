#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=500005;
const ll mod=998244353;
int n,m,p[N];
ll dis[N],a[N],mx=1e18,res,ans,d;
int main(){
	freopen("road.in","r",stdin),freopen("road.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>n>>d;
	for(int i=2;i<=n;i++)cin>>dis[i];
	for(int i=1;i<=n;i++)cin>>a[i],dis[i]+=dis[i-1];
	for(int i=1;i<=n;i++){
		if(mx>a[i])mx=a[i],p[++m]=i;
	}
	for(int i=1;i<=m;i++){
		if(i<m)ans+=(res>=dis[p[i+1]]-dis[p[i]]?0ll:(dis[p[i+1]]-dis[p[i]]-res+d-1)/d)*a[p[i]],res=(res>=dis[p[i+1]]-dis[p[i]]?res:res+((dis[p[i+1]]-dis[p[i]]-res+d-1)/d)*d-(dis[p[i+1]]-dis[p[i]]));
		else ans+=(res>=dis[n]-dis[p[i]]?0ll:(dis[n]-dis[p[i]]-res+d-1)/d)*a[p[i]];
	}
	cout<<ans;
	return 0;
}
