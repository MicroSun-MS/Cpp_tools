#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=5000005;
const ll mod=998244353;
int t,m;
ll a,b,c,del,num[N],sqr;
ll gcd(ll x,ll y){
	return x%y?gcd(y,x%y):y;
}
int main(){
	freopen("uqe.in","r",stdin),freopen("uqe.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>t>>m,num[0]=1;
	for(int i=1;i<=m*5;i++)for(int j=i*i;j<=5*m*m;j+=i*i)num[j]=max(num[j],1ll*i);
	while(t--){
		cin>>a>>b>>c;
		del=b*b-4ll*a*c;
		if(del<0){cout<<"NO\n";continue;}
		else if(del==0){
			if(b==0)cout<<"0\n";
			else{
				b=-b;
				if(a<0)a=-a,b=-b;
				ll x=gcd(abs(2*a),abs(b));
				if(2*a/x==1)cout<<b/x<<'\n';
				else cout<<b/x<<'/'<<2*a/x<<'\n';
			}
		}else if(num[del]*num[del]==del){
			a=2*a,b=-b+num[del]*(a<0?-1ll:1ll);
			if(b==0)cout<<"0\n";
			else{
				if(a<0)a=-a,b=-b;
				ll x=gcd(abs(a),abs(b));
				if(a/x==1)cout<<b/x<<'\n';
				else cout<<b/x<<'/'<<a/x<<'\n';
			}
		}else{
			ll A=2*a,B=-b;
			ll x;
			if(b!=0){
				x=gcd(abs(A),abs(B));
				if(A<0)A=-A,B=-B;
				if(A/x==1)cout<<B/x<<'+';
				else cout<<B/x<<'/'<<A/x<<'+';
			}
			a=2ll*a;
			if(a<0)a=-a;
			ll y=num[del];
			x=gcd(abs(a),y),del/=(y*y);
			if(y/x>1)cout<<y/x<<'*';
			if(a/x==1)cout<<"sqrt("<<del<<")\n";
			else cout<<"sqrt("<<del<<")/"<<a/x<<'\n';
		}
	}
	return 0;
}
/*
#include<bits/stdc++.h>
#define ll long long
using namespace std;
int mp[10][10],x,y,mx,c,a[10][10],b[10][10],A,B,op;
void print(){
	for(int i=1;i<=4;i++){
		for(int j=1;j<=4;j++)cout<<setw(6)<<mp[i][j]<<' ';
		cout<<'\n';
	}
}
void up(){
	for(int i=1;i<=4;i++)for(int j=1;j<=4;j++)a[i][j]=b[i][j]=0;
	for(int j=1;j<=4;j++){
		int m=0,pre=0;
		for(int i=1;i<=4;i++){
			if(mp[i][j]&&mp[i][j]==mp[pre][j]&&!a[pre][j])b[m][j]*=2,pre=i,a[i][j]=1;
			else if(mp[i][j])pre=i,b[++m][j]=mp[i][j];
		}
	}
	for(int i=1;i<=4;i++)for(int j=1;j<=4;j++)mp[i][j]=b[i][j];
}
void down(){
	for(int i=1;i<=4;i++)for(int j=1;j<=4;j++)a[i][j]=b[i][j]=0;
	for(int j=1;j<=4;j++){
		int m=5,pre=5;
		for(int i=4;i;i--){
			if(mp[i][j]&&mp[i][j]==mp[pre][j]&&!a[pre][j])b[m][j]*=2,pre=i,a[i][j]=1;
			else if(mp[i][j])pre=i,b[--m][j]=mp[i][j];
		}
	}
	for(int i=1;i<=4;i++)for(int j=1;j<=4;j++)mp[i][j]=b[i][j];
}
void lft(){
	for(int i=1;i<=4;i++)for(int j=1;j<=4;j++)a[i][j]=b[i][j]=0;
	for(int i=1;i<=4;i++){
		int m=0,pre=0;
		for(int j=1;j<=4;j++){
			if(mp[i][j]&&mp[i][j]==mp[i][pre]&&!a[i][pre])b[i][m]*=2,pre=j,a[i][j]=1;
			else if(mp[i][j])pre=j,b[i][++m]=mp[i][j];
		}
	}
	for(int i=1;i<=4;i++)for(int j=1;j<=4;j++)mp[i][j]=b[i][j];
}
void rgt(){
	for(int i=1;i<=4;i++)for(int j=1;j<=4;j++)a[i][j]=b[i][j]=0;
	for(int i=1;i<=4;i++){
		int m=5,pre=5;
		for(int j=4;j;j--){
			if(mp[i][j]&&mp[i][j]==mp[i][pre]&&!a[i][pre])b[i][m]*=2,pre=j,a[i][j]=1;
			else if(mp[i][j])pre=j,b[i][--m]=mp[i][j];
		}
	}
	for(int i=1;i<=4;i++)for(int j=1;j<=4;j++)mp[i][j]=b[i][j];
}
int main(){
	mt19937 rnd(time(0));
	A=rnd()%4+1,B=rnd()%4+1;
	mp[A][B]=2;
	while(mp[A][B])A=rnd()%4+1,B=rnd()%4+1;
	mp[A][B]=2;
	print(),mx=2;
	while(mx<2048){
		do{cin>>op;}while(op<1||op>4);
		if(op==1)lft();
		if(op==2)rgt();
		if(op==3)up();
		if(op==4)down();
		mx=c=0;
		for(int i=1;i<=4;i++){
			for(int j=1;j<=4;j++){
				mx=max(mx,mp[i][j]);
				c+=(mp[i][j]>0);
			}
		}
		if(mx==2048)break;
		if(c==16)cout<<"/cf",exit(0);
		A=rnd()%4+1,B=rnd()%4+1;
		while(mp[A][B])A=rnd()%4+1,B=rnd()%4+1;
		mp[A][B]=2;
		system("cls");
		print();
	}
	cout<<"orz!2048!";
	return 0;
}
*/
