#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=10005,M=105;
const ll mod=998244353;
struct node{int d,s;};
struct pos{int x,y;};
int n,m,k,xx,yy,w,tp,ed;
ll dp[N][M];
ll l=-1,r=1e8+1;
vector<node> g[N];
pos q[N*M];
int check(ll res){
	for(int i=1;i<=n;i++)for(int j=0;j<=k;j++)dp[i][j]=-1e13;
	tp=ed=1,q[tp]=(pos){n,0},dp[n][0]=res;
	while(ed<=tp){
		int u=q[ed].x,fl=q[ed].y;
		ed++;
		for(int i=0;i<g[u].size();i++){
			int v=g[u][i].d,t=g[u][i].s;
			if(dp[u][fl]-1>=t&&dp[v][(fl?fl-1:k-1)]<dp[u][fl]-1)dp[v][(fl?fl-1:k-1)]=dp[u][fl]-1,q[++tp]=(pos){v,(fl?fl-1:k-1)};
		}
	}
	return dp[1][0]>=0;
}
int main(){
	freopen("bus.in","r",stdin),freopen("bus.out","w",stdout);
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++)cin>>xx>>yy>>w,g[yy].push_back((node){xx,w});
	while(r-l>1){
		ll mid=(l+r)>>1;
		if(check(mid*k))r=mid;
		else l=mid;
	}
	cout<<r*k;
	return 0;
}
