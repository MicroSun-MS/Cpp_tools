#include<iostream>
#include<cstdio>
namespace SOLVE
{
	template<typename type>
	void read(type &num)
	{
		num=0;
		char c=getchar();
		int n(1);
#define isdigit(c) ((c)>='0'&&(c)<='9')
		while(!isdigit(c)){if(c=='-') n=-1;c=getchar();}
		while(isdigit(c)){num=(num<<1)+(num<<3)+(c^48);c=getchar();}
#undef isdigit
		num*=n;
	}
	const int const1=3e4;
	struct edges
	{
		int from,next,open;
	}edge[const1];
	int Head[const1],cnt;
	void AddEdge(int from,int to,int open)
	{
		edge[++cnt].from=from;
		edge[cnt].next=Head[from];
		Head[from]=cnt;
	}
	void dfs(int begin,int end)
	{
		
	}
	void solve()
	{
		int n,m,k,u,v,a;
		read(n);
		read(m);
		read(k);
		for(i=1;i<=n;++i)
		{
			read(u,v,a);
			AddEdge(u,v,a); 
		}
		
	}
}
int main()
{
//	freopen("bus.in","r",stdin);
//	freopen("bus.out","w",stdout);
	SOLVE::solve();
//	fclose(stdin);
//	fclose(stdout);
	return 0;
}


































