#include<iostream>
#include<cstdio>
namespace SOLVE
{
	template<typename type>
	void read(type &num)
	{
		num=0;
		char c=getchar();
		int n(1);
#define isdigit(c) ((c)>='0'&&(c)<='9')
		while(!isdigit(c)){if(c=='-') n=-1;c=getchar();}
		while(isdigit(c)){num=(num<<1)+(num<<3)+(c^48);c=getchar();}
#undef isdigit
		num*=n;
	}
	int a,b,c,powtable[3000];
	int pow(int x)
	{
		return x*x;
	}
	int abs(int x)
	{
		return x<0?-x:x;
	}
	int gcd(int x,int y)
	{
		if(y==0) return 1;
		if(x%y!=0) return gcd(y,x%y);
		else return y;
	}
	void init_()
	{
		int i;
		for(i=0;i<=2300;++i) powtable[i]=i*i;
	}
	void solve()
	{
		int i,t,m,delta,gcd_,sqr,at,bt;
		init_();
		read(t);
		read(m);
		for(i=1;i<=t;++i)
		{
			read(a);
			read(b);
			read(c);
			delta=pow(b)-4*a*c;
			if(delta<0)
			{
				printf("NO\n");
				continue;
			}
			else if(delta==0)
			{
				a*=2;
				gcd_=gcd(abs(b),abs(a));
				b/=gcd_;
				a/=gcd_;
				if(!((a<0)^(b<0))&&b!=0) putchar('-');
				if(abs(a)==1) printf("%d",abs(b));
				else printf("%d/%d",abs(b),abs(a));
			}
			else if(delta>0)
			{
				sqr=-1;
				for(i=1;delta>=powtable[i];++i) if(delta%powtable[i]==0) sqr=i;
				if(sqr==-1) sqr=delta;
				if(sqr*sqr==delta)
				{
					a*=2;
					b=sqr-b;
					gcd_=gcd(abs(b),abs(a));
					b/=gcd_;
					a/=gcd_;
					if((a<0)^(b<0)) putchar('-');
					if(abs(a)==1) printf("%d",abs(b));
					else printf("%d/%d",abs(b),abs(a));
				}
				else
				{
					a*=2;
					at=a;
					bt=b;
					gcd_=gcd(abs(a),abs(b));
					a/=gcd_;
					b/=gcd_;
					if(b!=0)
					{
						if(!((a<0)^(b<0))) putchar('-');
						if(abs(a)==1) printf("%d",abs(b));
						else printf("%d/%d",abs(b),abs(a));
					}
					a=at;
					if(b!=0)
					{
						if(a<0) putchar('-');
						else if(b!=0) putchar('+');
					}
					b=sqr;
					gcd_=gcd(abs(a),abs(b));
					a/=gcd_;
					b/=gcd_;
					if(b!=1) printf("%d*",abs(b));
					printf("sqrt(%d)",delta/pow(sqr));
					if(abs(a)!=1) printf("/%d",abs(a));
				}
			}
			putchar('\n');
		}
	}
}
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	SOLVE::solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
