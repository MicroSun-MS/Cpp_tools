#include<iostream>
#include<cstdio>
namespace SOLVE
{
	template<typename type>
	void read(type &num)
	{
		num=0;
		char c=getchar();
		int n(1);
#define isdigit(c) ((c)>='0'&&(c)<='9')
		while(!isdigit(c)){if(c=='-') n=-1;c=getchar();}
		while(isdigit(c)){num=(num<<1)+(num<<3)+(c^48);c=getchar();}
#undef isdigit
		num*=n;
	}
	int ans=0,day=0,dat=-1;
	int upper(int a,int b)
	{
		if(a==0) return 0; 
		if(a%b!=0) return a/b+1;
		else return std::max(a/b,1);
	}
	void solve()
	{
		int n;
		read(n);
		while(n)
		{
			++day;
			if(n%3==1&&dat==-1) dat=day;
			n-=upper(n,3);
		}
		printf("%d %d\n",day,dat);
	}
}
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	SOLVE::solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
