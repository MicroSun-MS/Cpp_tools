#include<iostream>
#include<climits>
#include<cstdio>
namespace SOLVE
{
	typedef long long ll;
	typedef unsigned long long ull;
	template<typename type>
	void read(type &num)
	{
		num=0;
		char c=getchar();
		int n(1);
#define isdigit(c) ((c)>='0'&&(c)<='9')
		while(!isdigit(c)){if(c=='-') n=-1;c=getchar();}
		while(isdigit(c)){num=(num<<1)+(num<<3)+(c^48);c=getchar();}
#undef isdigit
		num*=n;
	}
	const int const1=2e5+10;
	int v[const1],a[const1];
	ll cost=0,mincost=LONG_LONG_MAX,dis=0,lst=1,add;
	ll upper(ll a,ll b)
	{
		if(a==0) return 0; 
		if(a%b!=0) return a/b+1;
		else return std::max(a/b,1ll);
	}
	void solve()
	{
		int i,n;
		ll d;
		read(n);
		read(d);
		v[1]=0;
		for(i=2;i<=n;++i) read(v[i]);
		for(i=1;i<=n+1;++i)
		{
			if(i<=n) read(a[i]);
			else a[i]=0;
			dis+=v[i];
			if(a[i]>mincost) continue;
			if(i!=1)
			{
				add=upper(dis,d);
				cost+=add*a[lst];
				dis-=add*d;
			}
			if(mincost>a[i])
			{
				mincost=a[i];
				lst=i;
			}
		}
		printf("%lld\n",cost);
	}
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	SOLVE::solve();
	fclose(stdin);
	fclose(stdout);
	return 0;
}
