#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n;
ll hao;
queue<ll> q;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	if(n<4){
		cout<<n<<" "<<n<<endl;
		return 0;
	}else if(n==6){
		cout<<4<<" "<<2<<endl;
		return 0;
	}else if(n==9){
		cout<<5<<" "<<3<<endl;
		return 0;
	}
	ll a[n+1];
	memset(a,1,sizeof(a));
	for(int i=1;i<=n;i++){
		q.push(i);
	}
	ll ans=0;
	ll head=q.front();
	while(!q.empty()){
		
		if(q.front()==n) hao=ans;
		q.pop();
		head+=3;
		if(head>n){
			head=q.front();
			ans++;
	
		}
	}
	if(n%3==1) hao=1;
	else hao++;
	cout<<ans<<" "<<hao;
	
	
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
