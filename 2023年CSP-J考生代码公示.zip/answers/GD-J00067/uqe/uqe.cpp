#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int m,t;
	cin>>t>>m;
	int a,b,c;
	for(int i=1;i<=t;i++){
		cin>>a>>b>>c;
		if((b*b-4*a*c)<0) cout<<"NO"<<endl;
		if(a==1) cout<<0<<" "<<0<<endl;
		if(a==-1) cout<<0<<" "<<0<<endl;
	}
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
