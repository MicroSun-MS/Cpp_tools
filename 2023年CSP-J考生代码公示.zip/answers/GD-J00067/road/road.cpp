#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,a[100010],d,v[100010];
ll cost,l;
int main(){
	freopen("road.in ","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(ll i=1;i<=n-1;i++){
		cin>>v[i];
		l+=v[i];
	}
	for(ll i=1;i<=n;i++){
		cin>>a[i];
	}
	if(l%d!=0)cost+=a[1];
	l/=d;
	cost+=l*a[1];
	
	cout<<cost<<endl;
	fclose(stdin);
	fclose(stdout);
	
	return 0;
}
