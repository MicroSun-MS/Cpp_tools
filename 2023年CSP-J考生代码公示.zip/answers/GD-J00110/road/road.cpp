#include<bits/stdc++.h>
using namespace std;
int v[100010];
int a[100010];
int n, d, ans;
int main(){
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	scanf("%d%d", &n, &d);
	for(int i = 1; i < n; i++) scanf("%d", &v[i + 1]);
	for(int i = 2; i <= n; i++) v[i] += v[i - 1];
	for(int i = 1; i <= n; i++) scanf("%d", &a[i]);
	int tmp = 1, now = 0;
	while(tmp < n){
		for(int i = tmp + 1; i <= n; i++){
			if(a[i] < a[tmp]){
				int need = v[i] - v[tmp] - now;
				if(need < 0) continue;
				ans += ceil(1.0 * need / d) * a[tmp];
				now += ceil(1.0 * need / d) * d - (v[i] - v[tmp]);
				tmp = i;
				break;
			}
			if(i == n) {
				int need = v[n] - v[tmp] - now;
				if(need < 0) continue;
				ans += ceil(1.0 * need / d) * a[tmp];
				tmp = n;
				break;
			}
		}
	}
	cout << ans << endl;
	return 0;
}
