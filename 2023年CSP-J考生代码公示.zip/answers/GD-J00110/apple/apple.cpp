#include<bits/stdc++.h>
using namespace std;
int n;
int main(){
	freopen("apple.in", "r", stdin);
	freopen("apple.out", "w", stdout);
	scanf("%d", &n);
	int cnt = 0, ans;
	bool flag = false;
	while(n){
		cnt++;
		if(n % 3 == 1 && !flag){
			ans = cnt;
			flag = true;
		} 
		n -= (n + 2) / 3;
	}
	printf("%d %d", cnt, ans);
	return 0;
}
