#include<bits/stdc++.h>
using namespace std;
int T, M;
int x, y, z;
int gcd(int m, int n){
	if(n == 0) return m;
	return gcd(n, m % n);
}
int main(){
	freopen("uqe.in", "r", stdin);
	freopen("uqe.out", "w", stdout);
	scanf("%d%d", &T, &M);
	while(T--){
		scanf("%d%d%d", &x, &y, &z);
		double a = 1.0 * x, b = 1.0 * y, c = 1.0 * z;
		double dt = b * b - 4 * a * c;
		if(dt < 0){
			puts("NO");
			continue;
		}
		int r = int(dt), x = 1;
		for(int i = 2; i <= (int)(sqrt(r)); i++){
			while(r % (i * i) == 0) {
				x *= i;
				r /= i * i;
			}
		}
		if(r != 1 && b){
			int Gcd = gcd(abs(int(b)), abs(int(2 * a)));
			if(2 * a == 1.0 * Gcd) printf("%d", int(-1 * b / Gcd));
			else {
				if(2 * a / Gcd == 1 || 2 * a / Gcd == -1){
					if(a * b < 0) printf("%d", abs(int(b / Gcd)));
					if(a * b > 0) printf("-%d", abs(int(b / Gcd)));
				} else {
					if(a * b < 0) printf("%d/%d", abs(int(b / Gcd)), abs(int(2 * a / Gcd)));
					if(a * b > 0) printf("-%d/%d", abs(int(b / Gcd)), abs(int(2 * a / Gcd)));
				}
			}
		} else if(r == 1){
			int ans;
			if(a < 0) ans = -b - x;
			else ans = x - b;
			int Gcd = gcd(abs(int(ans)), abs(int(2 * a)));
			if(2 * a == 1.0 * Gcd) printf("%d", int(ans / Gcd));
			else {
				if(ans != 0 && (2 * a / Gcd == 1 || 2 * a / Gcd == -1)){
					if(a * ans > 0) printf("%d", abs(int(ans / Gcd)));
					if(a * ans < 0) printf("-%d", abs(int(ans / Gcd)));
				} else if(ans != 0 ){
					if(a * ans > 0) printf("%d/%d", abs(int(ans / Gcd)), abs(int(2 * a / Gcd)));
					if(a * ans < 0) printf("-%d/%d", abs(int(ans / Gcd)), abs(int(2 * a / Gcd)));
				} else printf("0");
			}
		}
		if(dt == 0 || r == 1){
			puts("");
			continue;
		}
		if(b) printf("+");
		int gcD = gcd(x, abs(int(2 * a)));
		x = x / (1.0 * gcD), a = a / (1.0 * gcD);
		if(x == 1) {
			if(r == 1) printf("1");
			else printf("sqrt(%d)", r); 
		} else {
			if(r == 1) printf("%d", x);
			else printf("%d*sqrt(%d)", x, r);
		}
		if(2 * a != 1 && 2 * a != -1) printf("/%d", int(2 * a));
		puts("");
	}
	return 0;
}
