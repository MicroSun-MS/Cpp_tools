#include<bits/stdc++.h>
using namespace std;
int n, m, k, u, v, a, ans = 0x3f3f3f3f;
int G[10010][10010];
void dfs(int u, int now, int plus){
	if(u == n){
		if(now % k == 0) ans = min(ans, plus * k + now);
		return;
	} 
	for(int i = 1; i <= n; i++){
		if(G[u][i] == 0x3f3f3f3f) continue;
		if(now + plus * k >= G[u][i]) dfs(i, now + 1, plus);
		if(now + plus * k < G[u][i]) dfs(i, now + 1, plus + ceil(1.0 * (G[u][i] - now - plus * k) / k));
	}
	return;
}
int main(){
	freopen("bus.in", "r", stdin);
	freopen("bus.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	memset(G, 0x3f, sizeof(G));
	for(int i = 1; i <= m; i++){
		scanf("%d%d%d", &u, &v, &a);
		G[u][v] = a;
	}
	dfs(1, 0, 0);
	printf("%d", ans);
	return 0;
}
