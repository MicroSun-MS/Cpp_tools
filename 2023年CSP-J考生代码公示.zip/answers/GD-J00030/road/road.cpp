#include<iostream>
#include<cstdio>
#include<algorithm>
#define int long long
using namespace std;
int n,d,now,ans,v[100005];
struct node{
	int x,s;
}a[100005];
signed main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int i,j;
	cin>>n>>d;
	for(i=1;i<n;i++)scanf("%lld",&v[i]);
	for(i=1;i<=n;i++){
		scanf("%lld",&a[i].x);
		if(i==1){
			a[i].s=0;
		}else{
			a[i].s=a[i-1].s+v[i-1];	
		}
	}
	for(i=1;i<=n;){
		for(j=i+1;j<=n;j++){
			//cout<<a[j].x<<endl;
			if(a[j].x<=a[i].x)break;
		}
		j=min(j,n);
		//cout<<j<<endl;
		//cout<<a[i].x<<endl;
		//cout<<i<<" "<<a[j].s-a[i].s<<" "<<(a[j].s-a[i].s+d-1)/d<<" "<<a[i].x<<endl;
		ans+=(a[j].s-a[i].s-now+d-1)/d*a[i].x;
		now+=(a[j].s-a[i].s+d-1)/d*d-a[j].s+a[i].s;
		i=j;
		if(i==n)break;
		//cout<<now<<endl;
		//cout<<i<<" "<<ans<<endl;
	}
	cout<<ans;
}
