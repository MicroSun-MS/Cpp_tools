#include<iostream>
#include<cstdio>
#include<vector>
using namespace std;
int n,m,k,u,v,w;
struct node{
	int v,w;
};
vector<node> g[10005];
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int i;
	cin>>n>>m>>k;
	for(i=1;i<=m;i++){
		scanf("%d%d%d",&u,&v,&w);
		g[u].push_back((node){v,w});
	}
	cout<<-1;
}
