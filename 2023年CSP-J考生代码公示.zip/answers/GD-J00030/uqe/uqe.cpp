#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int t,m,a,b,c;
int check(int a,int b,int c){
	if(b*b-4*a*c<0)return 0;
	return 1;
}
int gcd(int a,int b){
	if(a%b==0)return b;
	gcd(b,a%b);
}
void write(){
	int i,aa,bb,cc,dd=1;
	int x=b*b-4*a*c;
	int y=sqrt(x);
	if(y*y==x){
		aa=-b+y;
		if(aa<0){
			if(2*a>0)cout<<"-";
			aa=-aa;
		}
		bb=2*a;
		if(bb<0){
			if(aa>0)cout<<"-";
			bb=-bb;
		}
		cc=gcd(aa,bb);
		if(bb/cc==1){
			cout<<aa/cc<<endl;
		}else{
			cout<<aa/cc<<"/"<<bb/cc<<endl;
		}
	}else{
		aa=-b;
		if(aa<0){
			if(2*a>0)cout<<"-";
			aa=-aa;
		}
		bb=2*a;
		if(bb<0){
			if(aa>0)cout<<"-";
			bb=-bb;
		}
		cc=gcd(aa,bb);
		if(aa/cc!=0){
			if(bb/cc==1){
				cout<<aa/cc<<"+";
			}else{
				cout<<aa/cc<<"/"<<bb/cc<<"+";
			}
		}
		for(i=4;i<x;i++){
			int y=sqrt(i);
			if(y*y==i){
				while(x%i==0){
					x/=i;
					dd*=y;
				}
			}
		}
		if(dd==1){
			cout<<"sqrt("<<x<<")/"<<2*a<<endl;
		}else{
			cc=gcd(dd,2*a);
			if(dd/cc!=1){
				cout<<dd/cc<<"*";
			}
			cout<<"sqrt("<<x<<")";
			if(bb/cc!=1){
				cout<<"/"<<bb/cc<<endl;
			}else{
				cout<<endl;
			}
		}
	}
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int i;
	cin>>t>>m;
	while(t--){
		scanf("%d%d%d",&a,&b,&c);
		if(b==0&&c==0){
			cout<<0<<endl;
			continue;
		}
		if(!check(a,b,c)){
			cout<<"NO"<<endl;
			continue;
		}
		write();
	}
}
