#include<iostream>
#include<cstdio>
using namespace std;
int n,s,p,ans1,ans2,vis[10000005];
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int i;
	cin>>n;
	while(s<n){
		ans1++;
		p=0;
		for(i=1;i<=n;i++){
			if(!vis[i]){
				if(p%3==0){
					vis[i]=1;
					s++;
					if(i==n)ans2=ans1;
				}
				p++;
			}
		}
	}
	cout<<ans1<<" "<<ans2;
}
