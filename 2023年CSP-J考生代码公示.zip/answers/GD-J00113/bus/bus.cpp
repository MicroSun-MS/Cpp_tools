#include<cstdio>
#include<iostream>
#include<algorithm>
#include<iomanip>
#include<queue>
using namespace std;
int n,m,k,u,v,a,cnt,head[20005],dis[20005][105];
struct node{
	int v,nxt,t;
}edge[20005];
void add(int x,int y,int z){
	edge[++cnt].v=y,edge[cnt].t=z,edge[cnt].nxt=head[x],head[x]=cnt;
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=n;i++)
		for(int j=0;j<k;j++)
			dis[i][j]=2147483647;dis[1][0]=k;
	for(int i=1;i<=m;i++){
		scanf("%d%d%d",&u,&v,&a);
		add(u,v,a);
	}
	for(int u=1;u<=n;u++){
		for(int i=head[u];i;i=edge[i].nxt){
			int v=edge[i].v;
			for(int j=0;j<k;j++){
				if(dis[v][j]>dis[u][(j+k-1)%k]+1&&dis[u][(j+k-1)%k]+1>=edge[i].t){
					dis[v][j]=dis[u][(j+k-1)%k]+1;
				}
			}
		}
	}
	if(dis[n][0]==2147483647)dis[n][0]=-1;
	printf("%d",dis[n][0]);
	return 0;
}
