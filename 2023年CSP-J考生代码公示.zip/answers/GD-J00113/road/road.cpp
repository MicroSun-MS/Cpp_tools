#include<cstdio>
#include<iostream>
#include<algorithm>
#include<iomanip>
using namespace std;
int n,v[100005],a[100005],now;
long long ans,s,s2,d;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%lld",&n,&d);a[n+1]=0;
	for(int i=2;i<=n;i++)
	{scanf("%d",&v[i]);}
	for(int i=1;i<=n;i++)
	{scanf("%d",&a[i]);}now=1;
	for(int i=2;i<=n+1;i++){
		s+=v[i];
		if(a[i]<a[now]){
			if(s>=s2){s-=s2;s2=((s/d)+bool(s%d))*d-s;}
			else s2-=s,s=0;
			ans+=((s/d)+bool(s%d))*a[now];
			now=i;s=0;
		}
	}printf("%lld",ans);
	return 0;
}
