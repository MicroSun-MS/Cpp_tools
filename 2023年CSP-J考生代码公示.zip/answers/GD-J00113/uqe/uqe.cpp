#include<cstdio>
#include<iostream>
#include<algorithm>
#include<cmath>
#include<iomanip>
using namespace std;
int T,m,a,b,c;
int G(int x,int y){
	while(x%y){int r=x%y;x=y,y=r;}
	return y;
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&T,&m);
	while(T--){
		scanf("%d%d%d",&a,&b,&c);
		int dt=b*b-4*a*c;
		if(dt<0){printf("NO\n");continue;}
		if(!b&&!c){printf("0\n");continue;}
		int k=sqrt(dt),dtx=1;
		for(int i=k;i>1;i--){
			if(dt%(i*i))continue;
			dt/=i*i,dtx*=i;
		}b=-b;a*=2;int p=1;
		if(dt==1){if(a>0)b+=dtx;else b-=dtx;}
		p=G(abs(b),abs(a));
		b/=p;if(a*b<0)printf("-");
		if(b!=0)printf("%d",abs(b));
		if(abs(a)!=p)printf("/%d",abs(a)/p);
		if(dt==1){if(!b)printf("0");printf("\n");}
		else{
			p=G(dtx,abs(a));if(!dt){printf("\n");continue;}
			if(b!=0)printf("+");dtx/=p;
			if(dtx!=1)printf("%d*",dtx);
			printf("sqrt(%d)",dt);
			if(abs(a)!=p)printf("/%d",abs(a)/p);printf("\n");
		}
	}
	return 0;
}
