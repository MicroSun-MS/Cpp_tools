#include<cstdio>
#include<iostream>
#include<algorithm>
#include<iomanip>
using namespace std;
int n,tot,ans;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);tot=n;
	for(int day=1;tot>0;day++){
		int num=tot/3+bool(tot%3);
		if(n%3==1&&!ans)ans=day;
		tot-=num;n=tot;if(tot<=0)printf("%d ",day);
	}printf("%d",ans);
	return 0;
}
