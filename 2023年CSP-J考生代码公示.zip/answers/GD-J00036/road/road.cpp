#include<bits/stdc++.h>
using namespace std;
long long n,d,a[100010],v[100010],mi=1000000,js,f[10010],t,yl,zqs;
void fs(int x){
	if(x<=1) return ;
	int minn=10000000,js;
	t++;
	for(int i=1;i<=x;i++){
		if(a[i]<minn){
			minn=a[i];
			f[t]=i;
		}
	}
	x=f[t];
	fs(x);
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=1;i<n;i++){
		cin>>v[i];
		js+=v[i];
	}
	for(int i=1;i<=n;i++){
		cin>>a[i];
		mi=min(mi,a[i]);
	}
	if(mi==a[1]){
		cout<<js/d*a[1];
		return 0;
	}
	fs(n);
	for(int i=t;i>=1;i--){
		int s;
		for(int j=f[i];j<=f[i+1];j++)
			s+=v[j];
		s-=yl*d;
		yl=s/d;
		if(s%d!=0) yl++;
		zqs+=yl*a[f[i]];
	}
	cout<<zqs;
	return 0;
}
