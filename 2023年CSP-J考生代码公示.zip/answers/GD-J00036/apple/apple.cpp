#include<bits/stdc++.h>
using namespace std;
long long n,a[100100],ans,js,sn;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
		a[i]=i;
	int x=n;
	if(n%3==1){
		while(n!=0){
			int p=n/3;
			if(n%3!=0) p++;
			n-=p;
			ans++;
		}
		cout<<ans<<" "<<1;
		return 0;
	}
	while(n>0){
		ans++;
		for(int i=1;i<=n;i+=3){
			if(a[i]==x) js=ans;
			a[i]=0;
		}
		int t=0;
		for(int i=1;i<=n;i++)
			if(a[i]!=0)
				a[++t]=a[i];	
		n=t;
		if(n==0) break;
	}	
	cout<<ans<<" "<<js;
	return 0;
}
