#include<bits/stdc++.h>
using namespace std;
int n,d,l[100005],a[100005],m[100005],f[100005],minn=1e8,mini,lum;
int o(int x,int y){
	if(x%y==0) return x/y;
	return x/y+1;
} 
int main(){
	freopen("road.in","r",stdin);freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=1;i<=n-1;i++){
		cin>>l[i];
		lum+=l[i];
		f[i]=1e8;
	}
	for(int i=1;i<=n;i++){
		cin>>a[i];
		if(minn>a[i]){
			minn=a[i];
			mini=i;
		}
		m[i]=minn;
	}
//	for(int i=1;i<=n;i++) cout<<m[i]<<' ';
	if(mini==1){
		cout<<o(lum,d)*a[1]<<endl;
		return 0;
	}
	f[2]=o(l[1],d)*a[1];
	for(int i=3;i<=n;i++){
		int x=o(l[i-1],d)*m[i-1];
//		cout<<x<<' ';
		f[i]=f[i-1]+x;
	}
	cout<<f[n]<<endl;
	return 0;
}
/*
5 4
10 10 10 10
9 8 9 6 5

79
*/
