#include<bits/stdc++.h>
using namespace std;
int n,m,a,b,c;
int sqr,skr;
int main(){
	freopen("uqe.in","r",stdin);freopen("uqe.out","w",stdout);
	cin>>n>>m;
    while(n--){
    	cin>>a>>b>>c;
    	if(c==0){
    		skr=abs(b);
    		if(b>=0){
    			cout<<0<<endl;
				continue;
			}
    		if(skr%a==0) cout<<skr/a<<endl;
    		else cout<<skr<<'/'<<a<<endl;
    		continue;
		}
    	if(b==0){
    		int ans=-4*a*c,an;
    		if(ans<0) cout<<"NO"<<endl;
    		else if(ans==0) cout<<0<<endl;
    		else{
    			if(sqrt(ans)*sqrt(ans)!=ans){
    				if(ans%(a*2)==0) cout<<ans/(a*2)<<endl;
    				else cout<<ans<<'/'<<a*2<<endl;
				}
    			else{
    				cout<<"sqrt({"<<ans<<"})/"<<a*2<<endl;
				}
			}
		}
	}
	return 0;
}

