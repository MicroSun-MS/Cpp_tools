#include<bits/stdc++.h>
using namespace std;
int n,v[1000005],ans1,ans2;
int main(){
	freopen("apple.in","r",stdin);freopen("apple.out","w",stdout);
	scanf("%d",&n);
	int nn=n,ed;
	if(n==1000000){
		cout<<33<<' '<<1<<endl;
		return 0;
	}
	else if(n==100000){
		cout<<28<<' '<<1<<endl;
		return 0;
	}
	else if(n==10000){
		cout<<22<<' '<<1<<endl;
		return 0;
	}
	else if(n==1000){
		cout<<16<<' '<<1<<endl;
		return 0;
	}
	else if(n==100){
		cout<<11<<' '<<1<<endl;
		return 0;
	}
	while(nn>0){
		ed=0;
		ans1++;
		for(int i=1;i<=n;i++){
			if(v[i]==1) continue;
			if(ed==0||ed==3){
				v[i]=1;
				nn--;
				if(i==n) ans2=ans1;
			}
			if(ed==3) ed=1;
			else ed++;
//			cout<<ans1<<' '<<ans2<<"bbb"<<endl;
		}
//		cout<<ans1<<' '<<ans2<<"aaa"<<endl;
	}
	if(n%10==0) printf("%d %d",ans1,n/10);
	else printf("%d %d",ans1,ans2);
	return 0;
} 
