#include<bits/stdc++.h>
using namespace std;
int n,a[1009],j=0;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	int w=1;
	int m=n-1;
	if(n<=2){
		cout<<n<<endl;
	}
	else{
		while(m>0){
			m-=w;	
			w++;
		}
		cout<<w<<endl;
	} 
	cout<<1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}

