#include<bits/stdc++.h>
using namespace std;
struct node{
	int u,v,a;
}x[100006];
int sum=0;
long long  n,m,k;
void dfs(int q,int p){
	if(p==n&&sum%k==0){
		cout<<sum;
		return;
	}
	for(int i=1;i<=n;i++){
		if(x[i].u==p&&x[i].a<=sum){
			sum++;
			dfs(x[i].u,x[i].v);
			sum--;
		}
	}
	return ;
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		cin>>x[i].u>>x[i].v>>x[i].a;
	}
	sum+=k;
	for(int i=1;i<=m;i++){
		if(x[i].u==1){
			sum++;
			dfs(x[i].u,x[i].v);
			sum--;
		} 
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}

