#include<bits/stdc++.h>
using namespace std;
int v[10005],a[10005];
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,d;
	cin>>n>>d;
	int v_=0;
	for(int i=1;i<=n-1;i++){
		cin>>v[i];
		v_+=v[i];
	}
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	int sum=0;
	int i=1;
	int vv=0,y=0;
	while(y<v_){
		int k=1;
		
		while(a[i]<a[i+k]&&i+k<=n) {
			k++;	
		}
		for(int j=i;j<i+k;j++){
			vv+=v[j];	
		}
		if(i+k==n){
			if((v_-y)%d==0) sum=sum+(v_-y)/d*a[i];
			else sum=sum+((v_-y)/d+1)*a[i];
		}
		else{
			if(vv%d==0) sum=sum+vv/d*a[i];
			else sum=sum+(vv/d+1)*a[i];
			if(vv%d==0) y+=vv;
			else y+=(vv/d+1)*d;
		}
		vv=0;
		i=i+k;
	}
	cout<<sum;
	fclose(stdin);
	fclose(stdout);
	return 0;
}


