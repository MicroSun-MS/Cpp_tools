#include<cmath>
#include<stack>
#include<queue>
#include<cstdio>
#include<string>
#include<vector>
#include<cstring>
#include<iostream>
#include<algorithm>
#define PI pair<int,int>
#define MP(u,v) make_pair((u),(v))
#define U unsigned
#define IL inline
#define int long long
using namespace std;
const int INF=0x3f3f3f3f;
const int mod=1e9+7;
const int N=1e5+10;
const int M=1e5;
int n,d;
int v[N],a[N];
signed main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld%lld",&n,&d);
	for(int i=1;i<n;i++)
		scanf("%lld",v+i);
	for(int i=1;i<=n;i++)
		scanf("%lld",a+i);
	int ans=0,sum=0,len=0,id=1;
	for(int i=1;i<n;i++){
		if(a[id]>a[i]){
			int x=len-sum*d;
			sum+=x/d+(x%d!=0);
			ans+=(x/d+(x%d!=0))*a[id];
			id=i;
		}
		len+=v[i];
	}
	int x=len-sum*d;
	if(id!=n)
		ans+=(x/d+(x%d!=0))*a[id];
	printf("%lld\n",ans);
	return 0;
}
/*
5 4
10 10 10 10 
9 8 9 6 5

*/





