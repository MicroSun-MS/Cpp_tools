#include<cmath>
#include<stack>
#include<queue>
#include<cstdio>
#include<string>
#include<vector>
#include<cstring>
#include<iostream>
#include<algorithm>
#define PI pair<int,int>
#define MP(u,v) make_pair((u),(v))
#define U unsigned
#define IL inline
//#define int long long
using namespace std;
const int INF=0x3f3f3f3f;
const int mod=1e9+7;
const int N=1e5+10;
const int M=1e5;
int n,m,k;
vector<int>g[N],d[N];
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	bool f=1;
	for(int i=1;i<=m;i++){
		int u,v,w;
		scanf("%d%d%d",&u,&v,&w);
		if(w!=0)
			f=0;
		g[u].push_back(v),d[u].push_back(w);
	}
	puts(f?"0":"-1");
	return 0;
}
/*

*/





