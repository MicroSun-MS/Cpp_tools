#include<cmath>
#include<stack>
#include<queue>
#include<cstdio>
#include<string>
#include<vector>
#include<cstring>
#include<iostream>
#include<algorithm>
#define PI pair<int,int>
#define MP(u,v) make_pair((u),(v))
#define U unsigned
#define IL inline
//#define int long long
using namespace std;
const int INF=0x3f3f3f3f;
const int mod=1e9+7;
const int N=1e5+10;
const int M=1e5;
int T,m;
PI solve(int x,int y){
	if((x<0&&y<0)||(x>0&&y<0))
		return MP(-x,-y);
	return MP(x,y);
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&T,&m);
	while(T--){
		bool f1=0,f2=0;
		PI p,q,r;
		int a,b,c;
		scanf("%d%d%d",&a,&b,&c);
		int d=b*b-4*a*c;
		if(d>=0){
			double n=2*a;
			if(b!=0){
				if(-b!=2*a){
					int g=__gcd(-b,2*a);
					p=solve(-b/g,2*a/g);
					f1=1;
				}
			}
			if(d!=0){
				int dd=d,sq=1;
				for(int i=2;i*i<=dd;i++){
					int cnt=0;
					while(dd%i==0)
						dd/=i,cnt++;
					if(cnt>=2)
						sq*=pow(i,cnt/2);
					if(cnt&1)
						dd*=i;
				}
				if(sq==1){
					int g=__gcd(d,2*a);
					q.first=d,q.second=2*a/g;
					if(d==1)
						f2=1;
				}
				else{
					if(dd==1){
						int g=__gcd(sq,2*a);
						q=solve(sq/g,2*a/g);
						f2=1;
					}
					else{
						int g=__gcd(sq,2*a);
					}
				}
			}
		}
		if(f1&&f2){
			if(q.second==p.second){
				int x=q.first+p.first,g=__gcd(x,q.second);
				p=solve(x/g,q.second/g);
				if(p.first==p.second)
					putchar('1');
				else if(p.first+p.second==0)
					printf("-1");
				else
					printf("%d/%d",p.first,p.second);
			}
		}
		else{
			d=b*b-4*a*c;
			p=q=MP(0,0);
			if(d<0)
				printf("NO");
			else{
				double n=2*a;
				if(b!=0){
					if(-b!=2*a){
						int g=__gcd(-b,2*a);
						p=solve(-b/g,2*a/g);
						f1=1;
						printf("%d/%d",p.first,p.second);
					}
					else
						putchar('1');
					if(d!=0)
						putchar('+');
				}
				if(d!=0){
					int dd=d,sq=1;
					for(int i=2;i*i<=dd;i++){
						int cnt=0;
						while(dd%i==0)
							dd/=i,cnt++;
						if(cnt>=2)
							sq*=pow(i,cnt/2);
						if(cnt&1)
							dd*=i;
					}
					if(sq==1){
						int g=__gcd(d,2*a);
						if(d==1)
							putchar('1');
						else
							printf("sqrt(%d)",d);
						printf("/%d",2*a/g);
						p.first=d,p.second=2*a/g;
						f2=1;
					}
					else{
						if(dd==1){
							int g=__gcd(sq,2*a);
							q=solve(sq/g,2*a/g);
							printf("%d/%d",p.first,p.second);
							f2=1;
						}
						else{
							int g=__gcd(sq,2*a);
							if(sq/g!=1)
								printf("%d*",sq/g);
							printf("sqrt(%d)/%d",dd,2*a/g);
						}
					}
				}
			}
		}
		puts("");
	}
	return 0;
}
/*
9 1000
1 -1 0
-1 -1 -1
1 -2 1
1 5 4
4 4 1
1 0 -432
1 -3 1
2 -4 1
1 7 1

1 1 
1 -3 1

*/





