#include<cmath>
#include<stack>
#include<queue>
#include<cstdio>
#include<string>
#include<vector>
#include<cstring>
#include<iostream>
#include<algorithm>
#define PI pair<int,int>
#define MP(u,v) make_pair((u),(v))
#define U unsigned
#define IL inline
//#define int long long
using namespace std;
const int INF=0x3f3f3f3f;
const int mod=1e9+7;
const int N=1e8+10;
const int M=1e8;
int n;
int a[N];
bool check(){
	for(int i=1;i<=n;i++)
		if(a[i]==0)
			return 0;
	return 1;
}
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);
	for(int j=1;j<=100;j++){
		int cnt=0;
		for(int i=1;i<=n;i++){
			if(a[i]==0){
				cnt++;
				if(cnt%3==1){
					a[i]=j;
				}
			}
		}
	}
	int maxn=0;
	for(int i=1;i<=n;i++)
		maxn=max(maxn,a[i]);
	printf("%d %d",maxn,a[n]);
	return 0;
}
/*
8
123142153
123456789
235689
3589
58
8
*/





