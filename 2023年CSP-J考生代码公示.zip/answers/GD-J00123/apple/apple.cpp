#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n;
ll cnt;
ll ans;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout); 
	cin >> n;
	while(n){
		cnt++;
		if(!ans&&(n-1)%3==0) ans=cnt;
		int m=((n-1)/3)+1;
		n-=m;
	}
	cout << cnt << ' ' << ans << endl;
	return 0;
} 
