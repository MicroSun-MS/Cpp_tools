#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int n,d;
int val=100005;
int dis[100005];
int v[100005];
ll oil;
ll len;
ll ans;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin >> n >> d;
	for(int i=1;i<n;i++){
		cin >> dis[i];
	}
	for(int i=1;i<n;i++){
		cin >> v[i];
		val=min(val,v[i]);
		if(dis[i]<=len){
			len-=dis[i];
			continue;
		} 
		oil=(dis[i]-len)/d;
		if((dis[i]-len)%d) oil++;
		ans+=oil*val;
		len+=oil*d;
		len-=dis[i];
	}
	cout << ans << endl;
	return 0;
}
