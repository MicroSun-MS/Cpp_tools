#include<bits/stdc++.h>
using namespace std;
int n,m,k;
int x,y,z;
struct node{
	int val,next,t;
}edge[20005];
int head[10005];
int id;
void add(int x,int y,int z){
	edge[++id].val=y;
	edge[id].next=head[x];
	edge[id].t=z;
	head[x]=id;
}
int vis[10005][105];
struct qwe{
	int x,step,round,cost;
};
void bfs(){
	queue<qwe>q;
	q.push({1,0,0,0});
	vis[1][0]=1;
	int ans=1e9;
	while(!q.empty()){
		qwe now=q.front();
		q.pop();
		int x=now.x;
		if(now.round>=ans) continue;
		if(x==n&&now.step==0){
			int res=now.cost/k;
			if(now.cost%k) res++;
			ans=min(ans,now.round+res);
			continue;
		}
		for(int i=head[x];i!=-1;i=edge[i].next){
			int y=edge[i].val; 
			int z=edge[i].t;
			int nx_step=now.step+1;
			int nx_round=now.round;
			int nx_cost=max(z-now.round*k-now.step,now.cost);
			if(nx_step>=k){
				nx_step-=k;
				nx_round++;
			}
			if(vis[y][nx_step]) continue;
			vis[y][nx_step]=1;
			q.push({y,nx_step,nx_round,nx_cost});
		} 
	}
	if(ans==1e9){
		cout << -1;
	}else{
		cout << ans*k << endl;
	}
}
void mini_bfs(){
	queue<qwe>q;
	q.push({1,0,0,0});
	for(int i=1;i<=n;i++){
		for(int j=0;j<k;j++){
			vis[i][j]=1e9;
		}
	}
	vis[1][0]=0;
	int ans=1e9;
	while(!q.empty()){
		qwe now=q.front();
		q.pop();
		int x=now.x;
		if(now.round>=ans) continue;
		if(x==n&&now.step==0){
			int res=now.cost/k;
			if(now.cost%k) res++;
			ans=min(ans,now.round+res);
			continue;
		}
		for(int i=head[x];i!=-1;i=edge[i].next){
			int y=edge[i].val; 
			int z=edge[i].t;
			int nx_step=now.step+1;
			int nx_round=now.round;
			int nx_cost=max(z-now.round*k-now.step,now.cost);
			if(nx_step>=k){
				nx_step-=k;
				nx_round++;
			}
			int res=nx_cost/k;
			if(nx_cost%k) res++;
			if(nx_round+res>vis[y][nx_step]) continue;
			vis[y][nx_step]=nx_round+res;
			q.push({y,nx_step,nx_round,nx_cost});
		} 
	}
	if(ans==1e9){
		cout << -1;
	}else{
		cout << ans*k << endl;
	}
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin >> n >> m >> k;
	for(int i=1;i<=n;i++) head[i]=-1;
	for(int i=1;i<=m;i++){
		cin >> x >> y >> z;
		add(x,y,z);
	}
	if(n>10){
		bfs();
	}else{
		mini_bfs();
	}
	return 0;
}
 

