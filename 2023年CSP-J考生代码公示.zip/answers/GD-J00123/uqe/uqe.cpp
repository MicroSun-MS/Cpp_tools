#include<bits/stdc++.h>
using namespace std;
int t,n,m;
int a,b,c;
int gcd(int a,int b){
	if(a<0) a=-a;
	if(b<0) b=-b;
	return (a%b)?(gcd(b,a%b)):b;
}
void solve(int a,int b,int c){
	int sum=b*b-4*a*c;
	int sq=sqrt(sum);
	int shang=-b;
	int xia=2*a;
	if(sq==sqrt(sum)){
		if(xia<0) shang-=sq;
		else shang+=sq;
	} 
	if(shang){
		int gd=gcd(shang,xia);
		int fu=0;
		shang/=gd;
		xia/=gd;
		if(shang<0){
			fu^=1;
			shang=-shang;
		}
		if(xia<0){
			fu^=1;	
			xia=-xia;
		}
		if(fu) cout << '-';
		cout << shang;
		if(xia^1){
			cout << '/' << xia;
		} 
	}else{
		if(sq==sqrt(sum)) cout << 0;
	}
	if(sq!=sqrt(sum)){
		if(b) cout << '+';
		for(int i=sq;i>=1;i--){
			if(sum%(i*i)==0){
				shang=i;
				break;
			}
		}
		xia=2*a;
		int gd=gcd(shang,xia);
		int zhong=sum/shang/shang;
		shang/=gd;
		xia/=gd;
		if(xia<0) xia=-xia;
		if(shang^1){
			cout << shang << '*';
		}
		cout << "sqrt(" << zhong << ")";
		if(xia^1){
			cout << '/' << xia;
		}
	}
	cout << endl;
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin >> t >> m;
	while(t--){
		cin >> a >> b >> c;
		if(b*b<4*a*c){
			cout << "NO" << endl;
		}else{
			solve(a,b,c);
		}
	}
	return 0;
} 
