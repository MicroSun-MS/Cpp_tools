#include <bits/stdc++.h>
using namespace std;

const int MAXN = 1e5 + 10;
int dp[MAXN], dis[MAXN], division[MAXN], f[MAXN];
int n, d, v[MAXN], a[MAXN];

int main(){
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	cin >> n >> d;
	cin >> v[1];
	for(int i = 2; i < n; i++){
		cin >> v[i];
		dis[i] = dis[i - 1] + v[i - 1];
	}
	dis[n] = dis[n - 1] + v[n - 1];
	for(int i = 1; i <= n; i++){
		cin >> a[i];
	}
	dp[1] = 0;
	f[1] = 0;
	for(int i = 2; i <= n; i++){
		int minn = 1e9, need;
		for(int j = i - 1; j >= 1; j--){
			int distance = dis[i] - dis[j];
			need = ceil(max(distance - f[j], 0) * 1.0 / d);
			if(minn > dp[j] + need * a[j]){
				minn = dp[j] + need * a[j];
				division[i] = j;
			}
		}
		f[i] = (ceil((dis[i] - dis[division[i]] - f[division[i]]) * 1.0 / d) - (dis[i] - dis[division[i]] - f[division[i]]) * 1.0 / d) * d;
		dp[i] = minn;
	}
	cout << dp[n] << endl;
	return 0;
} 
