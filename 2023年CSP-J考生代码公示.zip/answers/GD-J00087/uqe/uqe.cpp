#include <bits/stdc++.h>
using namespace std;

int t, m, a, b, c;
int has_ans(int a, int b, int c){
	int delta = b * b - 4 * a * c;
	if(delta < 0) return -1;
	else if(delta == 0) return 0;
	else return 1;
}
int gcd(int x, int y){
	if(x == y) return x;
	else{
		int t1 = max(x, y);
		int t2 = min(x, y);
		x = t1;
		y = t2;
		if(x % y == 0) return y;
		else return gcd(x % y, y);
	}
}

int gsqrdiv(int n){
	int ret = 1, cnt = 1;
	while(cnt * cnt <= n){
		if(n % cnt == 0 && (n / cnt) % cnt == 0){
			ret = cnt;
		}
		cnt++;
	}
	return ret;
}

int main(){
	freopen("uqe.in", "r", stdin);
	freopen("uqe.out", "w", stdout);
	cin >> t >> m;
	while(t--){
		cin >> a >> b >> c;
		if(has_ans(a, b, c) == -1){
			cout << "NO" << endl;
			continue;
		}
		else if(has_ans(a, b, c) == 0){
			int ansup = -b, ansdown = 2 * a;
			if(ansup == 0){
				cout << 0 << endl;
				continue;
			}
			else if(ansdown < 0){
				ansup = -ansup;
				ansdown = -ansdown;
			}
			int divisor = gcd(abs(ansup), ansdown);
			ansup /= divisor;
			ansdown /= divisor;
			if(ansdown == 1){
				cout << ansup << endl;
				continue;
			}
			cout << ansup << "/" << ansdown << endl;
		}
		else{
			int delta = b * b - 4 * a * c;
			int realup = gsqrdiv(delta), realdown = 2 * a;
			delta = delta / realup / realup;
			if(delta == 1){
				int resdown = 2 * a, resup;
				if(resdown < 0){
					resup = b + realup;
					resdown = -resdown;
				}
				else{
					resup = -b + realup;
				}
				if(resup == 0){
					cout << 0 << endl;
					continue;
				}
				int divisor = gcd(abs(resup), resdown);
				resup /= divisor;
				resdown /= divisor;
				if(resdown == 1) cout << resup << endl;
				else cout << resup << "/" << resdown << endl;
				continue;
			}
			int ansup = -b, ansdown = 2 * a;
			if(ansup != 0){
				if(ansdown < 0){
					ansup = -ansup;
					ansdown = -ansdown;
				}
				int divisor = gcd(abs(ansup), ansdown);
				ansup /= divisor;
				ansdown /= divisor;
				if(ansdown == 1) cout << ansup << "+";
				else cout << ansup << "/" << ansdown << "+";
			}
			if(realup == 1){
				cout << "sqrt(" << delta << ")/" << abs(realdown) << endl;
				continue; 
			}
			else if(realup == realdown){
				cout << "sqrt(" << delta << ")" << endl;
				continue; 
			}
			else{
				int div = gcd(realup, abs(realdown));
				realup /= div;
				realdown /= div;
				if(realup == 1 && abs(realdown) != 1){
					cout << "sqrt(" << delta << ")/" << abs(realdown) << endl;
					continue;
				}
				else if(realup != 1 && abs(realdown) == 1){
					cout << realup << "*sqrt(" << delta << ")" << endl;
					continue;
				}
				else if(realup == 1 && abs(realdown) == 1){
					cout << "sqrt(" << delta << ")" << endl;
					continue;
				}
				cout << realup << "*sqrt(" << delta << ")/" << abs(realdown) << endl;
			}
		}
	}
	return 0;
} 
