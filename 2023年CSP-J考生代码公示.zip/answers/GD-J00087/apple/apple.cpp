#include <bits/stdc++.h>
using namespace std;

int n, tmp, cnt;

int main(){
	freopen("apple.in", "r", stdin);
	freopen("apple.out", "w", stdout);
	cin >> n;
	tmp = n;
	cnt = 0;
	while(tmp > 0){
		cnt++;
		tmp -= ceil(tmp * 1.0 / 3);
	}
	cout << cnt << " ";
	tmp = n;
	cnt = 1;
	while(tmp % 3 != 1){
		cnt++;
		tmp -= (tmp - 1) / 3 + 1;
	}
	cout << cnt;
	return 0;
} 
