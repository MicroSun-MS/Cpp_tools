#include<iostream>
#include<vector>
#include<cstdio>
using namespace std;
int n,m,k,u[20001],v[20001],a[20001],bj[10001];
int ans;
vector<int>ve[20001];
void dfs(int id,int step){
	if(id==n)ans=min(ans,step);
	for(int i=0;i<ve[id].size();i++){
		if(bj[ve[id][i]]==1)continue;
		bj[ve[id][i]]=1;
		dfs(ve[id][i],step+1);
		bj[ve[id][i]]=0;
	}
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		cin>>u[i]>>v[i]>>a[i];
		ve[u[i]].push_back(v[i]);
	}
	ans=n+n;
	dfs(1,0);
	if(ans==n+n)cout<<"-1";
	while(ans%k!=0)ans++;
	cout<<ans+k;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
