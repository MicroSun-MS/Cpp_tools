#include<iostream>
#include<cmath>
#include<cstdio>
using namespace std;
int t,m,a,b,c;
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>t>>m;
	for(int i=1;i<=t;i++){
		cin>>a>>b>>c;
		if(b==0&&c==0){
			cout<<0<<endl;
		}else{
			if(b*b-4*a*c<0){
				cout<<"NO"<<endl;
				continue;
			}
			if(b==0){
				cout<<"sqrt("<<(int)(abs(c/a))<<")"<<endl;
				continue;
			}
			if(c==0){
				int x1=(-1*b+abs(b))/(2*a);
				int x2=(-1*b-abs(b))/(2*a);
				if(2*a==1){
					if(x1>x2){
						cout<<(int)(-1*b+abs(b))<<endl;
					}else{
						cout<<(int)(-1*b-abs(b))<<endl;
					}
				}else{
					if(x1>x2){
						if((int)(-1*b+abs(b))%(int)(2*a)==0)cout<<(int)(-1*b+abs(b))/(int)(2*a)<<endl;
						else cout<<(int)(-1*b+abs(b))<<"/"<<(int)(2*a)<<endl;
					}else{
						if((int)(-1*b-abs(b))%(int)(2*a)==0)cout<<(int)(-1*b-abs(b))/(int)(2*a)<<endl;
						else cout<<(int)(-1*b-abs(b))<<"/"<<(int)(2*a)<<endl;
					}
				}
			}else{
			    int d=b*b-4*a*c;
			    double dd=sqrt(d);
			    int ddd=sqrt(d);
			    if(dd=ddd){
				    int x1=(-1*b+ddd)/(2*a);
				    int x2=(-1*b-ddd)/(2*a);
				    if(2*a==1){
					    if(x1>x2){
						cout<<(int)x1<<endl;
					    }else{
						cout<<(int)x2<<endl;
					    }
				    }else{
					    if(x1>x2){
					    	if((int)(-1*b+ddd)%(int)(2*a)==0)cout<<(int)(-1*b+ddd)/(int)(2*a)<<endl;
						    else cout<<(int)(-1*b+ddd)<<"/"<<(int)(2*a)<<endl;
					    }else{
					    	if((int)(-1*b-ddd)%(int)(2*a)==0)cout<<(int)(-1*b-ddd)/(int)(2*a)<<endl;
						    else cout<<(int)(-1*b-ddd)<<"/"<<(int)(2*a)<<endl;
					    }
				    }
			    }else{
				    int p=-1*b/(2*a);
				    double q2;
				    if(a<0){
					    q2=-1/(2*a);
				    }else{
					    q2=1/(2*a);
				    }
				    int r=d;
				    if(q2==1){
				    	double pd=sqrt(r);
				    	int pd1=pd;
				    	if(pd1==pd)cout<<pd<<endl;
					    else cout<<"sqrt("<<(int)r<<")"<<endl;
				    }else{
					    int q=q2;
					    if(q==q2){
					    	double pd=sqrt(r);
				    	    int pd1=pd;
				    	    if(pd1==pd)cout<<q*pd<<endl;
						    else cout<<q<<"*sqrt("<<(int)r<<")"<<endl;
					    }else{
						    double q3=1/q2;
						    int qq=q3;
						    if(qq==q3){
						    	double pd=sqrt(r);
				    	        int pd1=pd;
				    	        if(pd1==pd){
				    	        	if(pd1%qq==0)cout<<pd/qq<<endl;
				    	        	else cout<<pd1<<'/'<<qq<<endl;
								}else cout<<"sqrt("<<(int)r<<")/"<<q3<<endl;
						    }
					    }
				    }
			    }
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
