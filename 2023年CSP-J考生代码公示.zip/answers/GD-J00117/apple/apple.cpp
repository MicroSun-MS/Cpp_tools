#include<iostream>
#include<cstdio>
using namespace std;
int n,a,b,sum;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	a=n%3;
	b=n;
	while(b>1){
		int c=(b+2)/3;
		b-=c;
		sum++;
	}
	cout<<sum+1<<" ";
	sum=0;
	while(n%3!=1){
		int c=(n-1+2)/3;
		n-=c;
		sum++;
	}
	cout<<sum+1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
