#include<iostream>
#include<cstdio>
using namespace std;
int n,d,v[100001],a[100001],ans,id,rest,road;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&d);
	for(int i=2;i<=n;i++)scanf("%d",&v[i]);
	for(int i=1;i<=n;i++)scanf("%d",&a[i]);
	id=1;
	for(int i=2;i<n;i++){
		road=0;
		if(a[i]<a[id]){
			for(int j=id+1;j<=i;j++){
				road+=v[j];
			}
			road-=rest;
			rest=0;
			int b=road/d;
			if(road%d!=0){
				ans+=a[id]*(b+1);
				rest=d*(b+1)-road;
			}else{
				ans+=a[id]*b;
			}
			id=i;
		}
	}
	for(int j=id+1;j<=n;j++){
		road+=v[j];
	}
	road-=rest;
	rest=0;
	int b=road/d;
	if(road%d!=0){
		ans+=a[id]*(b+1);
	}else{
		ans+=a[id]*b;
	}
	printf("%d",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
