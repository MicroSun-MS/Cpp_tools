#include<bits/stdc++.h>
using namespace std;
int n,head=1,tail,q,b,nn;
struct st{
	int no;
	int to;
	int from;
}a[1000001];
void br(int t)
{
	n--;
	if(t==head)
	{
		head=a[t].to;
		return;
	}
	if(t==tail)
	{
		tail=a[t].from;
		a[tail].to=0;
	}
	a[a[t].from].to=a[t].to;
	a[a[t].to].from=a[t].from;
	
}
int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		a[i].no=i;
		a[i].to=i+1;
		a[i].from=i-1;
	}
	a[n].to=0,tail=n,nn=n;
	while(n!=0)
	{
		q++;
		for(int i=head;i!=0;i=a[i].to)
		{
			if(a[i].no==nn)
				b=q;
			br(a[i].no)
			i=a[i].to;
			i=a[i].to;
		}
	}
}
