#include<bits/stdc++.h>
using namespace std;
int t,m,a,b,c,d,cnt,k[100001];
bool bz[100001];
bool pd(int x,int y)
{
	long long xy=x*y;
	return xy>0;
}
void Euler()
{
	for(int i=2;i<=1000;i++)
	{
		if(bz[i]==0)
			k[++cnt]=i;
		for(int j=1;j<=cnt&&i*k[j]<=1000;j++)
		{
			bz[i*k[j]]=1;
			if(i%k[j]==0)
				break;
		}
	}
}
void yf(int &a,int &d)
{
	for(int j=1;j<=cnt;j++)
	{
		while(a%k[j]==0&&d%k[j]==0)
		{
			a/=k[j],d/=k[j];
		}
	}
}
void ply(int a,int d)
{
	yf(a,d);
	if(a==1)
	{
		printf("%d",d);
	}
	else
	{
		printf("%d/%d",d,a);
	}
}
int main()
{
	freopen("uge.in","r",stdin);
	freopen("uge.out","w",stdout);
	scanf("%d%d",&t,&m);
	Euler();
	for(int i=1;i<=t;i++)
	{
		scanf("%d%d%d",&a,&b,&c);
		d=b*b-4*a*c;
		if(d<0)
		{
			printf("NO\n");
			continue;
		}
		if(int(sqrt(d))*int(sqrt(d))==d)
		{
			if(a>0)
				d=max(-(int(sqrt(d))+b),int(sqrt(d))-b);
			else
				d=max(int(sqrt(d))+b,b-int(sqrt(d)));
			if(d==0)
			{
				printf("0\n");
				continue;
			}
			if(pd(d,-1))
			{
				printf("-");
			}
			a=abs(a)*2,d=abs(d);
			ply(a,d);
			printf("\n");
		}
		else
		{
			if(b!=0)
			{
				if(!pd(a,-b))
				{
					printf("-");
				}
				ply(abs(a)*2,abs(b));
				printf("+");
			}
			int p=1;
			for(int j=1;j<=cnt;j++)
			{
				while(d%(k[j]*k[j])==0)
				{
					p*=k[j];
					d=d/k[j]/k[j];
				 } 
			}
			a=a*2;
			yf(p,a);
			if(p==a&&a==1)
			{
				printf("sqrt(%d)\n",d);
				continue;
			}
			if(a==1)
			{
				printf("%d*sqrt(%d)\n",p,d);
				continue;
			}
			if(p==1)
			{
				printf("sqrt(%d)/%d\n",d,a);
				continue;
			}
			printf("%d*sqrt(%d)/%d\n",p,d,a);
		}
	}
}

