#include<bits/stdc++.h>
using namespace std;
int n,d,a[400001],b[400001],fa[400001],s[400001],t[400001],ans,g;
int fi(int h)
{
	if(h==fa[h])
		return h;
	return fa[h]=fi(fa[h]);
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&d);
	for(int i=1;i<=n;i++)
	{
		fa[i]=i;
	}
	for(int i=1;i<=n-1;i++)
	{
		scanf("%d",&a[i]);
	}
	t[0]=2103801212;
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&b[i]);
		if(b[i]<=t[fi(i-1)])
			t[i]=b[i];
		else
		{
			fa[i]=fi(i-1);
		}
		s[fi(i-1)]+=a[i-1];
	}
	for(int i=1;i<=n;i++)
	{
		if(fi(i)==i)
		{
			ans+=(s[i]-g)/d*b[i]+b[i];
			g=d-(s[i]-g)+(s[i]-g)/d*d;
			if(g==d)
				g=0,ans-=b[i];
		}
	}
	printf("%d",ans);
}

