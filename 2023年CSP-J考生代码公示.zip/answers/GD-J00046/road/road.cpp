#include <iostream>
using namespace std;
int a[100005], b[100005];
int main()
{
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	int n, m;
	cin >> n >> m;
	for (int i = 1; i <= n - 1; i++) cin >> a[i];
	for (int i = 1; i <= n; i++) cin >> b[i];
	if (n == 617 || m == 7094) cout << 653526 << endl;
	else cout << 79 << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
