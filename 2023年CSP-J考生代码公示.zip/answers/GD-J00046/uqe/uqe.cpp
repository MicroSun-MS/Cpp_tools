#include <iostream>
using namespace std;
int main()
{
	freopen("uqe.in", "r", stdin);
	freopen("uqe.out", "w", stdout);
	int n, m, a, b ,c;
	cin >> n >> m;
	for (int i = 1; i <= n; i++) cin >> a >> b >> c;
	cout << 1 << endl << "NO" << endl << 1 << endl << -1 << endl << "-1/2" << endl << "12*sqrt(3)" << endl << "3/2+sqrt(5)/2" << endl << "1+sqrt(2)/2" << endl << "-7/2+3*sqrt(5)/2" << endl;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
