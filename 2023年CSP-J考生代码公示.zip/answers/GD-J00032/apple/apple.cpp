#include <iostream>
#include <cstdio>
#include <vector>
#include <cstring>
#include <algorithm>
using namespace std;

int cal(int x) {
	if (x % 3 == 0)
		return x / 3;
	return x / 3 + 1;
}

int main() {
	freopen("apple.in", "r", stdin);
	freopen("apple.out", "w", stdout);
	int n;
	cin >> n;
	int k = n, cnt = 1;
	while (k % 3 != 1) {
		k = k - cal(k);
		cnt++;
	}
	int tot = 0, lft = n;
	while (lft > 0) {
		tot++;
		lft = lft - cal(lft);
	}
	printf("%d %d\n", tot, cnt);
	return 0; 
} 
