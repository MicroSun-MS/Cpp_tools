#include <iostream>
#include <cstdio>
#include <vector>
#include <cstring>
#include <algorithm>
using namespace std;

int gcd(int x, int y) {
	return x == 0 ? y : gcd(y % x, x);
}
int dlt(int a, int b, int c) {
	return b * b - 4 * a * c;
}

void Print_R(int p, int q) {
	if ((p > 0 && q < 0) || (q > 0 && p < 0))
		printf("-");
	p = abs(p), q = abs(q);
	int g = gcd(p, q);
	p /= g, q /= g;
	if (p == 0) 
		printf("0");
	else if (q == 1) 
		printf("%d", p);
	else 
		printf("%d/%d", p, q);
}

void slv() {
	int a, b, c;
	scanf("%d%d%d", &a, &b, &c);
	int d = dlt(a, b, c);
	if (d < 0) {
		printf("NO");
		return;
	}
	if (d == 0) {
		Print_R(-1 * b, 2 * a);
		return;
	}
	int p = -1 * b, q = 1;
	int frc = a * 2;
	for (int i = 2; i * i <= d; i++) 
		if (d % (i * i) == 0)
			q = i;
	d /= q * q;
	if (d == 1) {
		if (frc > 0)
			p += q;
		else
			p -= q;
		Print_R(p, frc);
		return;	
	}
	
	if (p != 0) {
		Print_R(p, frc);
		printf("+");
	}
	
	frc = abs(frc);
	q = abs(q);
	int g = gcd(q, frc);
	q /= g, frc /= g;
	
	if (q != 1) 
		printf("%d*", q);

	printf("sqrt(%d)", d);

	if (frc != 1)
		printf("/%d", frc);
}

int main() {
	freopen("uqe.in", "r", stdin);
	freopen("uqe.out", "w", stdout);
	int T, M;
	scanf("%d%d", &T, &M);
	while (T--) {
		slv();	
		printf("\n");
	}
	return 0;
} 
