#include <iostream>
#include <cstdio>
#include <vector>
#include <cstring>
#include <algorithm>
using namespace std;
const int N = 1e5 + 5;

int n, d;
int a[N] = {0}, v[N] = {0};
long long s[N] = {0};
int mn[N] = {0};

int main() {
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	scanf("%d%d", &n, &d);
	for (int i = 1; i < n; i++) {
		scanf("%d", &v[i]);
		s[i + 1] = s[i] + v[i];
	}
	mn[0] = 2e9;
	for (int i = 1; i <= n; i++) {
		scanf("%d", &a[i]);
		mn[i] = min(mn[i - 1], a[i]);
	}
	long long sum = 0ll;
	long long len = 0ll; 
	for (int i = 2; i <= n; i++) {
		if (len >= s[i])
			continue;
		long long lft = s[i] - len;
		if (lft % d == 0ll)
			lft = lft / d;
		else
			lft = lft / d + 1;
		sum += 1ll * mn[i - 1] * lft; 
		len += lft * d;
	}
	printf("%lld\n", sum);
	
	return 0;
} 

