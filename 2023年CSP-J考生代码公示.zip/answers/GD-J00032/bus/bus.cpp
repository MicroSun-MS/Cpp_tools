#include <iostream>
#include <cstdio>
#include <queue>
#include <vector>
#include <cstring>
#include <algorithm>
using namespace std;
const int N = 1e4 + 5;
const int M = 2e4 + 5;
const int K = 105;
int n, m, k;
struct Edge {
	int to, val;
	Edge (int _to = 0, int _val = 0) :
		to(_to), val(_val) {}
}; 
vector<Edge> e[N * K];

int idx(int i, int j) {
	return j * n + i;
}
int dis[N * K] = {0};
void bfs(int st) {
	memset(dis, 0x3f, sizeof dis);
	queue<int> q;
	q.push(st);
	dis[st] = 0;
	while (!q.empty()) {
		int h = q.front();
		q.pop();
		for (auto i: e[h])
			if (dis[i.to] > dis[h] + 1) {
				dis[i.to] = dis[h] + 1;
				q.push(i.to); 
			} 
	}
}

 

int main() {
	freopen("bus.in", "r", stdin);
	freopen("bus.out", "w", stdout);
	scanf("%d%d%d", &n, &m, &k);
	for (int i = 1, u, v, w; i <= m; i++) {
		scanf("%d%d%d", &u, &v, &w);
		for (int j = 0; j < k; j++) {
			e[idx(u, j)].push_back(Edge(idx(v, (j + 1) % k), w));
		}
	}
	bfs(1);
	if (dis[n] == 0x3f3f3f3f)
		printf("-1\n");
	else
		printf("%d\n", dis[n]);
	return 0;
} 
