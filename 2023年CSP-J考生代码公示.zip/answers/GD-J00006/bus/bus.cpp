#include <bits/stdc++.h>
#include <cstdio>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n,m,k;
	cin>>n>>m>>k;
	int a[20002],u[20002],v[20002]
	for(int i = 1;i <= m;i++)
	{
		cin>>u[i]>>v[i]>>a[i];
	}
	cout<<-1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
