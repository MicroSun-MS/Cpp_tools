#include <bits/stdc++.h>
using namespace std;
int a,b,c;
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
    int t,m;
    cin>>t>>m;
    for(int i = 1;i <= t;i++)
    {
    cin>>a>>b>>c;
    if(b == 0 && a*c < 0)
    {
        cout<<"NO";
            return 0;
    }
    if(b*b - (4*a*c) < 0)
    {
        cout<<"NO";
        return 0;
    }

    }
    fclose(stdin);
    fclose(stdout);
    return 0;
}

