#include <bits/stdc++.h>
#include <cstdio>
using namespace std;
const long long MAXN = 100002;
long long v[MAXN] = {},a[MAXN];
long long vc = 0;
long long ans = 0;
int main()
{
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    int n;
    cin>>n;
    int d;
    cin>>d;
    for(int i = 1;i <= n-1;i++)
    {
        cin>>v[i];
        vc += v[i];
    }
    for(int i = 1;i <= n;i++)
    {
        cin>>a[i];
    }

    long long  mina = a[1];
    for(int i = 1;i <= n-1;i++)
    {
        mina = min(mina,a[i]);
        int sum = ceil(v[i]*1.0 / d);
        ans+= sum* mina;
        v[i+1] -= sum*d - v[i];
    }
    cout<<ans;
    fclose(stdin);
    fclose(stdout);
    return 0;
}

