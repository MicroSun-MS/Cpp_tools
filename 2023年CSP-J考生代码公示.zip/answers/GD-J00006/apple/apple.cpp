#include <bits/stdc++.h>
#include <cstdio>
int a[100001];
using namespace std;
int main()
{
    freopen("apple.in","r",stdin);
    freopen("apple.out","w",stdout);
    int n;
    cin>>n;
    int N = n;
    int k = 0;
   for(int i = 1;i <= n;i++)
   {
       a[i] = 1;
   }
   int head = 1;
   int tail = n;
   int day;
   bool flag = 1;
   for(day = 1;n > 0;day++)
   {
       while(a[head] == 0)
       {
           head++;
       }
       while(a[tail] == 0)
       {
           tail--;
       }
       for(int i = head;i <= tail;i++)
       {
           if(k == 0)
           {
               a[i]--;
               n--;
               k = 2;
           }
           else
           {
               k-=a[i];
           }
       }
       k = 0;
       if(a[N] == 0 && flag)
       {
       	 flag = 0;
           cout<<day<<" ";
       }
   }
   cout<<day - 1;
   fclose(stdin);
   fclose(stdout);
   return 0;
}

