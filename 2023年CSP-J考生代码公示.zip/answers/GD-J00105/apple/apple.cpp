#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n,sum=0,ans;
	cin>>n;
	bool flag=true;
	while(n){
		if((n-1)%3==0&&flag){
			flag=false;
			ans=++sum;
		}
		n-=(n-1)/3+1;
		sum++;
	}
	cout<<sum-1<<' '<<ans;
	return 0;
}

 
