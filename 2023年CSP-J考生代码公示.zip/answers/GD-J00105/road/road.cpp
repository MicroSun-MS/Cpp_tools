#include<bits/stdc++.h>
using namespace std;
int up(int x,int y){
	if(x%y) return x/y+1;
	else return x/y;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,d,sumv=0,c[100001],v[100001],dp[100001]={};
	cin>>n>>d;
	for(int i=1;i<n;i++){
		cin>>v[i];
		sumv+=v[i];
	}
	for(int i=1;i<=n;i++) cin>>c[i];
	dp[1]=0;
	for(int i=2;i<=n;i++){
			dp[i]=dp[i-1]+up(v[n-1],d)*max(c[i-1],c[i]);
	}
	 
	cout<<up(sumv,d)*c[1];
	return 0; 
}/*
5 4
10 10 10 10
9 8 9 6 5
*/

