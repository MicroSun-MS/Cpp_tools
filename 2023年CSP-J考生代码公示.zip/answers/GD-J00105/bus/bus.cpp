#include<bits/stdc++.h>
using namespace std;
int num_p,num_r,t,k,r[10001][10001];
int ans=2147483647;
void dfs(int p){
	if(p==num_p&&t%k==0){
		ans=(t<ans?t:ans);
		return;
	}
	for(int i=1;i<=num_p;i++){
		if(r[p][i]&&t>=r[p][i]-1){
			t++;
			dfs(i);
			t--;
		}
	}
	return;
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int u,v,a,maxa;
	cin>>num_p>>num_r>>k;
	for(int i=0;i<num_r;i++){
		cin>>u>>v>>a;
		maxa=max(a,maxa);
		r[u][v]=a+1;
	}
	for(int j=0;j<=maxa;j+=k){
		t=j;
		dfs(1);
	}
	if(ans==2147483647) cout<<"NO";
	else cout<<ans;
	return 0;
}
