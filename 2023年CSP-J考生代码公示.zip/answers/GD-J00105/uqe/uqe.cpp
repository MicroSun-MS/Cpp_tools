#include<bits/stdc++.h>
using namespace std;
int gcd(int x,int y){
	if(x<=y) return x;
	else return gcd(y,x-y);
}
int gen(int x){
	for(int i=sqrt(x);i>=1;i--){
		if(x%(i*i)==0) return i;
	}
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int t,m;
	cin>>t>>m;
	for(int j=0;j<=t;j++){
		int a,b,c;
		cin>>a>>b>>c;
		int x=b*b-4*a*c;//x=derta
		if(x<0){
			cout<<"NO"<<endl;
			break;
		}else{
			x=int(sqrt(x)); 
			if(b==0&&c==0){
				cout<<0<<endl;
			}else if(b==0){
				int y=gcd(x,a*2);
				if(y==2*a) cout<<x/gcd(x,a*2)<<endl;
				else cout<<x/y<<'/'<<2*a/y<<endl;
			}else if(c==0){
				int y=gcd(b,a);
				if(a*b<=0){
					cout<<0<<endl;
				}
			}
		} 
	}
	return 0;
}
