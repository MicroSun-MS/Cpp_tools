#include<bits/stdc++.h>
using namespace std;
int n;
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	int ans=0,sum=0;
	while(n>0)
	{
		ans++;
		if((n-1)%3==0 && !sum){sum=ans;}
		n-=1+(n-1)/3;
	}
	cout<<ans<<" "<<sum;
	return 0;
}
