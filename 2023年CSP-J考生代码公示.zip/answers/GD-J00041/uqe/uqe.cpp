#include<bits/stdc++.h>
using namespace std;
const int cnt=3e3;
int T,M,a,b,c,delta,p_1,p_2;
bool check_Rnum(int delta)//ȷ��sqrt(delta)�Ƿ�Ϊʵ��(��������) 
{
	int sqrtD=sqrt(delta);
	if(sqrtD*sqrtD==delta) return true;
	return false;
}
void fenjie(int delta)
{
	p_1=1;
	for(int i=2;i<=cnt;i++)
	{
		if(i*i>delta) break;
		while(delta%(i*i)==0)
		{
			delta/=(i*i);
			p_1*=i;
		}
	}
	p_2=delta;
}
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>T>>M;
	for(int i=1;i<=T;i++)
	{
		scanf("%d%d%d",&a,&b,&c);
		delta=b*b-4*a*c;
		if(delta<0)
		{
			printf("NO\n");
			continue;
		}
		if(check_Rnum(delta))
		{
			int sqrtD=sqrt(delta);
			int q=2*a;//-b+sqrtDΪ����,qΪ��ĸ
			bool fh=true;//fhΪ����,trueʱqΪ����falseʱqΪ��
			if(q<0)
			{
				fh=false;
				q=-q;
			}
			int p=-b+sqrtD;
			if(!fh)
			{
				p=-p;
				p=max(p,-(-b-sqrtD));
			}
			int g=__gcd(abs(p),abs(q));
			p/=g,q/=g;
			if(q>1) printf("%d/%d\n",p,q);
				else printf("%d\n",p);
		}
		else
		{
			//��sqrt(delta)�����Ϊp_1*sqrt(p_2)
			fenjie(delta);
			int q=2*a,qq=q;//-b+p_1*sqrt(p_2)Ϊ����,qΪ��ĸ
			bool fh=true;//fhΪ����,trueʱqΪ����falseʱqΪ��
			if(q<0)
			{
				fh=false;
				q=-q,qq=-qq;
			}
			int g1=__gcd(abs(b),abs(q)),g2=__gcd(abs(p_1),abs(qq));
			b/=g1,q/=g1;
			if(b)
			{
				if(!fh) b=-b;
				if(q>1) printf("%d/%d+",-b,q);
					else printf("%d+",-b);	
			}
			p_1/=g2,qq/=g2;
			if(p_1>1) printf("%d*sqrt(%d)",p_1,p_2);
				else printf("sqrt(%d)",p_2);
			if(qq>1) printf("/%d",qq);
			printf("\n");
		}
	}
	return 0;
}
/*
��Ҫ������˵���飺
��ϴ��x��
��ϴ��x��
��ϴ��x�� 
*/
