#include<bits/stdc++.h>
using namespace std;
int n,ans1,ans2;
bool flag;
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	while(n)
	{
		ans1++;
		if(!flag) ans2++;
		if(n%3==1&&!flag) flag=1;
		n-=(n-1)/3+1;
	}
	printf("%d %d",ans1,ans2);
	return 0;
}
