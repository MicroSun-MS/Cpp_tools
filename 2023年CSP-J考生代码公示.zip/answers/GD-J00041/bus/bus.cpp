#include<bits/stdc++.h>
using namespace std;
const int N=1e4+5;
int n,m,k,ans,T;
vector <int> g[N];
vector <int> tt[N];
void dfs(int x,int t)
{
	if(x==n&&!(t%k))
	{
		ans=min(ans,t);
		return;
	}
	if(T>1e7)
	{
		printf("-1");
		exit(0); 
	}
	for(int i=0;i<g[x].size();i++)
	{
		int son=g[x][i];
		T++;
		dfs(g[x][i],t+1+tt[x][i]);
	}
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++)
	{
		int w,v,a;
		scanf("%d%d",&w,&v,&a);
		g[w].push_back(v);
		tt[w].push_back(a);
	}
	printf("-1");
	return 0;
}
