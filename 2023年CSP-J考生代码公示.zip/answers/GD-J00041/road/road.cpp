#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1e5+5;
ll n,d,v[N],dis[N],a[N],dp[N],least[N],cost;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=2;i<=n;i++)
	{
		scanf("%lld",&v[i]);
		dis[i]=dis[i-1]+v[i];
		least[i]=dis[i]/d;
		if(dis[i]%d) least[i]++;
	}
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	cost=a[1];
	for(int i=2;i<=n;i++)
	{
		dp[i]=dp[i-1]+(least[i]-least[i-1])*cost;
		cost=min(cost,a[i]);
	}
	printf("%lld",dp[n]);
	return 0;
}
