#include<bits/stdc++.h>
using namespace std;
const int MAXN=1e5+5; 
long long n,d,v[MAXN],a[MAXN],sum,ans,now=0x7fffffff;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld%lld",&n,&d);
	for(int i=1;i<n;i++){
		scanf("%lld",&v[i]);
		v[i]+=v[i-1];
	}
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int i=1;i<n;i++){
		now=min(now,a[i]);
		if(sum>=v[i]) continue;
		long long l=(v[i]-sum-1)/d+1;
		sum+=l*d;
		ans+=l*now;
	}
	printf("%lld",ans); 
	return 0;
}
