#include<bits/stdc++.h>
using namespace std;
int n,sum,ans;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);
	while(n){
		sum++;
		if(!((n-1)%3)&&!ans) ans=sum;
		n-=(n-1)/3+1;
	}
	printf("%d %d",sum,ans);
	return 0;
}
