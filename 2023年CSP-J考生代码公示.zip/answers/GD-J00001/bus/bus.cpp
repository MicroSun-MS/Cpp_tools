#include<bits/stdc++.h>
using namespace std;
const int MAXN=1e4+5,MAXK=100+5; 
int n,m,k,a,b,c,f[MAXN][MAXK];
bool w[MAXN][MAXK];
vector<int> v[MAXN];
void dijkstra(){
	typedef pair<int,int> pii;
	priority_queue<pii,vector<pii>,greater<pii> > q;
	q.push(make_pair(0,1));
	f[1][0]=0;
	while(!q.empty()){
		pii t=q.top(); q.pop();
		int tx=t.second,ty=t.first;
		if(w[tx][ty%k]) continue;
		w[tx][ty%k]=true;
		for(int i=0;i<v[tx].size();i+=2){
			int to=v[tx][i],s=f[tx][ty%k]+1;
			if(s<v[tx][i+1]) s+=((v[tx][i+1]-s-1)/k+1)*k;
			if(s<f[to][s%k]){
				f[to][s%k]=s;
				q.push(make_pair(s,to));
			}
		}
	}
	return;
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;i++){
		scanf("%d%d%d",&a,&b,&c);
		v[a].push_back(b);
		v[a].push_back(c);
	}
	for(int i=1;i<=n;i++)
		for(int j=0;j<k;j++)
			f[i][j]=0x7fffffff;
	dijkstra();
	if(f[n][0]==0x7fffffff) printf("-1");
	else printf("%d",f[n][0]);
	return 0;
}
