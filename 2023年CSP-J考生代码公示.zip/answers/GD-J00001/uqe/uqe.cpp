#include<bits/stdc++.h>
using namespace std;
int T,M,a,b,c,dt,t,k;
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&T,&M);
	while(T--){
		scanf("%d%d%d",&a,&b,&c);
		dt=b*b-4*a*c;
		if(dt<0) printf("NO");
		else{
			a*=2,b=-b;
			t=sqrt(dt);
			if(t*t==dt){
				dt=0;
				b+=pow(-1,a<0)*t;
			}
			if(b){
				t=__gcd(abs(b),abs(a));
				if(b<0&&a<0||b>0&&a<0) b=-b,a=-a;
				printf("%d",b/t);
				if(a/t!=1) printf("/%d",a/t);
			}
			if(dt){
				int t=sqrt(dt);
				for(int i=t;i>=1;i--)
					if(!(dt%(i*i))){
						dt/=i*i;
						k=pow(-1,a<0)*i;
						break;
					}
				t=__gcd(abs(k),abs(a));
				if(b) printf("+");
				if(k<0&&a<0||k>0&&a<0) k=-k,a=-a;
				if(k/t!=1) printf("%d*",k/t);
				printf("sqrt(%d)",dt);
				if(a/t!=1) printf("/%d",a/t);
			}
			if(!b&&!dt) printf("0");
		}
		printf("\n");
	}
	return 0;
}
