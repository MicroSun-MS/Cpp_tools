#include<iostream>
#include<cstdio>
using namespace std;
const int N=1e9+10;
int n,cnt,cnt1,cnt2,cnt3,ans2;
bool vis[N],flag;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);
	cnt3=n;
	while(1){
		cnt1++;
		if(!flag&&cnt3%3==1) flag=1,ans2=cnt1;
		int ans=cnt3/3;
		if(cnt3%3!=0) ans++;
		cnt3-=ans;	
		if(cnt3==0) break;
	}
	if(!ans2) ans2=cnt1;
	printf("%d %d",cnt1,ans2);
	return 0;
}
