#include<iostream>
#include<cstdio>
using namespace std;
typedef long long ll;
const int N=1e5+10;
struct node{
	ll r,v,w;
}a[N];
ll n,d,ol,ans,now,dis,minn=0x3f3f3f3f;
bool flag=1;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld%lld",&n,&d);
	for(ll i=1;i<n;i++){
		scanf("%lld",&a[i].v);
		a[i].r=i+1;
	}
	for(ll i=1;i<=n;i++){
		scanf("%lld",&a[i].w);
		minn=min(a[i].w,minn);
	}
	if(a[1].w==minn){
		for(int i=1;i<n;i++) dis+=a[i].v;
		while(ol*d<dis) ol++;
		ans=ol*minn;
		printf("%lld",ans);
		return 0;
	}
	now=a[1].w,a[n].w=0x3f3f3f3f;
	while(ol*d<a[1].v) ol++;
	ans=ol*now;
	for(ll i=2;i<=n;i++){
		dis+=a[i-1].v;
		if(a[i].w>=now) continue;
		if(flag) now=a[i].w;
		ll ol1=ol;
		while(ol*d<dis) ol++;
		ans+=(ol-ol1)*now;
		if(flag) flag=0;
		else now=a[i].w;		
	}
	if(ol*d<dis){
		ll ol1=ol;
		while(ol*d<dis) ol++;
		ans+=(ol-ol1)*now;
	}
	printf("%lld",ans);
	return 0;
}
/*
5 4
10 10 10 10
9 8 9 6 5
*/
