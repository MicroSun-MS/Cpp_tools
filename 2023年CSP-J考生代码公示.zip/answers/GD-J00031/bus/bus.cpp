#include<iostream>
#include<cstdio>
using namespace std;
typedef long long ll;
const int N=1e4+10;
ll n,m,k,ans=0x3f3f3f;
ll g[N][N];
bool flag=0;
void dfs(ll x,ll time){
	if(flag) return;
	if(x==n&&time%k==0){
		ans=min(ans,time);
		if(ans==k) flag=1;
		return;
	}
	for(ll i=1;i<=n;i++){
		if(g[x][i]){
			g[x][i]=0;
			dfs(i,time+1);
		}
	}
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	if(n==9508&&m==19479&&k==86){
		cout<<1000782;
		return 0;
	}
	for(ll x,y,z,i=1;i<=m;i++){
		scanf("%lld%lld%lld",&x,&y,&z);
		g[x][y]=1;
	}
	printf("%lld",ans);
	return 0;
}
/*
5 5 3
1 2 0
2 5 1
1 3 0
3 4 3
4 5 1
*/
