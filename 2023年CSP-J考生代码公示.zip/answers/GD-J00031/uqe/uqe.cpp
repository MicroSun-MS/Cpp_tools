#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
typedef long long ll;
int t,m;
ll a,b,c,dlt;
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&t,&m);
	for(int i=1;i<=t;i++){
		scanf("%lld%lld%lld",&a,&b,&c);
		dlt=b*b-4*a*c;
		if(dlt<0){
			printf("NO\n");
			continue;
		}
		double x=(-b+sqrt(dlt))/(2*a);
		ll y=(ll)x;
		double z=(double) y;
		bool flag=0;
		if(x!=z){
			int maxn=t*t*t;
			for(ll i=1;i<=maxn;i++){
				double p=(double)i/x;
				ll y1=(ll)p;
				double z1=(double) y1;
				if(p==z1&&__gcd(i,y1)==1){
					flag=1;
					y1=-y1,i=-i;
					printf("%lld/%lld\n",i,y1);
					break;
				}
			}
		}else printf("%lld\n",y); 
	}
	return 0;
}
/*
9 1000
1 -1 0
-1 -1 -1
1 -2 1
1 5 4
4 4 1
1 0 -432
1 -3 1
2 -4 1
1 7 1
*/
