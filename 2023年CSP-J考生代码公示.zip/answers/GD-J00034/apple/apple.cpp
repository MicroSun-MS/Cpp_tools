#include<bits/stdc++.h>
using namespace std;
int sum,ans,k1[1000001];
bool a[1000001];
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n;
	scanf("%d",&n);
	if(n==1){
		printf("1 1");
		return 0;
	}
	if(n==2){
		printf("2 2");
		return 0;
	}
	sum=1;
	ans=2;
	int y=2,l;
	while(ans<n){
		y++;
		l=ans;
		ans+=sum;
		sum=l;
	}
	if(n%3==0&&n!=3)y--;
	printf("%d ",y);
	if(n>1000000){
	cout<<1;
	return 0;
	}
	int k=0;
	for(int i=1;i<=y;i++){
		int o=1;
		while(a[o])o++;
		a[o]=true;
		for(int j=1;j<=n;j++){
			while(!a[j]&&j<n&&k!=2){
				k++;
				j++;
			}
			if(k==2){
				a[j]=true;
				if(j==n){
					if(n%3==0&&n!=3)i--;
					printf("%d",i);
					return 0;
				}
				k=0;
			}
		}
	}
	printf("%d",y);
	fclose(stdin);
	fclose(stdout);
}
