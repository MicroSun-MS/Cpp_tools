#include<bits/stdc++.h>
using namespace std;
struct g{
	int yq,ui;
};
int ll;g k1[100001];
long long sum,ans,money;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,m;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n-1;i++){
		scanf("%d",&k1[i].ui);
		ans+=k1[i].ui;
	}
	for(int i=1;i<=n;i++){
		scanf("%d",&k1[i].yq);
	}
	int i=1;
	while(sum<ans){
		int o=i+1;int h=0;
		while(k1[o].yq>=k1[i].yq&&o<n)o++;
		ll=sum;
		for(int j=i;j<o;j++)
			sum+=k1[i].ui;
			if(sum>=ans){
				if((ans-ll)%m==0){
				money+=(ans-ll)/m*k1[i].yq;
			}
			else money+=((ans-ll)/m+1)*k1[i].yq;
				cout<<money;
				return 0;
			}
			if((sum-ll)%m==0){
				money+=(sum-ll)/m*k1[i].yq;
				i=o;
			}
			else {
				money+=((sum-ll)/m+1)*k1[i].yq;
				sum=ll+m*((sum-ll)/m+1);
				ll=sum;
				i=o;
			}
		
	}
	cout<<money;
	fclose(stdin);
	fclose(stdout);
}
