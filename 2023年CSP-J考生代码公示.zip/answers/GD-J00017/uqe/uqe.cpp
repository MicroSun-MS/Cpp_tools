//9:47
#include<bits/stdc++.h>
using namespace std;
int a,b,c,T,m;
int gcd(int a,int b){
	if(b==0)return a;
	return gcd(b,a%b);
}
void printr(int a,int b){
	int g=gcd(a,b);
	if(a==0){
		printf("0");
		return ;
	}
	if(b==g){
		printf("%d",a/g);
		return ;
	}
	if(a*b<0){
		printf("-");
		a=abs(a);
		b=abs(b);
		g=abs(g);
	}
	printf("%d/%d",a/g,b/g);
}
void solve(){
	cin>>a>>b>>c;
	int del=b*b-4*a*c;
	if(del<0){
		puts("NO");
		return ;
	}
	int v=sqrt(del);
	int down=2*a;
	if(v*v==del){
		int up1=-b+v,up2=-b-v,up;
		if(up1*2*a<up2*2*a)up=up2;
		else up=up1;
		printr(up,down);
		puts("");
	}
	else {
		int dls=1;
		for(int i=2;i*i<=del;i++){
			while(del%(i*i)==0){
				dls*=i;
				del/=(i*i);
			}
		}
		if(-b!=0){
			printr(-b,down);
			int g=gcd(dls,down);
			if(dls*down<0){
				dls=abs(dls);
				down=abs(down);
				g=abs(g);
			}
			printf("+");
			dls/=g,down/=g;
			if(dls==1){
				if(down!=1)printf("sqrt(%d)/%d\n",del,down);
				else printf("sqrt(%d)\n",del);
			}
			else {
				if(down!=1)printf("%d*sqrt(%d)/%d\n",dls,del,down);
				else printf("%d*sqrt(%d)\n",dls,del);
			}
		}
		else {
			int g=gcd(dls,down);
			if(dls*down<0){
				dls=abs(dls);
				down=abs(down);
				g=abs(g);
			}
			dls/=g,down/=g;
			if(dls==1){
				if(down!=1)printf("sqrt(%d)/%d\n",del,down);
				else printf("sqrt(%d)\n",del);
			}
			else {
				if(down!=1)printf("%d*sqrt(%d)/%d\n",dls,del,down);
				else printf("%d*sqrt(%d)\n",dls,del);
			}
		}
	}
	
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>T>>m;
	while(T--)solve();
}
/*
7:20
起床，去其他宿舍拉了几个人一起去饭堂吃饭，感觉睡得很好

7:50
到了机房，路上玩手机被教练看到了，但是没说什么，又在机房玩了一会手机

8:20
教练提醒我们去考场，每年都要听这个考场须知，真的烦

8:30
开始考试，我搞反密码输错好几次，rp--
T1没啥好说的，但是我写挂了一次，调的时候还把CP Editor卡崩了
T2一开始想复杂了，又读了一遍题就会了
看了看T3题面，很不友好，先去开了T4
不是很难，这种题好像做过，开写开写
9:30 写完了，大样例过不了，调调调
9:47 调过了，去看T3，发现好像码量不大
9:55 写完了，两个样例都过不了，这下难受了，看着这代码就头疼
调了一会，莫名re了，开始检查是不是哪里除以了0，发现没有，开始罚坐
10:25 哦好我是傻逼，printf("%d*sqrt(%d)\n",dls,del);
改过来之后发现其他地方也是这样，都改完了就过样例了
不想看有没有细节问题，加文操，开始坐牢，感觉要挂大分

东张西望，发现generals非常严肃，真是太喜感了
lbw已经开始罚坐了，膜拜
其他人坐在我后面，看不到，悲

11:24 监考老师提醒说不能在注释里写一些侮辱性的话，一经核实禁赛三年/jy
generals 玩小恐龙没关声音，乐
*/