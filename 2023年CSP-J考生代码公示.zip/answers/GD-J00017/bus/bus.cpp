#include<bits/stdc++.h>
using namespace std;
const int maxn=2e4+5;
const int inf=0x3f3f3f3f;
int n,m,k,lim[maxn],head[maxn],cnt,dis[maxn][105],ans=inf;
struct edge{
	int to,id,nxt;
}e[maxn];
void addedge(int u,int v,int pos){
	e[++cnt]={v,pos,head[u]};
	head[u]=cnt;
}
struct node{
	int pos,len;
	bool operator <(const node &x)const {
		return len>x.len;
	}
}a[maxn][105];
bool vis[maxn][105];
priority_queue<node>q;
void dij(int x){
	memset(vis,0,sizeof vis);
	for(int i=1;i<=n;i++)for(int j=0;j<k;j++)a[i][j].pos=i,a[i][j].len=inf;
	a[1][0].len=0;
	q.push(a[1][0]);
	while(!q.empty()){
		int u=q.top().pos,t=q.top().len;
		q.pop();
		if(vis[u][t%k])continue;
		vis[u][t%k]=1;
		for(int i=head[u];i;i=e[i].nxt){
			int v=e[i].to;
			if(lim[e[i].id]<=t){
				if(a[v][(t+1)%k].len>t){
					a[v][(t+1)%k].len=t+1;
					q.push(a[v][(t+1)%k]);
				}
			}
			else {
				int val=lim[e[i].id]-t;
				t+=(val/k)*k;
				if(t<lim[e[i].id])t+=k;
				if(a[v][(t+1)%k].len>t){
					a[v][(t+1)%k].len=t+1;
					q.push(a[v][(t+1)%k]);
				}
			}
		}
	}
	ans=min(ans,a[n][0].len);
}
signed main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m>>k;
	int mx=0;
	for(int i=1;i<=m;i++){
		int u,v;
		cin>>u>>v>>lim[i];
		mx=max(mx,lim[i]);
		addedge(u,v,i);
	}
	dij(0);
	// for(int i=1;i<=n;i++){
		// for(int j=0;j<k;j++)cout<<a[i][j].len<<' ';
		// cout<<endl;
	// }
	if(ans==inf)puts("-1");
	else cout<<ans;
}