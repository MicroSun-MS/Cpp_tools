#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n,cnt=0,pos=0;
	cin>>n;
	while(n>0){
		cnt++;
		int tmp=(n+2)/3;
		if(n%3==1&&!pos)pos=cnt;
		// cout<<n<<' '<<tmp<<endl;
		n-=tmp;
	}
	cout<<cnt<<' '<<pos;
}