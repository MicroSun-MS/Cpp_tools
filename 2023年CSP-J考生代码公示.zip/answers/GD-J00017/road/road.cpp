#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=1e5+5;
int n,d,dis[maxn],v[maxn],f[maxn],a[maxn];
vector<int>vv;
signed main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=1;i<n;i++)cin>>v[i],dis[i]=dis[i-1]+v[i];
	for(int i=1;i<n;i++)cin>>a[i];
	int pos=1;
	vv.push_back(1);
	for(int i=2;i<=n;i++){
		f[pos]+=v[i-1];
		if(a[i]<a[pos]){
			pos=i;
			vv.push_back(i);
		}
	}
	int ans=0;
	for(int i=0,lst=0;i<vv.size();i++){
		int p=f[vv[i]]-lst;
		int val=(p+d-1)/d;
		ans+=val*a[vv[i]];
		lst=val*d-p;
	}
	cout<<ans;
}