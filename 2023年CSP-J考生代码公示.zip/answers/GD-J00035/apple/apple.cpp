#include<bits/stdc++.h>
using namespace std;
const int  maxn=1e6+10;
int n;

int vis[maxn];
int cnt=2,ans,pos;
int main() 
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
	 	if(!vis[i])
	 	{
	 		cnt=2;
	 		ans++;
	 		for(int j=i;j<=n;j++)
	 		{
	 			if(!vis[j])
	 			{
	 				if(j==n)
	 				{
	 					pos=ans;
					 }
	 				if(cnt==2)
	 				{
	 					vis[j]=1;
	 					cnt=0;
					 }
					 else
					 cnt++;
				 }
			 }
		 }
	}
	cout<<ans<<" "<<pos<<endl;
	return 0;
}
