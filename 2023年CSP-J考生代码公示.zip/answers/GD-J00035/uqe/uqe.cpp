#include<bits/stdc++.h>
using namespace std;
int t,m;
int f[1010];
void init()
{
	for(int i=1;i<=1000;i++)
	{
		f[i]=i*i;
	}
}
int cnt(double de)
{
	int sum=1;
	for(int i=2;i<=1000;i++)
	{
		if(f[i]>de)
		break;
		while(int(de)%f[i]==0)
		{
			de/=f[i];
			sum*=f[i];
		}
	}
	return sqrt(sum);
}
void cal(double a,double b,double c)
{
	double de;
	de=b*b-a*c*4;
	de=sqrt(de);
//	cout<<de<<endl;
	double x,k;
	x=(-b+de)*1.0/(2*a),k=(-b-de)*1.0/(2*a);
	x=max(x,k);
	if(int(x)!=x)
	{
		if(x<0)
		{
			cout<<"-";
		}
		cout<<abs((x*2*a)*1.0/__gcd(int(2*a),int(-b+de)));
		cout<<"/";
		cout<<abs((2*a)*1.0/__gcd(int(2*a),int(-b+de)));
		cout<<endl;
	}
	else
	cout<<x<<endl;
}
void cl(double a,double b,double c)
{
	double de;
	de=b*b-a*c*4;
	int k=cnt(de);
 
	de=de/k/k;
	double bf;
	bf=-b/(2*a);
	if(bf==0)
	{
		bf=0;
	}
	else if(int(bf)!=bf)
	{
		if(bf<0)
		{
			cout<<"-";
		}
		cout<<abs(-b*1.0/__gcd(int(2*a),int(-b)));
		cout<<"/";
		cout<<abs((2*a)*1.0/__gcd(int(2*a),int(-b)));	cout<<"+";
	}
	else
	{
		cout<<bf;
		cout<<"+";
	}
 
 	bf=abs(k/(2*a));
 	if(int(bf)!=bf)
	{
		
		int j=k*1.0/__gcd(int(2*a),int(k));
		if(j!=1)
		{
			cout<<j;
			cout<<"*";
		}
		cout<<"sqrt("<<de<<")";
		cout<<"/";
		cout<<(2*a)*1.0/__gcd(int(2*a),int(k));
	}
 	else
 	{
 		if(bf!=1)
 		{
 			cout<<bf;cout<<"*";
		 }
		
		cout<<"sqrt("<<de<<")";
	 }
	 cout<<endl;
	
}
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	init();
 	cin>>t>>m;
 	while(t--)
 	{
 		int a,b,c;
 		cin>>a>>b>>c;
 		double de;
 		de=b*b-4*a*c;
 		if(de<0)
 		{
 			cout<<"NO"<<endl;
		 }
		 else if(sqrt(de)==int(sqrt(de)))
		 {
		 	cal(a,b,c);
		 }
		 else
		 {
		 	cl(a,b,c);
		 }
	 }


	return 0;
}

