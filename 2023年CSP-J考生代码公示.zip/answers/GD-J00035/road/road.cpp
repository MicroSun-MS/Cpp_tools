#include<bits/stdc++.h>
using namespace std;
const int maxn=1e3+10;
int n;
int v[maxn];
int a[maxn];
int dp[maxn][maxn],d,tot,pos,maxs=1e9;	
int ans=1e9;
void dfs(int i,int val,int cost)
{
	if(i==n&&val>=0)
	{
		ans=min(ans,cost);
		return ;
	}
	for(int j=1;j<=tot;j++)
	{
		if((val+j)*d<v[i+1])
		continue;
		dfs(i+1,val+j,cost+j*a[i]);
	}
	 if(val*d>=v[i+1])
	 {
	 	int k=(v[i+1])/d;
	 	if(v[i+1]%d!=0)
	 	{
	 		k++;
		 }
	 	dfs(i+1,val-k,cost);
	 }
	 
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=2;i<=n;i++)
	{
		cin>>v[i];
		tot+=v[i];
	}
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		if(maxs>a[i])
		{
			maxs=a[i];
			pos=i;
		}
	}
 
	if(tot%d==0)
	{
		tot/=d;
	}
	else
	{
		tot/=d;
		tot++;
	}
//	cout<<tot<<endl;
	if(pos==1)
	{
		cout<<a[1]*tot;
	} 
	else
	{
		dfs(1,0,0);
	}
	cout<<ans<<endl;
 
	return 0;
}

