#include<bits/stdc++.h>
using namespace std;double a=1.0;
int main(){
	//freopen("apple.in","r",stdin);freopen("apple.out","w",stdout);
	cout<<12%8;
}
