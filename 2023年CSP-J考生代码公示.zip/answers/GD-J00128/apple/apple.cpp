#include<bits/stdc++.h>
using namespace std;int a,b,c,d,s,m;
int main(){
	freopen("apple.in","r",stdin);freopen("apple.out","w",stdout);
	scanf("%d",&a);while(a){
		s++;
		if(a%3==1&&!d)d=1,c=s;
		m=a%3;a=a-a/3;if(m)a--;
	}printf("%d %d",s,c);
}
