#include<bits/stdc++.h>
using namespace std;long long b,i,c[100001],d[100001],j,k,l,m,s,a;
int main(){
	freopen("road.in","r",stdin);freopen("road.out","w",stdout);
	scanf("%lld%lld",&a,&b);for(i=1;i<a;i++)scanf("%lld",&c[i]);
	for(i=1;i<=a;i++)scanf("%lld",&d[i]);i=1;
	while(i<a){
		j=i+1;k=l=0;k+=c[i];while(d[j]>=d[i]&&j<a-1)j++,k+=c[j];if(k<=m){
			m-=k;i=j;continue;
		}else k-=m,m=0;
		if(k%b)l++;m=m+(k/b+l)*b;s=s+(k/b+l)*d[i];m-=k;i=j;
	}printf("%lld",s);
}
