#include <bits/stdc++.h>
using namespace std;

int a, b, c, n, m, ty;

struct num
{
	int fz, fm;	
};
struct num yf(struct num a)
{
	int g = __gcd(a.fz, a.fm);
	g = abs(g);
	a.fz /= g, a.fm /= g;
	return a;
}

struct snum
{
	int a, b;
};
struct snum solve(int a)
{
	snum res;
	int ty = a > 0 ? 1 : -1;
	a = abs(a);
	res.a = 1;
	res.b = a;
	int k = 2, cnt, t = 1;
	while (res.b != 1)
	{
		cnt = 0;
		while (res.b % k == 0) res.b /= k, cnt++;
		res.a *= max((int)pow(k, cnt / 2), 1);
		if (cnt % 2 == 1) t *= k;
		k++;
	}
	res.b = t;
	return res;
}

int main()
{
	freopen("uqe.in", "r", stdin);
	freopen("uqe.out", "w", stdout);
	cin >> n >> m;
	for (int i = 1; i <= n; i++)
	{
		cin >> a >> b >> c;
		
		int d = b * b - 4 * a * c;
		if (d < 0) 
		{
			cout << "NO" <<endl;
			continue;
		}
		
		double ans = (-b + sqrt(d)) / (2.0 * a);
		if ((int)ans == ans)
		{
			cout << ans << endl;
			continue;
		}
		
		if (b)
		{ 
			num r1 = {-b, 2 * a};
			r1 = yf(r1);
			ty = r1.fm < 0 ? -1 : 1;
			cout << r1.fz * ty;
			if (abs(r1.fm) != 1) cout << '/' << abs(r1.fm); 
		}
		if (b && d) cout << "+";
		if (d)
		{
			snum r2 = solve(d);
			num r3 = {r2.a, 2 * a};
			ty = r3.fz < 0 ? -1 : 1;
			r3 = yf(r3);
			if (abs(r3.fz) != 1) cout << r3.fz * ty;
			cout << "*sqrt(" << r2.b << ")";
			if (abs(r3.fm) != 1) cout << "/" << abs(r3.fm);
		}
		
		cout << endl;
	}
	return 0;
}
