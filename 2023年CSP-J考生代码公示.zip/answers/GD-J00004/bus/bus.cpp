#include <bits/stdc++.h>
using namespace std;

const int maxn = 1e4;
vector<int> mp[maxn][maxn];
int n, m, k, u, v, a;

int main()
{
	cin >> n >> m >> k;
	return 0;
}
