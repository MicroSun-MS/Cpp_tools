#include <bits/stdc++.h>
using namespace std;

const int Max = 1e8;
int n, a[Max], cnt;

int main()
{
	freopen("apple.in", "r", stdin);
	freopen("apple.out", "w", stdout);
	cin >> n;
	int day = 1;
	for (int i = 1; i <= n; i++)
	{
		if (a[i]) continue;
		a[i] = 1;
		for (int j = i; j <= n; j++)
		{
			if (a[j]) continue;
			cnt++;
			if (cnt == 2) a[j + 1] = 1, cnt = 0;
		}
		cnt = 0;
		bool flag = true;
		for (int j = 1; j <= n; j++)
		{
			if (!a[j]) 
			{
				flag = false;
				break;
			}
		}
		if (flag) cout << day << ' ';
		if (a[n]) cout << day;
		day++;
	}
	return 0;
}
