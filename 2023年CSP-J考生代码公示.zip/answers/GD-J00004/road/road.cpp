#include <bits/stdc++.h>
using namespace std;

const int M = 1e6 + 5;
int v[M], a[M], f[M], ans = 0;

int main()
{
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	int n, d;
	cin >> n >> d;
	for (int i = 1; i < n; i++) cin >> v[i];
	for (int i = 1; i <= n; i++) cin >> a[i];
	
	int sum = 0;
	for (int i = 1; i < n; i++) sum += v[i];
	cout << sum * a[i]; 
	
	return 0;
 } 
