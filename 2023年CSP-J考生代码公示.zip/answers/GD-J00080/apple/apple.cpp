#include<bits/stdc++.h> 
using namespace std;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n;cin>>n;
	int x=n,cnt=0,day=-1;
	while(x){
		cnt++;
		x--;
		int a=x/3,b=x%3;
		if(!b&&day==-1){
			day = cnt;
		}
		x = 2*a+b;
	}
	cout<<cnt<<" "<<day;
	return 0;
}
