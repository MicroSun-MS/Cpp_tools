#include<bits/stdc++.h>
using namespace std;
struct path{
	int u,v,a;
}pathes[20010];
struct nod{
	int n,t;
};
int getin(){
	char c=getchar();
	int ans = 0,flag = 1;
	while(c<'0'||c>'9'){
		if(c=='-') flag = -1;
		c = getchar();
	}
	while(c>='0'&&c<='9'){
		ans *= 10;
		ans += c-'0';
		c = getchar();
	}
	return ans*flag;
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int n=getin(),m=getin(),k=getin(),maxn=0;
	for(int i=1;i<=m;i++){
		pathes[i].u=getin();
		pathes[i].v=getin();
		pathes[i].a=getin();
		maxn = max(maxn,pathes[i].a);
	}
	for(int t=k;t<=maxn+k;t+=k){
		queue<nod> q;
		nod tmp;
		tmp.n = 1;
		tmp.t = t;
		q.push(tmp);
		while(!q.empty()){
			tmp = q.front();
			q.pop();
			if(tmp.n==n&&tmp.t%k==0){
				cout<<tmp.t;
				return 0;
			}
			for(int i=1;i<=m;i++){
				if(pathes[i].u==tmp.n&&pathes[i].a<=tmp.t){
					nod new_tmp;
					new_tmp.n = pathes[i].v;
					new_tmp.t = tmp.t+1;
					q.push(new_tmp);
				}
			}
		}
	}
	cout<<-1;
	return 0;
}
