#include<bits/stdc++.h>
using namespace std;
int t,m;
int gcd(int a,int b){
	while(b){
		int c = a%b;
		a = b;
		b = c;
	}
	return abs(a);
}
bool print(double v){
	int q;
	double p;
	for(q=1;q<=m;q++){
		p = q*v;
		if(p-int(p)!=0) continue;
		if(gcd(p,q)==1) break;
	}
	if(q>m) return false;
	if(q==1){
		cout<<p;
	}
	else{
		cout<<p<<'/'<<q;
	}
	return true;
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>t>>m;
	for(int i=1;i<=t;i++){
		int a,b,c;cin>>a>>b>>c;
		int tr = (b*b)-(4*a*c);
		if(tr<0){
			cout<<"NO"<<endl;
			continue;
		}
		double x1=(-b+sqrt(tr))/(2*a),x2=(-b-sqrt(tr))/(2*a);
		double pr = max(x1,x2);
		if(int(pr)-pr==0) cout<<pr<<endl;
		else{
			if(x1>=x2){
				bool back = print(x1);
				if(back){
					cout<<endl;
					continue;
				}
			}
			else{
				bool back = print(x2);
				if(back){
					cout<<endl;
					continue;
				}
			}
		}
		
	}
	return 0;
}

