#include<bits/stdc++.h>
using namespace std;
long long arr[100010];
int price[100010],n,d;
double dp[100010][2];
int getin(){
	char c=getchar();
	int ans = 0,flag = 1;
	while(c<'0'||c>'9'){
		if(c=='-') flag = -1;
		c = getchar();
	}
	while(c>='0'&&c<='9'){
		ans *= 10;
		ans += c-'0';
		c = getchar();
	}
	return ans*flag;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=getin();
	d=getin();
	for(int i=1;i<n;i++) arr[i] = getin();
	for(int i=1;i<=n;i++){
		price[i] = getin();
		dp[i][0] = dp[i][1] = 1145141919;
	}
	dp[1][0] = 0;
	dp[1][1] = 0;
	for(int i=2;i<=n;i++){
		for(int j=1;j<i;j++){
			int jl=0,crjl=dp[j][1]*d;
			for(int k=j;k<i;k++) jl += arr[k];
			double cost = 0,oil=0;
//			cout<<j<<"->"<<i;
			if(jl>crjl){
				oil = (jl-crjl)/d;
				if((jl-crjl)%d) oil++;
				cost = oil * price[j];
//				cout<<" oil:"<<oil<<" cost:"<<cost;
			}
			double c = dp[j][0]+cost;
			double o = dp[j][1]+oil;
			o -= double(jl)/double(d);
			if(c<dp[i][0]){
				dp[i][0] = c;
				dp[i][1] = o;
			}
//			cout<<" dp:"<<dp[i][0]<<" ";
//			cout<<" cnt_cost:"<<c<<" last_oil:"<<o<<endl;
		}
	}
	cout<<dp[n][0];
	return 0;
}

