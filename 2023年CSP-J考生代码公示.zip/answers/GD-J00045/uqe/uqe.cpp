#include<bits/stdc++.h>
using namespace std;
int t;
int M;
int a,b,c;
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>t>>M;
	while(t--)
	{
		cin>>a>>b>>c;
		if(b*b-4*a*c<0)
		{
			cout<<"NO";
			if(t!=0) cout<<endl;
			continue;
		}
		cout<<0;
		if(t!=0) cout<<endl;
	}
	return 0;
}
