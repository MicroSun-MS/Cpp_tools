#include<bits/stdc++.h>
using namespace std;
int n,m,k;
vector<int> p[10001];
int a[100001];
int dis[100001];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cout<<"-1";
	return 0;
}
