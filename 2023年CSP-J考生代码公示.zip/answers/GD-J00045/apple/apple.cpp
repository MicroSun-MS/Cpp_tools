#include<bits/stdc++.h>
using namespace std;
int n;
bool vis[1000001];
int head=1;
int next(int x)
{
	int sum=0;
	while(1)
	{
		x++;
		if(vis[x]==0) sum++;
		if(x>n) return 0;
		if(sum==3)
		{
			return x;
		}
	}
}
int nextq(int x)
{
	int sum=0;
	while(1)
	{
		x++;
		if(x>n) return 0;
		if(vis[x]==0) return x;
		
	}
}
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	int ans;
	int sum=0;
	head=1;
	while(head)
	{
		sum++;
		for(int i=head;i;i=next(i))
		{
			vis[i]=1;
			if(i==n) ans=sum;
		}
		
		head=nextq(head);
		
	}
	cout<<sum<<" "<<ans;
	return 0;
}

