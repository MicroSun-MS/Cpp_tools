#include<bits/stdc++.h>
using namespace std;
int n;
int a[100001];
long long qzh[100001];
long long dis[100001];
double dq;
int d;
bool vis[100001];
const long long inf=0x3f3f3f3f;
queue<pair<double,int> > q;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=1;i<=n-1;i++)
	{
		int x;
		cin>>x;
		qzh[i+1]=qzh[i]+x;
	}
	for(int i=1;i<=n;i++)
	{
		dis[i]=inf;
		cin>>a[i];
	}
	dis[1]=0;
	q.push({0,1});
	while(!q.empty())
	{
		dq=q.front().first;
		int x=q.front().second;
		q.pop();
		if(vis[x]) continue;
		vis[x]=1;
		for(int i=1;i<=n;i++)
		{
			if(x==i) continue;
			int q1=abs(qzh[i]-qzh[x]);
			double qq=q1*1.0/d;
			double tt=ceil(qq-dq);
			long long t=tt*a[x];
			double dqq=tt-qq;
			if(dis[x]+t<dis[i])
			{
				dis[i]=dis[x]+t;
				if(i==n)
				{
					continue;
				}
				q.push({dqq,i});
				vis[i]=0;
			}
		}
	}
	cout<<dis[n];
	return 0;
}
