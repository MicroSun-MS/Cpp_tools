#include<bits/stdc++.h>
using namespace std;
long long n,a[1000100],f,b,c,p,s,k,m;
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	k=n;
	if(n%3==1) c=1;
	if(n%9==2||n%9==6) c=2;
	while(1)
	{
		b++;
		if(k%3!=0) p=k/3+1;
		else p=k/3;
		k-=p;
		s+=p;
		if(k==3)
		{
			b+=3;
			break;
		}
	}
	for(int i=1;i<=1000100;i++) a[i]=1;
	for(int i=1;i<=b;i++)
	{
		m=2;
		f=0;
		for(int j=1;j<=n;j++)
		{
			if(a[j]==1)
			{
				if(m==2)
				{
					a[j]=0;
					m=0;
					if(j==n)
					{
						f=1;
						c=i;
						break;
					}
				}
				else m++;
			}
		}
		if(f==1) break;
	}
	cout<<b<<" "<<c;
	return 0;
} 
