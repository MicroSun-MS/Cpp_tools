#include<bits/stdc++.h>
using namespace std;
long long n,dis,k,m,ans,d,u[1000100],a[1000100],v[1000100],b[1000100],c[1000100];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++)
	{
		cin>>u[i]>>v[i]>>a[i];
	}
	cout<<-1;
	return 0;
}
