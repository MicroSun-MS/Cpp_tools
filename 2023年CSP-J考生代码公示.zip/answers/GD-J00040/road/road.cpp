#include<bits/stdc++.h>
using namespace std;
long long n,dis,k,m,ans,d,a[1000100],v[1000100],b[1000100],c[1000100];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=1;i<=n-1;i++) cin>>v[i],b[i]=b[i-1]+v[i];
	for(int i=1;i<=n;i++) cin>>a[i];
	m=1;
	while(m<n)
	{
		k=n;
		for(int j=m+1;j<=n;j++)
		{
			if(a[j]<a[m])
			{
				k=j;
				break;
			}
		}
		long long ne=b[k-1]-dis;
		if(ne%d==0) ans+=(ne/d)*a[m],dis+=ne;
		else ans+=(ne/d+1)*a[m],dis+=(ne/d+1)*d;
		m=k;
	}
	cout<<ans;
	return 0;
}
