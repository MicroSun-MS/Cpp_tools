#include<bits/stdc++.h>
using namespace std;
long long n,a,b,c,d,t,m,k=1,pf[1000100],gys,fz,fm,gy,zz,mm;
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	for(int i=0;i<=1000;i++) pf[i*i]=1;
	cin>>t>>m;
	for(int i=1;i<=t;i++)
	{
		k=1;
		cin>>a>>b>>c;
		d=b*b-4*a*c;
		if(d<0)
		{
			cout<<"NO\n";
			continue;
		}
		if(pf[d]==1)
		{
			fm=2*a;
			fz=sqrt(d)-b;
			gys=__gcd(fz,fm);
			fz/=gys;
			fm/=gys;
			if(fm<0) fm*=-1,fz*=-1;
			if(fm==1)
			{
				cout<<fz<<"\n";
				continue;
			}
			else
			{
				cout<<fz<<"/"<<fm<<"\n";
				continue;
			}
		}
		else
		{
			fz=-b;
			fm=2*a;
			gys=__gcd(fz,fm);
			fz/=gys;
			fm/=gys;
			if(fm<0) fm*=-1,fz*=-1;
			if(fz!=0)
			{
				if(fm==1) cout<<fz;
				else cout<<fz<<"/"<<fm;
			}
			for(int i=2;i*i<=d;i++)
			{
				int j=i*i;
				while(d%j==0)
				{
					d/=j;
					k*=i;
				}
			}
			mm=2*a;
			gy=__gcd(k,mm);
			k/=gy;
			mm/=gy;
			if(k>0) cout<<"+";
			if(k!=1) cout<<k<<"*";
			cout<<"sqrt("<<d<<")";
			if(mm!=1) cout<<"/"<<mm;
			cout<<endl;
		}
	}
	return 0;
}
