#include <bits/stdc++.h>
using namespace std;

int T, M;
int a, b, c;

int gcd(int n, int m)
{
	return n % m == 0 ? m : gcd(m, n % m);
}

int main()
{
	freopen("uqe.in", "r", stdin);
	freopen("uqe.out", "w", stdout);

	scanf("%d%d", &T, &M);
	while (T--)
	{
		scanf("%d%d%d", &a, &b, &c);
		
		if (a < 0)
		{
			a = -a, b = -b, c = -c;
		}

		int de = b * b - 4 * a * c;
		if (de < 0)
		{
			puts("NO");
			continue;
		}
		else if (floor(sqrt(de)) == ceil(sqrt(de)))
		{
			int maxp = -M, maxq = 1;
			{
				int p = -b + sqrt(de), q = 2 * a;
				int d = gcd(p, q);
				p /= d, q /= d;
				if (p / q > maxp / maxq)
				{
					maxp = p, maxq = q;
				}
			}
			{
				int p = -b - sqrt(de), q = 2 * a;
				int d = gcd(p, q);
				p /= d, q /= d;
				if (p / q > maxp / maxq)
				{
					maxp = p, maxq = q;
				}
			}
			if (maxp < 0 && maxq < 0)
			{
				maxp = -maxp, maxq = -maxq;
			}
			if (maxp > 0 && maxq < 0)
			{
				maxp = -maxp, maxq = -maxq;
			}
			if (maxp == 0)
			{
				puts("0");
			}
			else if (maxq == 1)
			{
				printf("%d\n", maxp);
			}
			else
			{
				printf("%d/%d\n", maxp, maxq);
			}
		}
		else
		{
			int p = -b, q = 2 * a;
			int d = gcd(p, q), c = 1, cc = 2 * a;

			for (int i = 2; i * i <= de; i++)
			{
				while (de % (i * i) == 0)
				{
					c *= i;
					de /= i * i;
				}
			}
			p /= d, q /= d;
			d = gcd(c, cc);
			c /= d, cc /= d;


			if (p < 0 && q < 0)
			{
				p = -p, q = -q;
			}
			if (p > 0 && q < 0)
			{
				p = -p, q = -q;
			}
			if (c * cc < 0)
			{
				c = abs(c), cc = abs(cc);
			}
			if (p == 0)
			{
				if (c == 1)
				{
					if (cc == 1)
					{
						printf("sqrt(%d)\n", de);
					}
					else
					{
						printf("sqrt(%d)/%d\n", de, cc);
					}
				}
				else
				{
					if (cc == 1)
					{
						printf("%d*sqrt(%d)\n", c, de);
					}
					else
					{
						printf("%d*sqrt(%d)/%d\n", c, de, cc);
					}
				}
			}
			else if (q == 1)
			{
				printf("%d+", p);
				if (c == 1)
				{
					if (cc == 1)
					{
						printf("sqrt(%d)\n", de);
					}
					else
					{
						printf("sqrt(%d)/%d\n", de, cc);
					}
				}
				else
				{
					if (cc == 1)
					{
						printf("%d*sqrt(%d)\n", c, de);
					}
					else
					{
						printf("%d*sqrt(%d)/%d\n", c, de, cc);
					}
				}
			}
			else
			{
				printf("%d/%d+", p, q);
				if (c == 1)
				{
					if (cc == 1)
					{
						printf("sqrt(%d)\n", de);
					}
					else
					{
						printf("sqrt(%d)/%d\n", de, cc);
					}
				}
				else
				{
					if (cc == 1)
					{
						printf("%d*sqrt(%d)\n", c, de);
					}
					else
					{
						printf("%d*sqrt(%d)/%d\n", c, de, cc);
					}
				}
			}
		}
	}
}
