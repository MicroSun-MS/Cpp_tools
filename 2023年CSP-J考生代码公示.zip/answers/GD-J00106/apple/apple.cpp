#include <bits/stdc++.h>
using namespace std;

const int N = 1e6 + 5;

int n;
bool a[N];

int main()
{
	freopen("apple.in", "r", stdin);
	freopen("apple.out", "w", stdout);
	scanf("%d", &n);

	int ans1 = 0, ans2 = 0;
	bool mark = 1;
	
	while(mark)
	{
		ans1++;
		mark = 0;
		int k = 0;
		for (int i = 1; i <= n; i++)
		{
			if (!a[i])
			{
				k++;
			}
			if (k % 3 == 1 && !a[i])
			{
				mark = 1;
				a[i] = 1;
				if (i == n)
				{
					ans2 = ans1;
				}
			}
		}
	}

	printf("%d %d\n", ans1 - 1, ans2);
	return 0;
}
