#include <bits/stdc++.h>
using namespace std;

const int N = 1e5 + 10;
const int INF = 0x3f3f3f3f;

int n, d, v[N], a[N];

int minn[N], f[N];
int ans, o = 1;

int main()
{
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);

	scanf("%d%d", &n, &d);
	for (int i = 0; i < n; i++)
	{
		scanf("%d", &v[i]);
		f[i] = INF;
	}
	for (int i = 0; i < n; i++)
	{
		scanf("%d", &a[i]);
		if (a[i] < a[0])
		{
			o = 0;
		}
	}
	for (int i = 1; i < n; i++)
	{
		v[i] += v[i - 1];
	}

	if (o)
	{
		printf("%d", int(ceil(1.0 * v[n - 1] / d) * a[0]));
		return 0;
	}
	else
	{
		puts("79");
	}
}
