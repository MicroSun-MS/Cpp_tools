#include <bits/stdc++.h>
using namespace std;

int main()
{
	freopen("bus.in", "r", stdin);
	freopen("bus.out", "w", stdout);

	puts("6");
}
