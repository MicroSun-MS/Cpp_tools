#include<bits/stdc++.h>
using namespace std;

int main() {
	int n;
	cin >> n;
	int l;
	int cnt = 0;
	int ans;
	bool flat = false;
	while (n > 0) {
		if ((n-1) % 3 == 0 && !flat) {
			ans = cnt + 1;
			flat = true;
		}
		l = (n-1)/3 + 1;
		n -= l;
		cnt ++;
	}
	cout << cnt << " " << ans;
	return 0;
}
