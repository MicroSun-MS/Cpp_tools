#include<bits/stdc++.h>
using namespace std;

int main(){
	int T,m;
	cin>>T>>m;
	for (int i=0;i<T;i++) {
		int a,b,c;
		cin >> a >> b >> c;
		if (a == 0) {
			cout << "NO" << endl;
		}else {
			cout << 0 << endl;
		}
	}
}
