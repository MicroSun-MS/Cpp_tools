#include<bits/stdc++.h>
using namespace std;

int n,d;
int sum[15];
int v[15];
int a[15];
int ans[15];
bool is(int a,int d) {
	if (a % d == 0) {
		return true;
	}else{
		return false;
	}
}

int minn = INT_MAX;

int dfs(int s, int n, int pr) {
	if (s == n) {
		return pr;
	}
	memset (ans,0,sizeof (ans));
	for (int i = s+1; i<= n; i++) {
		if (is(sum[i]-sum[s],d)) {
			ans[i] = dfs(i,n,pr + (sum[i]-sum[s])/d*a[s]);	
		}else {
			ans[i] = dfs(i,n,pr + ((sum[i]-sum[s])/d+1)*a[s]);
		}
	}
	sort(ans,ans+n);
	for (int i=0;i<15;i++) {
		if (ans[i]!=0) return ans[i];
	}
}

int main() {
	memset(sum,0,sizeof(sum));

	cin >> n >> d;
	
	for (int i=1;i<= n-1;i++) {
		cin >> v[i];
		sum[i+1] += sum[i] + v[i];
	}

	if (n > 100000) {
		if (is(sum[n],d)){
			cout << sum[n]/d*a[1];
		}else{
			cout << (sum[n]/d+1)*a[1];
		}
		return 0;
	}
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	cout << dfs(1,n,0);
	return 0;
}
