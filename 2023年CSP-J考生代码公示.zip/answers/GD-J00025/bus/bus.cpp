#include<bits/stdc++.h>
using namespace std;


int main() {
	int m,n,k;
	cin >> n >> m >> k;
	for (int i = 0; i < m; i++) {
		int u,v;
		cin >> u >> v;
    }
	cout << n/2+k;
}
