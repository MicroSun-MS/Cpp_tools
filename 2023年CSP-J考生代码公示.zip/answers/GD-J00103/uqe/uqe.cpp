#include<bits/stdc++.h>
using namespace std;
long long n,m,a[5005],b[5005],c[5005],x,y,z,q1,q2,q3,q4,g,g2;
int f(int k,int l)
{
	if(k<l)swap(k,l);
	if(k%l==0)return l;
	k%=l;
}
int j(int m)
{
	for(int i=sqrt(m);i>=2;i--)
	if(m%(i*i)==0)return i;
}
int main(){freopen("uqe.in","r",stdin);
	       freopen("uqe.out","w",stdout);
	       cin>>n>>m;
	       for(int i=1;i<=n;i++)
	       {
	       	   cin>>a[i]>>b[i]>>c[i];
	       	   x=0,y=0,z=0,g=0;
	       	   q1=0,q2=0,q3=0,q4=0; 
			   if(b[i]*b[i]-4*a[i]*c[i]<0)
	       	   {
	       	   	  cout<<"NO"<<"\n";
	       	   	  continue;
			   }
			   if(b[i]!=0)
			   {
			   	  g=f(abs(2*a[i]),abs(b[i]));
	       	      q1=-b[i]/g;
	       	      q2=2*a[i]/g;
	       	      if(q2<0)q1*=-1,q2*=-1;
	       	      y=sqrt(b[i]*b[i]-4*a[i]*c[i]);
	       	      if(y*y!=b[i]*b[i]-4*a[i]*c[i])
	       	      {
	       	   	     y=b[i]*b[i]-4*a[i]*c[i];
	       	   	     q3=j(y);
	       	   	     y/=(q3*q3);
	       	   	     g2=f(q3,abs(2*a[i]));
	       	   	     q3/=g2;
	       	   	     q4=2*a[i]/g2;
	       	   	     if(q4<0)q3*=-1,q4*=-1;
	       	   	     if(q2==1||q2==-1)cout<<q1/q2<<"+";
	       	   	     else cout<<q1<<"/"<<q2<<"+";
	       	   	     if(q3==q4||q3==-q4)cout<<"sqrt("<<y<<")";
	       	   	     else
	       	   	     {
	       	   	  	    if(q3%q4==0&&q3>0)cout<<q3/q4<<"*"<<"sqrt("<<y<<")";
	       	   	  	    else if(q3%q4==0&&q3<0)cout<<-q3/q4<<"*"<<"sqrt("<<y<<")";
	       	   	  	    if(q3<q4&&q3==1)cout<<"sqrt("<<y<<")/"<<q4;
	       	   	  	    if(q3%q4!=0&&q3!=1)cout<<q3<<"*sqrt("<<y<<")/"<<q4;
				     }
				     cout<<"\n";
			      }
			      else
			      {
			   	     q1=-b[i]+y;
			   	     q2=2*a[i];
			   	     g=f(abs(q1),abs(q2));
			   	     q1/=g;
			   	     q2/=g;
			   	     if(q2<0)q1*=-1,q2*=-1;
			   	     if(q2==1)cout<<q1/q2;
			   	     else cout<<q1<<"/"<<q2;
			   	     cout<<"\n";
			      }
			   }
	       	   else
	       	   {
	       	      q1=-b[i];
	       	      q2=2*a[i];
	       	      if(q2<0)q1*=-1,q2*=-1;
	       	      y=sqrt(b[i]*b[i]-4*a[i]*c[i]);
	       	      if(y*y!=b[i]*b[i]-4*a[i]*c[i])
	       	      {
	       	   	     y=b[i]*b[i]-4*a[i]*c[i];
	       	   	     q3=j(y);
	       	   	     y/=(q3*q3);
	       	   	     g2=f(q3,abs(2*a[i]));
	       	   	     q3/=g2;
	       	   	     q4=2*a[i]/g2;
	       	   	     if(q4<0)q3*=-1,q4*=-1;
	       	   	     if(q3/q4==1)cout<<"sqrt("<<y<<")";
	       	   	     else
	       	   	     {
	       	   	  	    if(q3>q4&&q3%q4==0)cout<<q3/q4<<"*"<<"sqrt("<<y<<")";
	       	   	  	    if(q3<q4&&q3==1)cout<<"sqrt("<<y<<")/"<<q4;
	       	   	  	    if(q3%q4!=0&&q3!=1)cout<<q3<<"*sqrt("<<y<<")/"<<q4;
				     }
				     cout<<"\n";
			      }
			      else
			      {
			   	     q1=-b[i]+y;
			   	     q2=2*a[i];
			   	     if(q1==0)
			   	     {
			   	     	cout<<0;
			   	     	continue;
				     }
			   	     g=f(abs(q1),abs(q2));
			   	     q1/=g;
			   	     q2/=g;
			   	     if(q2<0)q1*=-1,q2*=-1;
			   	     if(q2==1)cout<<q1/q2;
			   	     else cout<<q1<<"/"<<q2;
			   	     cout<<"\n";
			      }
			   }
		   }
	return 0;
} 
