#include<bits/stdc++.h>
using namespace std;
long long n,x,s;
int j(int m)
{
    if(m%3==1)return 1; 
	if(m>3)return j(m-(m-1)/3-1)+1;
	if(m==3)return 3;
	if(m==2)return 2;
	
}
int main(){freopen("apple.in","r",stdin);
	       freopen("apple.out","w",stdout);
	       cin>>n;
	       x=n;
	       while(x>3)
	       {
	       	   s++;
	       	   x=x-(x-1)/3-1;
		   }
		   s+=x;
		   cout<<s<<" ";
		   if(n%3==1)
		   {
		   	  cout<<1;
		   	  return 0;
		   }
		   cout<<j(n);
	return 0;
} 
