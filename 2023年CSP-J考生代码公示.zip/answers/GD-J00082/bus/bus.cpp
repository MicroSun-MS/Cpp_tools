#include <bits/stdc++.h>
using namespace std;
struct node{
	int v;
	int t;
};
vector<vector<node> > a;
int n,m,k,ans = 2e7,nowans;
bool vis[10005],flag;
void dfs(int nowx,int time){
	if(nowx == n && (time % k) == 0){
		flag = true;
		ans = min(ans,time);
		return;
	}
	for(int i=0;i<a[nowx].size();i++){
		int newx = a[nowx][i].v;
		int opent = a[nowx][i].t;
		if(!vis[newx] && time >= opent){
			vis[newx] = true; 
			dfs(newx,time + 1);
			if(flag) return;
			vis[newx] = false;
		}
	}
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cin>>n>>m>>k;
	a.resize(n + 5);
	bool all0 = true;
	for(int i=0;i<m;i++){
		int u,v,x;
		cin>>u>>v>>x;
		if(x) all0 = false;
		a[u].push_back((node){v,x});
	}
	int l = 0,r = 1e6;
	if(all0){
		r = 1;
	}
	while(l < r){ 
		nowans = 2e7; 
		int mid = (l + r) >> 1;
//		cout<<mid<<endl;
		memset(vis,false,sizeof(vis));
		flag = false;
		dfs(1,mid * k);
		if(flag){
			r = mid;
		}else{
			l = mid + 1;
		}
	}
	if(ans == 2e7) cout<<-1;
	else cout<<ans;
	return 0;
}
/*
5 5 3
 1 2 0
 2 5 1
 1 3 0
 3 4 3 
 4 5 1
*/
