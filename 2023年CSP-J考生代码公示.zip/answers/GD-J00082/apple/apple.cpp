#include <bits/stdc++.h>
using namespace std;
vector<int> a;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n,cnt = 0,ans = 0;
	cin>>n;
	while(n%3 != 1){
//		cout<<n<<endl;
		cnt++;
		n-=(n-1)/3 + 1;
	}
	ans = cnt + 1;
	while(n){
		cnt++;
		n-=(n-1)/3 + 1;
	}
	cout<<cnt<<' '<<ans;
/*	a.push_back(0);
	for(int i=1;i<=n;i++){
		a.push_back(i);
	}
	
	while(a.size() > 1){
		cnt++;
		for(int i=1;i<=n;i+=3){
			if(a.size() <= 1 || i >= a.size()) break;
			if(a[i] == n) ans = cnt;
			a[i] = 0;
		}
		for(int i=1;i<a.size();i++){
			if(!a[i]){
				a.erase(a.begin() + i);
				i--;
			}
		}
	}
	cout<<cnt<<' '<<ans;*/
//	fclose(stdin);
//	fclose(stdout);
	return 0;
}
