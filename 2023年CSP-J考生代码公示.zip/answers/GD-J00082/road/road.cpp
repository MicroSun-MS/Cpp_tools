#include <bits/stdc++.h>
using namespace std;
const int N = 100020;
int v[N];
vector<pair<int,int> > a;
bool cmp(pair<int,int> a,pair<int,int> b){
	if(a.second != b.second) return a.second < b.second;
	else return  a.first < b.first;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n,d;
	int ans = 0;
	int nowdis = 0,nowmini = 1;
	cin>>n>>d;
	a.push_back({0,0});
	for(int i=1;i<=n-1;i++){
		int x;
		cin>>x;
		v[i] = v[i - 1] + x;
	}
	for(int i=1;i<=n;i++){
		int x;
		cin>>x;
		a.push_back({i,x});
	}
	int nowt = 1,nextt = 2;
	while(nowt < n){
		while(a[nextt].second >= a[nowt].second && nextt < n) nextt++;
		int dis = v[nextt - 1] - v[nowt - 1];
		ans += ((dis - nowdis) / d) * a[nowt].second;
		nowdis += ((dis - nowdis) / d) * d;
//		cout<<nowdis<<endl;
		if((dis - nowdis) % d != 0){
			ans += a[nowt].second;
			nowdis += d;
		}
		nowdis -= dis;
		nowt = nextt;
	}
	cout<<ans;
//	fclose(stdin);
//	fclose(stdout);
	return 0;
}
/*
5 4
10 10 10 10
9 8 9 6 5

*/
