#include <bits/stdc++.h>
using namespace std;
int n,sum,d,a;	
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin >> n >> d;
	for(int i = 1;i <= n - 1;i++){
		int v;
		cin >> v;
		sum += v;
	}
	cin >> a;
	cout << (sum / d) * a;
	return 0;
}


