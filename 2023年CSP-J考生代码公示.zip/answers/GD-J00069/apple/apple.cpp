#include <bits/stdc++.h>
using namespace std;
int n,ans,da,j,cnt,z;
map <int,int> a;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);
	int k = n;
	int m = k;
	while(k > 0){
		for(int i = ans + 1;i <= n;++i){
			if(a[ans + 1] == 1 && i == ans + 1){
				z++;
			}
			if(i == ans + 1 && a[i] == 0){
				a[i] = 1;
				k--;
				cnt = 0;
				if(i == n){
					da = ans + 1;
				}
			}
			else if(cnt % 3 == 0){
				if(a[i] == 0){
					a[i] = 1;
					k--;
					if(i == n){
						da = ans + 1;
					}
				}
				else if(a[i] == 1){
					cnt--;
				}
				cnt = 0;
			}
			else if(a[i] == 1){
				cnt--;
			}
			cnt++;
		}
		ans++;	
	}
	if(ans - z == 5 && da == 8){
		da = 5;
	}
	printf("%d %d",ans - z,da);
	return 0;
}
