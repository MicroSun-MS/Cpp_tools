#include <iostream>

using namespace std;

int n,rd,dy;

int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);
	while (n){
		rd++;
		if (!dy&&n%3==1) dy=rd;
		n-=(n+2)/3;
	}
	printf("%d %d\n",rd,dy);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
