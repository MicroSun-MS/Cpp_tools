#include <iostream>
#include <cmath>
#include <algorithm>

#define int long long

using namespace std;

const int N=1e4;

int t,m,a,b,c;
int primes[N];
bool st[N];

inline void init(){
	for (int i=2;i<=3*m;i++){
		if (!st[i]) primes[++primes[0]]=i;
		for (int j=1;i*primes[j]<=3*m;j++){
			st[i*primes[j]]=1;
			if (i%primes[j]==0) break;
		}
	}
}

inline void oput(int p,int q){
	if (q<0) q=-q,p=-p;
	int gcd=__gcd(abs(p),abs(q));
	p/=gcd,q/=gcd;
	if (q==1) return (void)printf("%lld",p);
	printf("%lld/%lld",p,q);
}

signed main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%lld%lld",&t,&m);
	init();
	while (t--){
		scanf("%lld%lld%lld",&a,&b,&c);
		int d=b*b-4*a*c;
		if (d<0){
			printf("NO\n");
			continue;
		}
		int rsq=round(sqrt(d));
		if (rsq*rsq==d){
			oput(-b+(a<0?-rsq:rsq),2*a),printf("\n");
			continue;
		}
		if (b) oput(-b,2*a),printf("+");
		if (a<0) a=-a;
		int tcl=1;
		for (int i=1;i<=primes[0];i++)
			while (d%(primes[i]*primes[i])==0) tcl*=primes[i],d/=primes[i]*primes[i];
		if (tcl==2*a){
			printf("sqrt(%lld)\n",d);
			continue;
		}
		if (tcl%(2*a)==0){
			printf("%lld*sqrt(%lld)\n",tcl/2/a,d);
			continue;
		}
		if ((2*a)%tcl==0){
			printf("sqrt(%lld)/%lld\n",d,2*a/tcl);
			continue;
		}
		int p=tcl,q=2*a,gcd=__gcd(p,q);
		p/=gcd,q/=gcd;
		printf("%lld*sqrt(%lld)/%lld\n",p,d,q);
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
