#include <iostream>
#include <vector>
#include <ext/pb_ds/priority_queue.hpp>
#include <cstring>

using namespace std;

typedef pair<int,int> PII;

const int N=1e6+10;

int n,m,k;
vector<PII> e[N];
int dis[N];
__gnu_pbds::priority_queue<PII,greater<PII>> q;
__gnu_pbds::priority_queue<PII,greater<PII>>::point_iterator p[N];

inline int gidx(int i,int j){
	return j*n+i;
}

inline void dijkstra(){
	memset(dis,0x3f,sizeof dis),dis[1]=0;
	for (int i=1;i<=n*k;i++) p[i]=q.push({dis[i],i});
	while (q.size()){
		int u=q.top().second;
		q.pop();
		for (auto i:e[u]){
			int j=i.first,a=max(0,(i.second-dis[u]+k-1)/k);
			if (dis[j]>dis[u]+a*k+1)
				dis[j]=dis[u]+a*k+1,q.modify(p[j],{dis[j],j});
		}
	}
}

int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout); 
	scanf("%d%d%d",&n,&m,&k);
	while (m--){
		int u,v,a;
		scanf("%d%d%d",&u,&v,&a);
		for (int i=0;i<k;i++) e[gidx(u,i)].emplace_back(gidx(v,(i+1)%k),a);
	}
	dijkstra();
	printf("%d\n",dis[n]==0x3f3f3f3f?-1:dis[n]);
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
