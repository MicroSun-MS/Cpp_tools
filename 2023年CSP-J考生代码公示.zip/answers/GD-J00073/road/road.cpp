#include <iostream>
#include <stack>

#define int long long

using namespace std;

const int N=1e5+10;

int n,d,ans;
int v[N],a[N],np[N];
stack<int> stk;

signed main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld%lld",&n,&d);
	for (int i=2;i<=n;i++) scanf("%lld",v+i),v[i]+=v[i-1];
	for (int i=1;i<=n;i++) scanf("%lld",a+i);
	stk.push(n+1);
	for (int i=n;i>=1;i--){
		while (stk.size()>1&&a[stk.top()]>=a[i]) stk.pop();
		np[i]=stk.top(),stk.push(i);
	}
	v[n+1]=v[n];
	for (int i=1,lst=0;i<=n;lst-=v[np[i]]-v[i],i=np[i]){
		int cnt=max(0ll,(v[np[i]]-v[i]-lst+d-1)/d);
		ans+=a[i]*cnt,lst+=d*cnt;
	}
	printf("%lld\n",ans);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
