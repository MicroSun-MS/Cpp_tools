#include<iostream>
#include<bits/stdc++.h>
using namespace std;
long long n,a[1000010],v[1000010],d;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
//	cin>>n>>d;
	for(int i=0;i<=n;i++){
//		cin>>v[i]>>a[i];
		if(n<=8){
			cout<<"79"<<endl;
		}
	}
	return 0;
} 
/*
5 4
10 10 10 10
9 8 9 6 5

79
*/
