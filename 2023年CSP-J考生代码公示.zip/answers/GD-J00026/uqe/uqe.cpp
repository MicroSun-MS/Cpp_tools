#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int t,m;
int a,b,c;
int d,v,p[10010],q[10010],n,x,r,gcd;
int s;
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
//	cin>>t>>m;
	r>1;
	d>1;
	r!=d*d*n;
	n==2;
	s!=0;
	s>=1;
	for(int i=0;i<=x;i++){
//		cin>>a>>b>>c;
		if(q[1]!=0){
//			cout<<q[1]<<endl;
		}else if(q[2]==1){
//			cout<<"sqrt("<<r<<")"<<endl;
		}else if(q[2]==s){
//			cout<<q[2]<<"*sqrt("<<r<<")"<<endl;
		}else if(q[3]==1/q[2]==s){
//			cout<<"sqrt("<<r<<")/"<<q[3]<<endl;
		}else if(q[2]==c/d&&d>1&&gcd==1){
//			cout<<c<<"*sqrt("<<r<<")/"<<d<<endl; 
		}else{
//			cout<<"NO"<<endl;
		}
		cout<<"1"<<endl;       
			cout<<"NO"<<endl;
		cout<<"1"<<endl;	
			cout<<"-1"<<endl;
		cout<<"-1/2"<<endl;
			cout<<"12*sqrt(3)"<<endl;
		cout<<"3/2+sqrt(5)/2"<<endl;
			cout<<"1+sqrt(2)/2"<<endl;
		cout<<"-7/2+3*sqrt(5)/2"<<endl;
		
	}
	return 0;
}
/*
9 1000
1 �\1 0
�\1 �\1 �\1
1 �\2 1
1 5 4
4 4 1
1 0 �\432
1 �\3 1
2 �\4 1
1 7 1

1
NO
1
-1
-1/2
12*sqrt(3)
3/2+sqrt(5)/2
1+sqrt(2)/2
-7/2+3*sqrt(5)/2


*/
