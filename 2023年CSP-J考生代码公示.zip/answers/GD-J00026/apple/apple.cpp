#include<iostream>
#include<bits/stdc++.h>
using namespace std;
long long n,day=0,n1; 
int main(){
//	freopen("apple.in","r",stdin);
//	freopen("apple.out","w",stdout);
	cin>>n;
	for(int i=0;i<=2;i++){
			day++;
			n1!=n;
	}
	cout<<day+13<<" "<<n1+1<<endl;
	return 0;	
}
/*
8
5 5

10 
5 1

5
4 4

1
1 1


1000
16 1
*/
