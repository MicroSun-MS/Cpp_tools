#include<bits/stdc++.h>
#define _rep(i,a,b) for(int i=(a);i<=(b);++i)
#define _antirep(i,a,b) for(int i=(a);i>=(b);--i)
using namespace std;
typedef long long LL;
const int N=1e4+5;
int n,m,k,ans=INT_MAX; 
bool vis[1000000000];
struct edge
{
	int to,w,nxt;
}e[N<<1];
struct node
{
	int p,ti,Max; 
};
int cnt,head[N];
void add(int u,int v,int w)
{
	cnt++;
	e[cnt].to=v;
	e[cnt].w=w;
	e[cnt].nxt=head[u];
	head[u]=cnt;
}
LL ha(int a,int b,int c)
{
	return a*3+b*5+c*7;
}
void bfs(int s)
{ 
	queue<node>q;  
	q.push((node){s,0,0}); 
	while(!q.empty())
	{
		node fr=q.front();q.pop();  
		if(vis[ha(fr.p,fr.ti,fr.Max)]) continue;
		vis[ha(fr.p,fr.ti,fr.Max)]=1;
		if(fr.p==n&&fr.ti%k==0)
		{
			ans=min(ans,fr.Max%k?(k-(fr.Max%k))+fr.ti+fr.Max:fr.ti+fr.Max);
			continue;
		}
		for(int i=head[fr.p];i;i=e[i].nxt)
		{
			int v=e[i].to;
			q.push((node){v,fr.ti+1,max(fr.Max,e[i].w)}); 
		}
	}
	return;
}
int main()
{ 
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout); 
	scanf("%d%d%d",&n,&m,&k);
	_rep(i,1,m)
	{
		int u,v,w;
		scanf("%d%d%d",&u,&v,&w);
		add(u,v,w);
	}
	bfs(1);
	if(ans==INT_MAX) printf("-1");
	else printf("%d",ans);
	return 0;
}

