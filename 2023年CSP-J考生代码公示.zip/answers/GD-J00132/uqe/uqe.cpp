#include<bits/stdc++.h>
#define _rep(i,a,b) for(int i=(a);i<=(b);++i)
#define _antirep(i,a,b) for(int i=(a);i>=(b);--i)
using namespace std;
typedef long long LL;
typedef double db;
const int N=1e5+5;
int a,b,c,T,m;
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&T,&m);
	while(T--)
	{
		scanf("%d%d%d",&a,&b,&c);
		if(b*b<4*a*c) printf("NO\n");
		else if(b==0||c==0) 
		{ 
			if(c==0) c=b;
			bool ok=false;
			int ans=0;
			_rep(i,1,m)
			{
				if(i*i>(-c)/a) break;
				if(i*i<(-c)/a&&(-c)/a%(i*i)==0) ans=i;
				if(i*i==(-c)/a)
				{
					printf("%d\n",i);
					ok=true;
					break;
				}
			}
			if(!ok) printf("%d*sqrt(%d)\n",ans,(-c)/a/(ans*ans));
		}
		else
		{
			int ans=-1001;
			_rep(i,-m,m) 
				if(a*i*i+b*i+c==0) ans=i;
			if(ans!=-1001) printf("%d\n",ans); 
		}
	} 
	return 0;
}

