#include<bits/stdc++.h>
#define _rep(i,a,b) for(int i=(a);i<=(b);++i)
#define _antirep(i,a,b) for(int i=(a);i>=(b);--i)
using namespace std;
typedef long long LL;
const int N=1e5+5;
int n,d,a[N],v[N];
LL ans; 
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&d);
	_rep(i,2,n) scanf("%d",&v[i]);
	_rep(i,2,n) v[i]+=v[i-1];
	_rep(i,1,n) scanf("%d",&a[i]);
	int i=1,j=1,lsts=0; 
	while(i<n)
	{
		while(a[i]<=a[j]&&j<n) j++;
		int sheng;
		if((v[j]-v[i]-lsts)%d==0) sheng=(v[j]-v[i]-lsts)/d,lsts=0;
		else sheng=(v[j]-v[i]-lsts)/d+1,lsts=d*sheng-(v[j]-v[i]-lsts); 
		ans+=sheng*a[i];
		i=j;
	}
	printf("%lld",ans); 
	return 0;
}

