#include<set>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

void FileIO(string fileName){
    freopen((fileName+".in").c_str(),"r",stdin);
    freopen((fileName+".out").c_str(),"w",stdout);
}

signed main(){
    FileIO("bus");
    printf("-1");
    // AUUUUUUUUUUUUUUUUUUGH
}