#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

#define   int   long long

bool flag;
int n,timesss,takeNApple;

void FileIO(string fileName){
    freopen((fileName+".in").c_str(),"r",stdin);
    freopen((fileName+".out").c_str(),"w",stdout);
}

signed main(){
    FileIO("apple");
    scanf("%lld",&n);
    while(n!=0){
        timesss++;
        if(n%3==1 && flag==false){
            flag=true;
            takeNApple=timesss;
        }
        n-=n/3+(n%3!=0);
    }
    printf("%lld %lld",timesss,takeNApple);
}