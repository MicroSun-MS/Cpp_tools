#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

#define      int   long long
// #define   fenshu   pair<long long,long long>

bool vAyaya[5000010];
int T,M,numAyaya,ayaya[10010];
double a,b,c,specialNum,normalAns1,normalAns2;

void FileIO(string fileName){
    freopen((fileName+".in").c_str(),"r",stdin);
    freopen((fileName+".out").c_str(),"w",stdout);
}

void init(){
    for(int i=1;i*i<=5000000;i++){
        ayaya[++numAyaya]=i*i;
        vAyaya[i*i]=true;
    }
    vAyaya[0]=true;
}

signed main(){
    FileIO("uqe");
    init();
    scanf("%lld%lld",&T,&M);
    while(T--){
        scanf("%lf%lf%lf",&a,&b,&c);
        specialNum=b*b-4*a*c;
        if(specialNum<0){
            printf("NO\n");
            continue;
        }
        if(a<0){
            a*=-1;
            b*=-1;
        }
        if(vAyaya[(int)specialNum]){
            int numA=-1*b+sqrt(specialNum);
            int numB=2*a;
            int uae=__gcd(numA,numB);
            numA/=uae;
            numB/=uae;
            if(numB<0){
                numA*=-1;
                numB*=-1;
            }
            if(numB==1) printf("%lld\n",numA);
            else printf("%lld/%lld\n",numA,numB);
            continue;
        }
        else{
            double normalQ1=(-1*b)/(2*a);
            if(normalQ1!=0){
                int numA=-1*b;
                int numB=2*a;
                int uae=__gcd(numA,numB);
                numA/=uae;
                numB/=uae;
                if(numB<0){
                    numA*=-1;
                    numB*=-1;
                }
                if(numB==1) printf("%lld+",numA);
                else printf("%lld/%lld+",numA,numB);
            }
            int normalQ2=1;
            for(int i=numAyaya;i>=2;i--){
                if((int)specialNum%ayaya[i]==0){
                    normalQ2=sqrt(ayaya[i]);
                    break;
                }
            }
            if(normalQ2%(int)(2*a)==0){
                if(normalQ2/(int)(2*a)==1) printf("sqrt(%lld)\n",(int)specialNum/normalQ2/normalQ2);
                else printf("%lld*sqrt(%lld)\n",normalQ2/(int)(2*a),(int)specialNum/normalQ2/normalQ2);
                continue;
            }
            else if((int)(2*a)%normalQ2==0){
                int numA=(int)(2*a);
                int numB=normalQ2;
                int uae=__gcd(numA,numB);
                if(numB<0){
                    numA*=-1;
                    numB*=-1;
                }
                printf("sqrt(%lld)/%lld\n",(int)specialNum/normalQ2/normalQ2,numA/uae);
                // uae bless me
                continue;
            }
            else{
                int numA=normalQ2;
                int numB=(int)2*a;
                int uae=__gcd(numA,numB);
                numA/=uae,numB/=uae;
                if(numB<0){
                    numA*=-1;
                    numB*=-1;
                }
                printf("%lld*sqrt(%lld)/%lld\n",numA,(int)specialNum/normalQ2/normalQ2,numB);
                continue;
            }
        }
    }
}