#include<set>
#include<cmath>
#include<cstdio>
#include<cstring>
#include<iostream>
#include<algorithm>
using namespace std;

#define   int   long long

const int MAXN = 100010;

multiset<pair<int,int> > qwq; // price id
double america;
bool vv[MAXN];
int n,d,totTOWARD,dollar,v[MAXN],a[MAXN],sum[MAXN],toward[MAXN];

void FileIO(string fileName){
    freopen((fileName+".in").c_str(),"r",stdin);
    freopen((fileName+".out").c_str(),"w",stdout);
}

signed main(){
    FileIO("road");
    scanf("%lld%lld",&n,&d);
    for(int i=1;i<n;i++){
        scanf("%lld",&v[i]);
        sum[i]=sum[i-1]+v[i];
    }
    for(int i=1;i<=n;i++){
        scanf("%lld",&a[i]);
        if(i!=n && vv[a[i]]==false){
            qwq.insert(make_pair(a[i],i));
            vv[a[i]]=true;
        }
    }
    int lastChoose=MAXN+10;
    pair<int,int> xQc=*(qwq.begin());
    while(xQc.second<lastChoose){
        toward[++totTOWARD]=xQc.second;
        lastChoose=xQc.second;
        qwq.erase(xQc);
        xQc=*(qwq.begin());
    }
    if(toward[totTOWARD]!=1){
        int howFar=sum[toward[totTOWARD]-1];
        dollar+=(howFar/d)*a[1];
        if(howFar%d!=0){
            dollar+=a[1];
            america=(d*1.0-(howFar%d)*1.0)/d*1.0;
        }
    }
    for(int i=totTOWARD;i>=1;i--){
        if(i!=1){
            int howFar=sum[toward[i-1]-1]-sum[toward[i]-1];
            if(america*(d*1.0)<howFar*1.0) {
                dollar+=(int)((int)(howFar*1.0-america*(d*1.0))/d)*a[toward[i]];
                if(((howFar-america*(d*1.0))-(int)(howFar-america*(d*1.0))/d*d)!=0){
                    dollar+=a[toward[i]];
                    america=((howFar-america*(d*1.0))-(int)(howFar-america*(d*1.0))/d*d)*1.0/d*1.0;
                }
            }
            else{
                america-=howFar*1.0/d*1.0;
            }
        }
    }
    if(toward[1]!=n){
        int howFar=sum[n-1]-sum[toward[1]-1];
            if(america*(d*1.0)<howFar) {
                dollar+=(int)((int)(howFar*1.0-america*(d*1.0))/d)*a[toward[1]];
                if(((howFar-america*(d*1.0))-(int)(howFar-america*(d*1.0))/d*d)!=0){
                    dollar+=a[toward[1]];
                }
            }
    }
    printf("%lld",dollar);
}