#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,f,cnt=1,vis;
int ans1,ans2;
signed main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	while(n){
		int m=0;
		f=1;
		while(f<=n){
			f+=3;
			m++;
		}
		ans1++;
		if((n-1)%3==0&&!vis){
			ans2=ans1;
			vis=1;
		}
		if(n&&!m)n--;
		else n-=m;
		if(m==0) break;
	}
	cout<<ans1<<" "<<ans2;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
