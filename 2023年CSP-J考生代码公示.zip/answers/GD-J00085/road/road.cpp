#include<bits/stdc++.h>
#define int long long
using namespace std;
struct node{
	int p,w;
}a[100005];
int w[100005],mxw,mnp;
int n,d,mn=0x7f7f7f7f;
void dfs(int x,int pri,int dis){
	if(pri>=mn) return;
	if(x==n){
		mn=min(mn,pri);
		return;
	}
	if(dis>=mxw) dfs(x+1,pri,dis);
	else if(mnp==a[x].p){
		printf("%lld",pri+(mxw-dis)/d*a[x].p);
		exit(0);
	}
	else{
		for(int i=0;i*d+dis<=mxw;i++){
			if(dis+i*d<a[x].w) continue;
			dfs(x+1,pri+i*a[x].p,dis+i*d-a[x].w);
		}
	}
	return;
}
signed main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld%lld",&n,&d);
	for(int i=1;i<n;i++){
		scanf("%lld",&w[i]);
		mxw+=w[i];
		a[i].w=w[i];
	}
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i].p);
		mnp=min(mnp,a[i].p);
	}
	dfs(1,0,0);
	printf("%lld",mn);
	fclose(stdin);
	fclose(stdout);
	return 0;
}
/*
5 4
10 10 10 10
9 8 9 6 5
*/
