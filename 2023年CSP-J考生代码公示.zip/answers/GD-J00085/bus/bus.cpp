#include<bits/stdc++.h>
#define int long long
using namespace std;
//int n,m,k;
//struct edge{
//	int next,to,w;
//}a[20004];
//int cnt,head[10004];
//void add(int u,int v,int w){
//	e[++cnt].to=v;
//	e[cnt].w=w;
//	e[cnt].next=head[u];
//	head[u]=cnt;
//}
signed main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
//	cin>>n>>m>>k;
//	for(int i=1;i<=m;i++){
//		int x,y,t;
//		cin>>x>>y>>t;
//		add(x,y,t);
//	}
	cout<<-1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
