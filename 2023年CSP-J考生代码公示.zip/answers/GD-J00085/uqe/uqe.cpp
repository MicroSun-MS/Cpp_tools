#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m;
signed main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	while(n--){
		int a,b,c;
		scanf("%lld%lld%lld",&a,&b,&c);
		int s=b*b-4*a*c,p;
		//if(s<0) printf("NO\n");
		printf("NO\n");
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
}
