#include<bits/stdc++.h>
using namespace std;
const int size=1e4+5;
int n,m,k,x,y,w;
int dis[size],vis[size];
vector<int> g[size],v[size];
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cout<<-1;

	return 0;
}
