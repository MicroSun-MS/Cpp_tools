#include<bits/stdc++.h>
#define int long long
using namespace std;
const int size=1e5+5;
int n,m,w,ys,ans;
int d[size],f[size],sum[size],p[size];
int r[size];//�ұߵ�һ����p[i]С�������±� 
stack<int> c;
signed main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld%lld",&n,&m);
	for(int i=2;i<=n;i++)
	{
		scanf("%lld",&d[i]);
		sum[i]=sum[i-1]+d[i];
	}
	for(int i=1;i<=n;i++)
		scanf("%lld",&p[i]);
	w=sum[n]/m+(sum[n]%m!=0);
	for(int i=n;i>=1;i--)
	{
		while(!c.empty()&&p[c.top()]>p[i])c.pop();
		r[i]=(c.empty()?n:c.top());
		c.push(i);
	}
//	for(int i=1;i<=n;i++)cout<<r[i]<<' ';
	for(int i=1;i<n;i=r[i])
	{
		int far=sum[r[i]]-sum[i]-ys;
		int num=far/m+(far%m!=0);
		ans+=num*p[i];
		ys=num*m-far;
//		cout<<i<<": "<<far<<" "<<num<<" "<<ys<<" "<<ans<<"\n";
	}
	printf("%lld",ans);
	return 0;
}
/*
	5 4
	10 10 10 10
	9 8 9 6 5
*/
