#include<bits/stdc++.h>
using namespace std;
int n,m,a,b,c,delta,qa,qb,r;
int za,zb,zq,x,mr,d,dza,nag1,nag2;
int gcd(int a,int b){return b?gcd(b,a%b):a;};
void do_q1()
{
	nag1=(a*b>0?1:-1);
	zb=(b<0?-b:b),za=(a<0?-a:a);za*=2;
	if(zb==0)return ;
	if(zb%za==0)qa=zb/za;
	else 
	{
		int g=gcd(za,zb);
		zb/=g; za/=g;
	}
//	cout<<qa<<' '<<za<<" "<<zb<<endl;
}
void do_q2()
{
	nag2=(a*qb<0?1:-1);
	dza=(a<0?-a:a)*2,zq=mr;
	if(zq%dza==0)qb=zq/dza;
	else
	{
		int g=gcd(zq,dza);
		zq/=g; dza/=g;
	}
}
void do_sqrt()
{
	x=delta,mr=1,d=0;
	for(int i=2;i<=sqrt(delta);i++)
	{
		while(x%i==0)x/=i,d++;
		if(d>=2)for(int j=1;j<=d/2;j++)mr*=i;
		d=0;
	}
	r=delta/(mr*mr);
//	cout<<delta<<" "<<mr<<" "<<r<<endl;
}
int add(int a,int b)
{
	int sum=0;
	sum-=a*nag1;sum+=b;
	return sum;
}
void do_cout()
{
	if(delta==0)
	{
		if(nag1==1)printf("-");
		if(qa==0)printf("%d/%d\n",zb,za);
		else printf("%d\n",qa);
		return;
	}
	if(r==1)
	{
//		cout<<qb<<" "<<dza<<" "<<zq<<" "<<za<<' '<<dza<<endl;
		if(qa)za=dza,zb=dza*qa;
		else if(qb)dza=za,zq=za*qb;
		zb=add(zb,zq);
//		cout<<zb<<' '<<za<<endl;
		if(zb%za==0)printf("%d\n",zb/za);
		else 
		{
			int g=gcd(zb,za);
			zb/=g; za/=g;
			printf("%d/%d\n",zb,za);
		}
		return;
	}
	if(nag1==1&&(qa>0||zb>0))printf("-");
	if(qa>0)printf("%d",qa);
	else if(zb>0) printf("%d/%d",zb,za);
	if(r!=0)printf("+");
	else return ;
	if(qb)
	{
		if(qb!=1)printf("%d*sqrt(%d)\n",qb,r);
		else printf("sqrt(%d)\n",r);
	}
	else
	{
		if(zq!=1)printf("%d*sqrt(%d)/%d\n",zq,r,dza);
		else printf("sqrt(%d)/%d\n",r,dza);
	}
}
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int t=1;t<=n;t++)
	{
		scanf("%d%d%d",&a,&b,&c);
		delta=b*b-4*a*c,qa=0,qb=0,r=0;
		if(delta<0){ puts("NO"); continue;}
		do_q1();
		do_sqrt();
		do_q2();
		do_cout();
	}
	return 0;
}
/*
	1 1000
	25 -250 589
*/
