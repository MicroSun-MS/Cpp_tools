#include<bits/stdc++.h>
using namespace std;
const int size=1e6+5;
int n,ans=1,pos,vis[size];
queue<int> q;
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	while(1)
	{
		int flag=0,x=0;
		for(int i=1;i<=n;i++)
		{
			if(vis[i])continue;
			x++;
			if(x==1)
			{
				if(i==n)pos=ans;
				vis[i]=1;
				flag=1;
			}
			if(x==3)x=0;
		}
		if(flag)ans++;
		else break;
	}
	cout<<ans-1<<" "<<pos;

	return 0;
}

