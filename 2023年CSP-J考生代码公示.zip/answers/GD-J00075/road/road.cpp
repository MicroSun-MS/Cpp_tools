#include<bits/stdc++.h>
using namespace std;
int n,a[100005],v[100005],minn,d,ans,z;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>d;
	for(int i=1;i<=n-1;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		cin>>v[i];
	}
	minn=v[1];
	for(int i=1;i<=n-1;i++){
		if(z<a[i]){
			minn=min(minn,v[i]);
			if((a[i]-z)%d==0){
				ans+=(a[i]-z)/d*minn;
				z=a[i];
			}
			else{
				ans+=((a[i]-z)/d+1)*minn;
				z=a[i]+(a[i]-z)%d;
			}
		}
		z-=a[i];
	}
	cout<<ans;
}
