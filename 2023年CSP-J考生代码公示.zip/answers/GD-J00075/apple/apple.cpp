#include<bits/stdc++.h>
using namespace std;
int cnt,n,ans,a,c,flag,b;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>n;
	a=n;
	while(a>3){
		b++;
		if(a%3==1&&flag==0){
			c=b;
			flag=1;
		}
		a=a-(a+2)/3;
	}
	b+=a;
	if(c==0) c=b;
	cout<<b<<' '<<c;
}
//CSP-J2023l!2
