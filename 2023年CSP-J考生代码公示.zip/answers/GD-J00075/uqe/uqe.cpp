#include<bits/stdc++.h>
using namespace std;
int t,m,n,flag;
int bd(int a){
	int ans=1;
	for(int i=2;i<=sqrt(a);i++){
		while(a%(i*i)==0){
			a=a/i/i;
			ans*=i;
		}
	}
	return ans;
}
void js(int a,int b,int c){
	int d,e,f,g,h;
	d=2*a;
	e=b*b-4*a*c;
	f=sqrt(e);
	if(f*f!=e){
		if(b%d!=0&&b!=0){
			flag=1;
			int aaa=__gcd(b,d);
			b/=aaa;
			d/=aaa;
			if(d==1) cout<<-b;
			else if(d<0&&b<0) cout<<b<<'/'<<-d;
			else if(d<0&&b>0) cout<<b<<'/'<<-d;
			else cout<<-b<<'/'<<d;
		}
		else if(b%d==0&&b!=0) cout<<-b/d,flag=1;
		g=bd(e);
		e=e/g/g;
		h=__gcd(d,g);
		d/=h;
		g/=h;
		if(d<0&&g>=0) g=-g,d=-d,cout<<'-';
		else if(g<0&&d<0) g=-g,d=-d,cout<<'-';
		else if(g<0) g=-g,cout<<'-';
		else if(flag==1) cout<<'+',flag=0;
		if(d==1&&abs(g)!=1){
			cout<<g<<"*sqrt("<<e<<")"<<'\n';
		}
		else if(d==1&&abs(g)==1){
			cout<<"sqrt("<<e<<")"<<'\n';
		}
		else if(d!=1&&abs(g)==1){
			cout<<"sqrt("<<e<<")/"<<d<<'\n';
		}
		else cout<<g<<"*sqrt("<<e<<")/"<<d<<'\n';
	}
	else{
		int o,p,q,r,s;
		o=0-b-f;
		p=f-b;
		q=max(o,p);
		if(q%d==0){
			cout<<q/d<<'\n';
		}
		else{
			r=__gcd(abs(q),abs(d));
			q=q/r;
			d=d/r;
			if(q>=0&&d<0) cout<<-q<<'/'<<-d<<'\n';
			else if(q<0&&d<0) cout<<-q<<'/'<<-d<<'\n';
			else cout<<q<<'/'<<d<<'\n';
		}
	}
}
void solve(int a,int b,int c){
	if(b*b-4*a*c<0){
		cout<<"NO\n";
		return;
	}
	js(a,b,c);
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin>>t>>m;
	for(int i=1;i<=t;i++){
		int a,b,c;
		cin>>a>>b>>c;
		solve(a,b,c);
	}
}

