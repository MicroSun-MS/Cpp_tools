#include<stdio.h>
#include<bits/stdc++.h>
using namespace std;
const int N=1000100;
int n,m,k,a,b,c,sum;
int aa[N][4];
struct t{
	int ok,power;
}dp[1010][1010];
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;++i){
		scanf("%d%d%d",&a,&b,&c);
		dp[a][b].power=c;
		dp[a][b].ok=1;
	}
	printf("-1");
	return 0;
}





