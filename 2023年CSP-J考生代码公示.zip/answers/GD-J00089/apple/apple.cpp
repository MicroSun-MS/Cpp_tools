#include<stdio.h>
#include<bits/stdc++.h>
using namespace std;
const int N=100001000;
long long n,m,s,x,day,num;
int a[N];
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%lld",&n);
	while(s<n){
		++day;
		x=0;
		for(int i=1;i<=n;++i){
			if(a[i]==0){
				++x;
			}
			if(x%3==1&&a[i]==0){
				++s;
				a[i]=1;
				if(i==n){
					num=day;
				}
			}
		}
	}
	printf("%lld %lld",day,num);
	return 0;
}






