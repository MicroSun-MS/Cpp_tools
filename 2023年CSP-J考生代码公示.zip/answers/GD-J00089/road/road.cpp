#include<stdio.h>
#include<bits/stdc++.h>
using namespace std;
const int N=100100;
struct t{
	int id,f,p,go;
	double pin;
}a[N];
int n,m,d,w,x=1,yu,num,sum,money;
int xsqz(int a,int b){
	int x=a/b;
	double y=a*1.0/b;
	if(y>x) return x+1;
	else return x; 
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&d);
	for(int i=1;i<=n-1;++i){
		scanf("%d",&a[i].f);
		sum+=a[i].f;
	}
	for(int i=1;i<=n;++i){
		scanf("%d",&a[i].p);
		a[i].id=i;
		if(a[i].f!=0)
			a[i].pin=a[i].f*1.0/a[i].p;
	}
	while(num<=sum){
		for(int i=x;i<=n;++i){
			i=x;
			w=0;
			for(int j=i;j<=n;++j){
				if(a[j].pin>a[i].pin || j==n){
					money+=(xsqz(w-yu,d))*a[i].p;
					yu=(w+yu)%d; 
					num+=w+yu;
					if(num>=sum){
						printf("%d",money);
						return 0;
					}
					x=j;
					break; 
				}
				w+=a[j].f;
			}
			if(num>sum){
				printf("%d",money);
				return 0;
			} 
		}
	}
	printf("%d",money);
	return 0;
}





