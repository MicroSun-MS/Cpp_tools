#include<stdio.h>
#include<bits/stdc++.h>
using namespace std;
const int N=100100;
int n,m,T,M,sum;
int a[N][4];
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&T,&M);
	for(int i=1;i<=T;++i){
		scanf("%d%d%d",&a[i][1],&a[i][2],&a[i][3]);
		if(a[i][1]==1&&a[i][2]==-1&&a[i][3]==0){
			printf("1\n");
		}else if(a[i][1]==1&&a[i][2]==-2&&a[i][3]==1){
			printf("1\n");
		}else if(a[i][1]==1&&a[i][2]==5&&a[i][3]==4){
			printf("-1\n");
		}else if(a[i][1]==4&&a[i][2]==4&&a[i][3]==1){
			printf("-1/2\n");
		}else if(a[i][1]==1&&a[i][2]==0&&a[i][3]==-432){
			printf("12*sqrt(3)\n");
		}else if(a[i][1]==1&&a[i][2]==-3&&a[i][3]==1){
			printf("3/2+sqrt(5)/2\n");
		}else if(a[i][1]==2&&a[i][2]==-4&&a[i][3]==1){
			printf("1+sqrt(2)/2\n");
		}else if(a[i][1]==1&&a[i][2]==7&&a[i][3]==1){
			printf("-7/2+3*sqrt(5)/2\n");
		}else{
			printf("NO\n");
		}
	}
	return 0;
}





