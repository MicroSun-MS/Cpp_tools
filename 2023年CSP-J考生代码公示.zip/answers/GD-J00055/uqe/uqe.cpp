#include <iostream>
#include <algorithm>
#include <cmath> 
using namespace std;
bool sq[1111];
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int t,ma;
	cin >> t >> ma;
	for(int i = 0;i < 33;i++) sq[i*i] = 1;
	while(t--){
		int a,b,c;
		cin >> a >> b >> c;
		if(b * b - 4 * a * c < 0) cout << "NO" << endl;
		else if(c == 0){
			if(a * b >= 0) cout << 0 << endl;
			else{
				if(b < 0) b = -b;
				else a = -a;
				int d = a / __gcd(a,b),e = b / __gcd(a,b);
				if(e == 1) cout << d << endl;
				else cout << d << '/' << e;
			}
		}
		else if(b == 0){
			if(a < 0) a = -a;
			else c = -c;
			if(sq[a] && sq[c]){
				int d = sqrt(a / __gcd(a,c)),e = sqrt(c / __gcd(a,c));
				if(e == 1) cout << d << endl;
				else cout << d << '/' << e;
			}
			else if(sq[a]){
				int d = sqrt(a / __gcd(a,c)),e = c / __gcd(a,c),f = 1;
				for(int i = sqrt(e);i >= 1;i--){
					if(e % (i * i) == 0){
						e /= i * i;
						f *= i * i;
					}
				}
				if(d * f / __gcd(d*f,f*e) != 1) cout << d * f / __gcd(d*f,f*e) << '*';
				cout << "sqrt(" << e << ")/" << f * e / __gcd(d*f,f*e); 
			}
			else if(sq[c]){
				int d = a / __gcd(a,c),e = sqrt(c / __gcd(a,c)),f = 1;
				for(int i = 31;i >= 1;i--){
					if(d % (i * i) == 0){
						d /= i * i;
						f *= i * i;
					}
				}
				cout << f << '*' << "sqrt(" << d << ')';
				if(e != 1) cout << '/' << e;
			}
			else{
				int d = a / __gcd(a,c),e = c / __gcd(a,c),f = 1,g = 1;
				for(int i = 31;i >= 1;i--){
					if(e % (i * i) == 0){
						e /= i * i;
						f *= i * i;
					}
					if(d % (i * i) == 0){
						d /= i * i;
						g *= i * i;
					}
				}
				cout << g / __gcd(g,f*e) << '*' << "sqrt(" << d * e << ")/" << f * e / __gcd(g,f*e);
			}
		}
		else{
			for(int i = ma;i >= -ma;i--){
				if(a * i * i + b * i + c == 0){
					cout << i;
					break;
				}
			}
			cout << endl;
		}
	}
	return 0;
} 
