#include <iostream>
#include <vector>
#include <queue>
using namespace std;
struct A{
	int pl,ti;
};
vector<int> v[11111];
queue<A> q;
int n,m,k,x,y,t,ma;
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin >> n >> m >> k;
	for(int i = 0;i < m;i++){
		cin >> x >> y >> t;
		v[x].push_back(y);
		if(t > ma) ma = t;
	}
	q.push(A{1,0});
	while(!q.empty()){
		x = q.front().pl;
		t = q.front().ti;
		q.pop();
		if(x == n && t % k == 0){
			cout << t + ma / k * k;
			return 0;
		}
		for(int i = 0;i < v[x].size();i++){
			q.push(A{v[x][i],t+1});
		}
	}
	return 0;
} 
