#include <iostream>
#include <cmath>
using namespace std;
int n,d,dis[111111],pr[111111],mi[111111] = {0x7f7f7f7f};
int A(int s,int x){
	if(s == n) return 0;
	int y = (ceil)((dis[s] * 1.0 - x) / d);
	return A(s+1,y*d-dis[s]+x) + y * mi[s];
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin >> n >> d;
	for(int i = 1;i < n;i++) cin >> dis[i];
	for(int i = 1;i <= n;i++){
		cin >> pr[i];
		if(pr[i] < mi[i-1]) mi[i] = pr[i];
		else mi[i] = mi[i-1];
	}
	cout << A(1,0);
	return 0;
} 
