#include <iostream>
using namespace std;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n,d = 0,x;
	bool first = 1;
	cin >> n;
	while(n){
		d++;
		if(n % 3 == 1 && first){
			x = d;
			first = 0;
		}
		n -= (n+2) / 3;
	}
	cout << d << ' ' << x;
	return 0;
} 
