#include<bits/stdc++.h>
using namespace std;
long long ans,n,d,v[100001],a[100001],sheng,lu;
void dfs(long long num,long long maxn)
{
	if(num>n){
		printf("%lld",ans);
		exit(0);
	}
	lu+=v[num-1];
	if(a[num]<maxn||num==n){
		long long you=(lu-sheng)/d;
		if((lu-sheng)%d!=0) you++;
		ans+=you*maxn;
		sheng=you*d-lu+sheng;
		maxn=a[num];
		lu=0;
	}
	dfs(num+1,maxn);
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%lld%lld",&n,&d);
	for(int i=1;i<n;i++)
		scanf("%lld",&v[i]);
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	dfs(1,a[1]);
}
