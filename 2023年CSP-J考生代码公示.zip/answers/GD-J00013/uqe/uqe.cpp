#include<bits/stdc++.h>
using namespace std;
int t,a,b,c,m;
int gcd(int a,int b) {
	if(a%b==0) return b;
	return gcd(b,a%b);
}
int main() {
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&t,&m);
	while(t--) {
		int y=0;
		scanf("%d%d%d",&a,&b,&c);
		if(b*b<4*a*c)
			printf("NO"),y=1;
		else {
			int ans1=-b,ans2=b*b-4*a*c,cheng=1,chu=2*a,num=sqrt(ans2);
			if(b!=0) {
				if(num*num==ans2){
					if(a>0)
					ans1+=num;
					else ans1-=num;
					ans2=0;
				}
				if(ans1%(2*a)==0) printf("%d",ans1/(2*a));
				else {
					if(ans1/abs(ans1)!=(2*a)/abs(2*a))
						printf("-");
					printf("%d/%d",abs(ans1)/gcd(abs(ans1),2*a),abs(2*a/gcd(abs(ans1),2*a)));
				}
				y=1;
			}
			if(ans2!=0) {
				if(b!=0)
					printf("+");
				for(int i=sqrt(ans2); i; i--)
					if(ans2%(i*i)==0) {
						cheng=i;
						ans2/=i*i;
						break;
					}
				int g=gcd(cheng,chu);
				cheng/=g,chu/=g;
				if(abs(cheng)!=1){
					printf("%d",abs(cheng));
					if(ans2!=1) printf("*");
					y=1;
				}
				if(ans2!=1)
				y=1,printf("sqrt(%d)",ans2);
				if(abs(chu)!=1) y=1,printf("/%d",abs(chu));
			}
		}
		if(y==0) printf("0");
		printf("\n");
	}
}
