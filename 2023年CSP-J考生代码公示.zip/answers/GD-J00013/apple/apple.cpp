#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n,tot=0,ans=0;
	scanf("%d",&n);
	while(n>0)
	{
		n--;
		tot++;
		if(n%3==0&&ans==0) ans=tot;
		n-=n/3;
	}
	printf("%d %d",tot,ans);
}
