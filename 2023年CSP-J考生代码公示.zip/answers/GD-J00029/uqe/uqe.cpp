#include<bits/stdc++.h>
using namespace std;
int a,b,c,x,bg=0,bgg=1,sl,midd,fub,deltaa,i,mmx;
int ggcd(int m,int n){
	m=max(m,-m);
	n=max(n,-n);
	if(m*n==0){
		return max(m-n,n-m);
	}
	else{
		if(m>=n){
			return ggcd(m-n,n);
		}
		else{
			return ggcd(m,n-m);
		}
	}
}
int main(){
	/*freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);*/
	scanf("%d %d",&x,&mmx);
	for(i=0;i<x;i++){
		scanf("%d %d %d",&a,&b,&c);
		if(a<0){
			a*=-1;
			b*=-1;
			c*=-1;
		}
		fub=-b;
		deltaa=b*b-4*a*c;
		if(deltaa>=0){
			for(int j=0;j*j<=deltaa;j++){
				if(deltaa==j*j){
					bg=j;
				}
			}
			if(bg*bg==deltaa){
				fub+=bg;
				if(max(fub,-fub)%(2*a)==0){
					printf("%d\n",fub/(2*a));
				}
				else{
					printf("%d/%d\n",fub/ggcd(fub,2*a),2*a/ggcd(fub,2*a));
				}
			}
			else{
				for(int j=2;j*j<=deltaa;j++){
					if(deltaa%(j*j)==0){
						bgg=j;
					}
				}
				if(bgg>1){
					if(max(fub,-fub)%(2*a)==0){
						if(fub/(2*a)!=0){
							if(ggcd(bgg,2*a)!=1){
								printf("%d+%d*sqrt(%d)\n",fub/(2*a),bgg/(2*a),deltaa/(bgg*bgg));
							}
							else{
								printf("%d+%d*sqrt(%d)/%d\n",fub/(2*a),bgg,deltaa/(bgg*bgg),2*a);
							}
						}
						else{
							if(ggcd(bgg,2*a)!=1){
								printf("%d*sqrt(%d)\n",bgg/(2*a),deltaa/(bgg*bgg));
							}
							else{
								printf("%d*sqrt(%d)/%d\n",bgg,deltaa/(bgg*bgg),2*a);
							}
						}
					}
					else{
						if(ggcd(bgg,2*a)!=1){
							printf("%d/%d+%d*sqrt(%d)\n",fub/ggcd(fub,2*a),2*a/ggcd(fub,2*a),bgg/(2*a),deltaa/(bgg*bgg));
						}
						else{
							printf("%d/%d+%d*sqrt(%d)/%d\n",fub/ggcd(fub,2*a),2*a/ggcd(fub,2*a),bgg,deltaa/(bgg*bgg),2*a);
						}
					}
				}
				else{
					if(max(fub,-fub)%(2*a)==0){
						if(fub/(2*a)!=0){
							printf("%d+sqrt(%d)/%d\n",fub/(2*a),deltaa,2*a);
						}
						else{
							printf("sqrt(%d)/%d\n",deltaa,2*a);
						}
					}
					else{
						printf("%d/%d+sqrt(%d)/%d\n",fub/ggcd(fub,2*a),2*a/ggcd(fub,2*a),deltaa,2*a);
					}
				}
			}
		}
		else{
			printf("NO\n");
		}
		bgg=1;
		fflush(stdout);
	}
} 
