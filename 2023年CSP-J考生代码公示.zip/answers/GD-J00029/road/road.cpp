#include<bits/stdc++.h>
using namespace std;
int a,b,c,x,aa[100005],bb[100005],i;
long long dp[100005][2];
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d %d",&a,&b);
	for(i=2;i<=a;i++){
		scanf("%d",&c);
		aa[i]=aa[i-1]+c;
	}
	for(i=1;i<=a;i++){
		scanf("%d",&bb[i]);
		dp[i][0]=1000000000;
	}
	dp[1][0]=0;
	for(i=1;i<a;i++){
		for(int j=i+1;j<=a;j++){
			x=(aa[j]-aa[i]+b-1-dp[i][1])/b;
			if(dp[i][0]+x*bb[i]<dp[j][0]){
				dp[j][0]=dp[i][0]+x*bb[i];
				dp[j][1]=x*b-aa[j]+dp[i][1]+aa[i];
			}
		}
	}
	printf("%lld",dp[a][0]);
	return 0;
} 
