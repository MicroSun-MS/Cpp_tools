#include<bits/stdc++.h>
using namespace std;
int a,i,ddy=0,dyy=0,aal=0,ccn=2;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&a);
	bool b[a+5];
	for(i=1;i<=a;i++){
		b[i]=true;
	} 
	while(aal<a){
		ddy++;
		for(i=1;i<=a;i++){
			if(b[i]==true){
				ccn++;
				if(ccn==3){
					ccn=0;
					aal++;
					b[i]=false;
					if(i==a){
						dyy=ddy;
					}
				}
			}
		}
		ccn=2;
	}
	printf("%d %d",ddy,dyy);
	return 0;
} 
