#include <bits/stdc++.h>

using namespace std;
long long n,m,k,flag=1,maxx,minn=1000010;
long long head[100010],to[100010],ne[100010],w[100010],id;
long long ans=0x3f3f3f3f;
void add(long long x,long long y,long long z){
	to[++id]=y,ne[id]=head[x],head[x]=id,w[id]=z;
}
void dfs(long long u,long long fa,long long step){
	//cout<<u<<" "<<step<<endl;
	if(u==n){
		if(step%k==0){
			ans=min(ans,step);
			flag=0;
		}
		return;
	}
	for(int i=head[u];i;i=ne[i]){
		int v=to[i];
		//if(w[i]>step)
			//cout<<"a "<<w[i]<<endl;
		if(v==fa||w[i]>step)
			continue;
		//cout<<step<<endl;
		dfs(v,u,step+1);
	}
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%lld%lld%lld",&n,&m,&k);
	long long x,y,z;
	for(int i=1;i<=n;i++){
		scanf("%lld%lld%lld",&x,&y,&z);
		add(x,y,z);
		maxx=max(maxx,z);
		minn=min(minn,z);
	}
	long long num=(minn/k)*k;
	while(flag&&num<=maxx){
		dfs(1,0,num);
		num+=k;
		//cout<<num<<endl;
	}
	if(flag)
		cout<<-1<<endl;
	else
		cout<<ans<<endl;
	return 0;
}

