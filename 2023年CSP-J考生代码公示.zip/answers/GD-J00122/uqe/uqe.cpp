#include <bits/stdc++.h>

using namespace std;
long long n,m,a,b,c,num;
void f(int x,int y){
	bool flag=1;
	while(flag){
		flag=0;
		for(int i=2;i<=min(x,y);i++){
			if(x%i==0&&y%i==0){
				x/=i,y/=i;
				flag=1;
			}
		}
	}
	cout<<x<<"/"<<y;
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>n>>m;
	while(n--){
		cin>>a>>b>>c;
		num=(b*b)-(4*a*c);
		if(num<0){
			cout<<"NO"<<endl;
			continue;
		}
		if(sqrt(num)*sqrt(num)==num){
			double ans=(double)(sqrt(num)-b)/(2*a);
			//if(ans<(double)0){
			//	cout<<"-";
			//}
			if(int(ans+0.999)>(int)ans){
				f(sqrt(num)-b,2*a);
			}
			else{
				cout<<(int)ans;
			}
			cout<<endl;
		}
		else{
			double ans=(double)(-b)/(2*a);
			//if(ans<(double)0){
			//	cout<<"-";
			//}
			if(int(ans+0.999)>(int)ans){
				f(-b,2*a);
			}
			cout<<"+sqrt(";
			if(num%(2*a*2*a)==0){
				cout<<(2*a)<<num/(2*a*2*a)<<")";
			}
			else{
				cout<<num<<")/"<<2*a; 
			}
			cout<<endl;
		}
	}
	return 0;
}

