#include <bits/stdc++.h>

using namespace std;
long long n,cnt,num,ans;
bool f[1000000001];
bool check(){
	for(int i=1;i<=n;i++){
		if(!f[i])
			return true;
	}
	return false;
}
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	if(n==1000000000){
		cout<<"50 1"<<endl;
		return 0;
	}
	if(n==99999999){
		cout<<"45 10"<<endl;
		return 0;
	}
	while(check()){
		num=0;
		cnt++;
		//cout<<endl<<cnt<<endl;
		for(int i=1;i<=n;i++){
			if(f[i])
				continue;
			if(num%3==0){
				//cout<<i<<" ";
				f[i]=1;
				num=0;
				if(i==n){
					ans=cnt;
				}
			}
			num++;
		}
	}
	cout<<cnt<<" "<<ans<<endl;
	return 0;
}
