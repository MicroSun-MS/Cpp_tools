#include <bits/stdc++.h>

using namespace std;
long long n,p;
long long d[100010],w[100010],sum[100010],num,ans,last;
void f(int x){
	long long flag=0;
	for(int i=x+1;i<n;i++){
		if(w[i]<w[x]){
			flag=i;
			break;
		}
	}
	if(!flag){
		if((sum[n]-sum[x])%p!=0){
			num=(sum[n]-sum[x])/p+1;
		}
		else
			num=(sum[n]-sum[x])/p;
		if((sum[n]-sum[x])-(num-1)*p<=last){
			num--;
			last-=(sum[n]-sum[x])-(num-1)*p;
		}
		ans+=num*w[x];
		return;
	}
	if((sum[flag]-sum[x]-last)%p!=0){
		num=(sum[flag]-sum[x]-last)/p+1;
	}
	else
		num=(sum[flag]-sum[x]-last)/p;
	if((sum[flag]-sum[x])-(num-1)*p<=last){
		num--;
		last-=(sum[flag]-sum[x])-(num-1)*p;
	}
	//cout<<x<<" "<<flag<<" "<<num<<endl;
	ans+=num*w[x];
	last+=(num*p)-(sum[flag]-sum[x]);
	//cout<<ans<<" "<<last<<endl;
	f(flag);
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>p;
	for(int i=2;i<=n;i++){
		cin>>d[i];
		sum[i]=sum[i-1]+d[i];
	}
	for(int i=1;i<=n;i++){
		cin>>w[i];
	}
	f(1);
	cout<<ans<<endl;
	return 0;
}

