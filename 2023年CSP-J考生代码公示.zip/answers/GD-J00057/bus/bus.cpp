#include <bits/stdc++.h>
using namespace std;
//vector<int> G[70007];
//vector<int> w[70007];
//int vis[70007];
//int n,m,k;
//void dfs(int u,int time)
//{
//	if(u==n) return;
//	for(int i=0;i<G[u].size();i++)
//	{
//		int v=G[i];
//		if(!vis[v])
//		{
//			vis[v]=1;
//			dfs(time+1);
//			vis[v]=0;
//		}
//	}
//	return;
//}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cout<<-1;
//	cin>>n>>m>>k;
//	for(int i=0;i<m;i++)
//	{
//		int u,v,c;
//		cin>>u>>v>>c;
//		G[u].push_back(v);
//		G[v].push_back(u);
//		w[u].push_back(c);
//		w[v].push_back(c);
//	}
//	vis[1]=1;
//	dfs(1,0);
	return 0;
}
