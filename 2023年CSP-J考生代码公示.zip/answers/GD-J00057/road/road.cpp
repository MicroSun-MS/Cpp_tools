#include <bits/stdc++.h>
using namespace std;
int a[100007],b[100007];
int dp[100007];
double yous[10007];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	int n,d;
	cin>>n>>d;
	for(int i=1;i<=n-1;i++) cin>>a[i];
	for(int i=1;i<=n;i++) cin>>b[i];
//	dp[1]=ceil(a[1]*1.0/d)*a[i];
	int nowmin=459764397,nowid=0;
	for(int i=1;i<=n;i++)
	{
		if(b[i]<nowmin)
		{
			nowmin=b[i],nowid=i;
		}
		dp[i]=dp[i-1]+ceil(a[i]*1.0/d-yous[i-1])*b[nowid];
		yous[i]=ceil(a[i]*1.0/d-yous[i-1])-a[i]*1.0/d+yous[i-1];
	}
	cout<<dp[n];
	return 0;
}


