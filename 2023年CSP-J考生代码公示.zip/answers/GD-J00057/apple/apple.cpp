#include <bits/stdc++.h>
using namespace std;
long long dijian(long long n)
{
	if(n==1) return 1;
	return dijian(n-ceil(n/3.0))+1;
}
long long dijia(long long n,long long q,long long cs)
{
	if(n==1) return 1;
	if(q%3==1) return cs;
	return dijia(n-ceil(n/3.0),q-ceil(q/3.0),cs+1);
}
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	long long n;
	cin>>n;
	cout<<dijian(n)<<" "<<dijia(n,n,1)<<endl;
	return 0;
} 
