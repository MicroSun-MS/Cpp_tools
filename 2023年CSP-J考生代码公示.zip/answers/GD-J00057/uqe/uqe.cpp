#include <bits/stdc++.h>
using namespace std;
long long very_fast_gcd(long long n,long long m)
{
	if(m==0) return n;
	return very_fast_gcd(m,n%m);
}
pair<int,int> hjsqrt(long long n)
{
	long long ans1=1,ans2=1;
	long long oxx=n;
	for(long long i=2;i<=oxx;i++)
	{
		if(n<=1) break;
		if(n%i) continue;
		int xsx=0;
		while(n%i==0) xsx++,n/=i;
		ans2*=(xsx%2==1?i:1);
	}
	return make_pair(sqrt(oxx/ans2),ans2);
}
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int t,m;
	cin>>t>>m;
	while(t--)
	{
		long long a,b,c;
		cin>>a>>b>>c;
		if(b*b-4*a*c<0) cout<<"NO";
		else{
			double delta=1.0*b*b-4*a*c;
			double s1=(-b+sqrt(delta))/2.0/a;
			double s2=(-b-sqrt(delta))/2.0/a;
			if(s1>=s2)
			{
				if(ceil(sqrt(delta))==sqrt(delta))
				{
					long long fac1=(-b+sqrt(delta));
					long long fac2=2*a;
					long long facy=very_fast_gcd(fac1,fac2);
					fac1/=facy,fac2/=facy;
					long long fyz=(fac1)*(fac2);
					if(fyz<0) cout<<"-";
					fac1=abs(fac1),fac2=abs(fac2);
					if(fac2==1)
					{
						cout<<fac1;
					}else{
						cout<<fac1<<"/"<<fac2;
					}
				}else{
					long long q2,r;
					r=hjsqrt(delta).second;
					q2=hjsqrt(delta).first;
					//-b/2.0/a
					if(b!=0)
					{
						long long fac1=-b;
						long long fac2=2*a;
						long long facy=very_fast_gcd(fac1,fac2);
						fac1/=facy,fac2/=facy;
						long long fyz=(fac1)*(fac2);
						if(fyz<0) cout<<"-";
						fac1=abs(fac1),fac2=abs(fac2);
						if(fac2==1)
						{
							cout<<fac1;
						}else{
							cout<<fac1<<"/"<<fac2;
						}
						cout<<'+';
					}
					//q2*sqrt/2/a
					long long fac1=q2;
					long long fac2=2*a;
					long long facy=very_fast_gcd(fac1,fac2);
					fac1/=facy,fac2/=facy;
					long long fyz=(fac1)*(fac2);
					if(fyz<0) cout<<"-";
					fac1=abs(fac1),fac2=abs(fac2);
					if(fac1==1)
					{
						cout<<"sqrt("<<r<<")";
					}else{
						cout<<fac1<<"*sqrt("<<r<<")";
					}
					if(fac2!=1)
					{
						cout<<"/"<<fac2;
					}
				}
			}else{
				s1=s2;
				if(ceil(sqrt(delta))==sqrt(delta))
				{
					long long fac1=(-b-sqrt(delta));
					long long fac2=2*a;
					long long facy=very_fast_gcd(fac1,fac2);
					fac1/=facy,fac2/=facy;
					long long fyz=(fac1)*(fac2);
					if(fyz<0) cout<<"-";
					fac1=abs(fac1),fac2=abs(fac2);
					if(fac2==1)
					{
						cout<<fac1;
					}else{
						cout<<fac1<<"/"<<fac2;
					}
				}else{
					long long q2,r;
					r=hjsqrt(delta).second;
					q2=hjsqrt(delta).first;
					//-b/2.0/a
					if(b!=0)
					{
						long long fac1=-b;
						long long fac2=2*a;
						long long facy=very_fast_gcd(abs(fac1),abs(fac2));
						fac1/=facy,fac2/=facy;
						long long fyz=(fac1)*(fac2);
						if(fyz<0) cout<<"-";
						fac1=abs(fac1),fac2=abs(fac2);
						if(fac2==1)
						{
							cout<<fac1;
						}else{
							cout<<fac1<<"/"<<fac2;
						}
						cout<<'+';
					}
					//q2*sqrt/2/a
					long long fac1=-q2;
					long long fac2=2*a;
					long long facy=very_fast_gcd(abs(fac1),abs(fac2));
					fac1/=facy,fac2/=facy;
					long long fyz=(fac1)*(fac2);
					if(fyz<0) cout<<"-";
					fac1=abs(fac1),fac2=abs(fac2);
					if(fac1==1)
					{
						cout<<"sqrt("<<r<<")";
					}else{
						cout<<fac1<<"*sqrt("<<r<<")";
					}
					if(fac2!=1)
					{
						cout<<"/"<<fac2;
					}
				}
			}
		}
		cout<<endl;
	}
	return 0;
}
