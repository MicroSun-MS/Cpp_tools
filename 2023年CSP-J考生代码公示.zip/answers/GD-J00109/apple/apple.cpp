#include<bits/stdc++.h>
using namespace std;
const int ma=1e6+15;
int day[ma],n;
int g(int i){
	bool o=0;
	int dis=2;
	for(int j=1;j<=n;j++){
		if(day[j]==0&&dis==2){
			o=1;
			day[j]=i;
			dis=0;
		}
		else if(day[j]==0&&dis<2){
			dis++;
		}
	}
	if(!o){
		return i-1;
	}
	return g(i+1);
}
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	for(int i=0;i<=n/3+1;i++){
		day[i*3+1]=1;
	}
	cout<<g(2)<<" ";
	cout<<day[n];
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
