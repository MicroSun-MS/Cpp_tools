#include<bits/stdc++.h>
using namespace std;
const int ab=1e5+15;
int n,d;
int v[ab],a[ab];
int g(int oil,int w,int i){
	int low=ab;
	if(i==n){
		return w;
	}
	for(int j=i;j<=n;j++){
		int m=v[j]-v[i-1]-oil;
		int k=m/d;
		if(m%d==0){
			low=min(low,g(0,w+k*a[i],j));
		}
		else {
			k++;
			oil+=k*d-m-oil;
			low=min(low,g(oil,w+k*a[i],j));
		}
	}
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=1;i<n;i++){
		cin>>v[i];
		v[i]=v[i-1]+v[i];
	}
	for(int i=1;i<=n;i++)cin>>a[i];
	cout<<g(0,0,1);	
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
