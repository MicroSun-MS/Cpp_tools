#include<bits/stdc++.h>
using namespace std;
const int ab=1e4+1;
int n,m,k;
struct lr{
	int v;
	int t;
};
lr u[ab][ab];
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<m;i++){
		int a,b;
		cin>>a>>b;
		u[a][b].v=1;
		cin>>u[a][b].t;
	}
	cout<<-1;
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
