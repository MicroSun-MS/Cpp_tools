#include<bits/stdc++.h>
using namespace std;
int m,t,a,b,c,delta,q,p;
int pan[2],chuli[2];
void chu(int a,int b){
	if(a*b>0)
	{
		if(a>0)chuli[0]=a,chuli[1]=b;
		else chuli[0]=-a,chuli[1]=-b;
	}
	else if(a*b<0){
		if(a>0)chuli[0]=-a,chuli[1]=-b;
		else chuli[0]=a,chuli[1]=b;
	}
}
void sou(int d){
	int k=0;
	for(int i=1;i<=sqrt(d)+1;i++){
		int j=i*i;
		if(d%j==0)k=max(i,k);
	}
	if(k!=0){
		pan[0]=k;
		pan[1]=d/(k*k);
	}
	else {
		pan[0]=1;
		pan[1]=d;
	}
	return;
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	cin>>t>>m;
	for(int i=1;i<=t;i++){
		cin>>a>>b>>c;
		delta=b*b-4*a*c;
		sou(delta);
		int gg=__gcd(2*a,b);
		int gg2=__gcd(2*a,pan[0]);
		p=a*2/gg;
		q=b/gg;
		q=0-q;
		chu(q,p);
		q=chuli[0];
		p=chuli[1];
		if(delta<0){
			cout<<"NO"<<endl;
		}
		else if(delta==0){			
			if(p==1)cout<<q<<endl;
			else cout<<q<<"/"<<p<<endl;
		}
		else{
			int f1=pan[0];
			int f2=pan[1];
			if(f2==1){
				f1/=gg2;
				int f3=a*2/gg2;
				if(f3==1){					
					if(p==1)cout<<q+f1<<endl;
					else if((q+f1*p)==0);
					else cout<<q+f1*p<<"/"<<p<<endl;
				}
				else{
					int f4=q*f3+p*f1;
					int f5=p*f3;
					int f6=__gcd(f4,f5);
					f4/=f6;
					f5/=f6;
					if(f5==1){
						cout<<f4<<endl;
					}
					else cout<<f4<<"/"<<f5<<endl;
				}
			}
			else{
				if(q=-p){
					cout<<-1<<"+";
				}
				else if(q=p){
					cout<<1<<"+";
				}
				else if(q==0);
				else cout<<q<<"/"<<p<<"+";
				f1/=gg2;
				int f3=a*2/gg2;
				if(f3==1){
					if(f1==1)cout<<"sqrt("<<f2<<")"<<endl;
					else cout<<f1<<"*sqrt("<<f2<<")"<<endl;
				}
				else {
					if(f1==1)cout<<"sqrt("<<f2<<")/"<<f3<<endl;
					else cout<<f1<<"*sqrt("<<f2<<")/"<<f3<<endl;
				}
			}
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
