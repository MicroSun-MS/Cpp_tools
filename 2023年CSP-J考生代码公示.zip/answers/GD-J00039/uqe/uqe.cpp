#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define fr first
#define sc second
#define db double
typedef const int Int;
typedef const double Db;
typedef pair<int,int> pii;

Int N=1e7;

int sq[N];

int T,m;

int a,b,c;

int gcd(int a,int b){
	return (b?gcd(b,a%b):a);
}

void prQ(int a1,int a2){
	bool x=(1LL*a1*a2>0);
	int g=gcd(a1,a2);
	if(!x)putchar('-');
	if(a1%a2==0)printf("%d",abs(a1/a2));
	else printf("%d/%d",abs(a1/g),abs(a2/g));
	return;
}

void solve(){
	int dlt=b*b-4*a*c;
	if(dlt<0){
		printf("NO");
		return;
	}
	if(!dlt||(sq[dlt]&&sq[dlt]*sq[dlt]==dlt)){
		int fz=-b+sq[dlt],fm=2*a;
		prQ(fz,fm);
		return;
	}
	if(b){
		prQ(-b,2*a);
		putchar('+');
	}
	sq[dlt]=max(1,sq[dlt]);
	int fz=sq[dlt],fm=abs(2*a);
	int g=gcd(fz,fm);
	fz/=g,fm/=g;
	if(fz!=1)printf("%d*",fz);
	printf("sprt(%d)",dlt/(sq[dlt]*sq[dlt]));
	if(fm!=1)printf("/%d",fm);
	return;
}

int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&T,&m);
	sq[1]=1;
	for(int i=2;i*i<=5*m*m;i++){
		sq[i*i]=i;
		for(int j=2;j*i*i<=5*m*m;j++){
			sq[i*i*j]=i;
		}
	}
	while(T--){
		scanf("%d%d%d",&a,&b,&c);
		solve();
		putchar('\n');
	}
	return 0;
}

//boring simulation
//correct CCF








