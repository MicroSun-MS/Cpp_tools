#include <bits/stdc++.h>
using namespace std;

#define pb push_back
#define LL long long
#define fr first
#define sc second
#define db double
typedef const int Int;
typedef const double Db;
typedef pair<int,int> pii;

Int N=1e4+5;

vector <pii> G[N];

pii f[N][100];

int n,m,k;

struct sta{
	int p,t,mint;
};

void bfs(){
	queue <sta> Q;
	Q.push(sta{1,0,0});
	f[1][0]=pii{0,0};
	while(!Q.empty()){
		int u=Q.front().p,t=Q.front().t,mt=Q.front().mint;
		Q.pop();
		for(auto &i:G[u]){
			int v=i.fr,a=i.sc;
			int nmax=max(mt,a-t);
			if(f[v][(t+1)%k].fr+f[v][(t+1)%k].sc>t+1+nmax){
				Q.push(sta{v,t+1,nmax});
				f[v][(t+1)%k]=pii{t+1,nmax};
			}
		}
	}
	return;
}

int u,v,a;

int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	memset(f,0x3f,sizeof(f));
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;i++){
		scanf("%d%d%d",&u,&v,&a);
		G[u].pb(pii{v,a});
	}
	bfs();
	if(f[n][0].fr!=0x3f3f3f3f)printf("%d",(int)ceil(1.0*(f[n][0].fr+f[n][0].sc)/k)*k);
	else printf("-1");
	return 0;
}

//happy ending (Hopefully)
//kind CCF

//        a       k   k        ccccccc   ssssssss  pppppppp               jjjjjjjjj                
//       a a      k  k        c       c s        s p       p                  j                
//      a   a     k k        c          s          p       p                  j                
//     aaaaaaa    kk         c           ssssssss  pppppppp   -----------     j                                      
//    a       a   k k        c                   s p                          j              
//   a         a  k  k        c       c s        s p                      j   j           
//  a           a k   k        ccccccc   ssssssss  p                       jjj                          
                                                                   







