#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define pb push_back
#define fr first
#define sc second
#define db double
typedef const int Int;
typedef const double Db;
typedef pair<int,int> pii;

Int N=1e5+5;

int n,m;

LL v[N],w[N];

LL sum[N];

vector <int> rcd;

int minn=INT_MAX;

LL ans,lef;

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&m);
	for(int i=1;i<n;i++)scanf("%lld",&v[i]),sum[i]=sum[i-1]+v[i];
	for(int i=1;i<=n;i++)scanf("%lld",&w[i]);
	for(int i=1;i<=n;i++){
		if(w[i]<minn){
			rcd.pb(i-1);
			minn=w[i];
		}
	}
	rcd.pb(n-1);
//	for(auto &i:rcd)cout<<i<<endl;
	for(int i=0;i<rcd.size()-1;i++){
		LL x=ceil(1.0*max(0LL,sum[rcd[i+1]]-sum[rcd[i]]-lef)/m);
//		cout<<x<<endl;
		ans+=x*w[rcd[i]+1];
		lef+=x*m-(sum[rcd[i+1]]-sum[rcd[i]]);
	}
	printf("%lld",ans);
	return 0;
}

//problem-less code
//unbreakable CCF








