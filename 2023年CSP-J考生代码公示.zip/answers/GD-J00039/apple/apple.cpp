#include <bits/stdc++.h>
using namespace std;

#define LL long long
#define fr first
#define sc second
#define db double
typedef const int Int;
typedef const double Db;
typedef pair<int,int> pii;

//Int N;

int n;

int a,b;

int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);
	for(a=1;n;a++){
		if(!b&&n%3==1)b=a;
		n-=(n+2)/3;
	}
	printf("%d %d\n",a-1,b);
	return 0;
}

//good beginning
//fantastic CCF








