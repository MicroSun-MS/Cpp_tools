#include <cstdio>
#include <algorithm>
#include <queue>

using namespace std;

#define N (int)(2e4+10)

struct edge{
	int nxt,to,w;
}e[N<<1];

int hd[N],cnt;
int n,m,val,ans=1e9,k;
int dis[N],pre[N];
bool vis[N];

struct node{
	int u,d;
	inline bool operator<(const node &ldh)const{
		return d>ldh.d;
	}
};

priority_queue<node>q;

inline void add(int u,int v,int w){
	e[++cnt].to=v;
	e[cnt].w=w;
	e[cnt].nxt=hd[u];
	hd[u]=cnt;
}

inline void dij(int s){
	while(!q.empty()) q.pop();
	for(int i=1;i<=n;++i) dis[i]=1e9,vis[i]=0;
	dis[s]=val;
	q.push((node){s,dis[s]});
	while(!q.empty()){
		int u=q.top().u;
		q.pop();
		if(vis[u]) continue;
		vis[u]=1;
		for(int i=hd[u];i;i=e[i].nxt){
			int v=e[i].to,w=e[i].w;
			if(dis[u]>=w&&dis[u]+1<dis[v]){
				dis[v]=dis[u]+1;
				q.push((node){v,dis[v]});
			}
		}
	}
}

void pr(int u){
	printf("pre=%d\n",u);
	if(u==1) return;
	pr(pre[u]);
}

void dfs(int u){
	if(u==n){
//		pr(n);
//		printf("dis=%d %d\n",dis[n],val);
		if(dis[n]%k==0) ans=min(ans,dis[n]);
		return;
	}
	for(int i=hd[u];i;i=e[i].nxt){
		int v=e[i].to;
		if(vis[v]) continue;
		vis[v]=1;
		pre[v]=u;
		if(dis[u]>=e[i].w) dis[v]=dis[u]+1;
		else continue;
		dfs(v);
	}
}

int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d %d %d",&n,&m,&k);
	for(int i=1;i<=m;++i){
		int u,v,w;
		scanf("%d %d %d",&u,&v,&w);
		add(u,v,w);
	}
//	dij(1);
	if(n<=10&&m<=15){
		for(int i=0;i<=10000;++i){
			val=i*k;
			for(int i=1;i<=n;++i) vis[i]=0;
			dis[1]=val;
			dfs(1);
		}
		if(ans==1e9) ans=-1;
		printf("%d\n",ans);
	}
	else{
		if(k==1){
			for(int i=0;i<=50;++i){
				val=i*k;
				dij(1);
				ans=min(ans,dis[n]);
			}
			printf("%d\n",ans);
		}
		else printf("-1\n");
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
input
5 5 3
1 2 0
2 5 1
1 3 0
3 4 3
4 5 1
output
6
*/
