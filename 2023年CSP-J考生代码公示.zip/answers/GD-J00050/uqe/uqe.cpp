#include <cstdio>
#include <cmath>
#include <algorithm>

using namespace std;

int t,m;
int a,b,c;

inline int my_abs(int x){
	return x<0?-x:x;
}

int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d %d",&t,&m);
	while(t--){
		scanf("%d %d %d",&a,&b,&c);
		int d=b*b-4*a*c;
		if(d<0){
			printf("NO\n");
			continue;
		}
		int tmp1=sqrt(d);
//		printf("orzlgp=%d\n",d);
		if(tmp1*tmp1==d){
			int tmp2=sqrt(d);
			int ans1_fz=-b+tmp2,ans2_fz=-b-tmp2;
//			double fs1=1.0*ans1_fz/(2.0*a);
//			double fs2=1.0*ans2_fz/(2.0*a);
			int mxfz=max(ans1_fz,ans2_fz);
			int fs=mxfz/(2*a);
			if(fs*2*a==mxfz){
				int ans=mxfz/(2*a);
				printf("%d\n",ans);
				continue;
			}
			else{
//				printf("orzzcy=%d\n",mxfz);
				int tmpfz=my_abs(mxfz);
				int tmpfm=my_abs(2*a);
				int g=__gcd(tmpfz,tmpfm);
				if(!g) g=1;
				tmpfz/=g,tmpfm/=g;
				if(mxfz<0) tmpfz*=(-1);
				if(2*a<0) tmpfm*=(-1);
				printf("%d/%d\n",tmpfz,tmpfm);
				continue;
			}
		}
		else{
//			printf("zcy AK IOI\n");
			int cur=0;
			for(int i=1;i*i<=d;++i){
				if(d%(i*i)==0) cur=i;
			}
			d/=(cur*cur);
			int xiang1fz=my_abs(-b);
			int xiang1fm=my_abs(2*a);
			int xiang2fz1=my_abs(cur);
			int xiang2fm=my_abs(2*a);
			int g1=__gcd(xiang1fz,xiang1fm);
			xiang1fz/=g1,xiang1fm/=g1;
			if(-b<0) xiang1fz*=(-1);
			if(2*a<0) xiang1fm*=(-1);
			int g2=__gcd(xiang2fz1,xiang2fm);
			xiang2fz1/=g2,xiang2fm/=g2;
			if(2*a<0) xiang2fm*=(-1);
//			printf("%d\n",xiang2fz1);
			if(xiang2fz1==1){
				if(xiang1fm==1&&xiang2fm==1) printf("%d+sqrt(%d)\n",xiang1fz,d);
				else if(xiang1fm==-1&&xiang2fm==1) printf("-%d+sqrt(%d)\n",xiang1fz,d);
				else if(xiang1fm==1&&xiang2fm==-1) printf("%d-sqrt(%d)\n",xiang1fz,d);
				else if(xiang1fm==-1&&xiang2fm==-1) printf("-%d-sqrt(%d)\n",xiang1fz,d);
				else if(xiang1fm==1) printf("%d+sqrt(%d)/%d\n",xiang1fz,d,xiang2fm);
				else if(xiang1fm==-1) printf("-%d+sqrt(%d)/%d\n",xiang1fz,d,xiang2fm);
				else if(xiang2fm==1) printf("%d/%d+sqrt(%d)\n",xiang1fz,xiang1fm,d);
				else if(xiang2fm==-1) printf("%d/%d-sqrt(%d)\n",xiang1fz,xiang1fm,d);
				else printf("%d/%d+sqrt(%d)/%d\n",xiang1fz,xiang1fm,d,xiang2fm);
			}
			else{
//				printf("orz ldh\n");
				if(xiang1fm==1&&xiang2fm==1) printf("%d+%d*sqrt(%d)\n",xiang1fz,cur,d);
				else if(xiang1fm==-1&&xiang2fm==1) printf("-%d+%d*sqrt(%d)\n",xiang1fz,cur,d);
				else if(xiang1fm==1&&xiang2fm==-1) printf("%d-%d*sqrt(%d)\n",xiang1fz,cur,d);
				else if(xiang1fm==-1&&xiang2fm==-1) printf("-%d-%d*sqrt(%d)\n",xiang1fz,cur,d);
				else if(xiang1fm==1) printf("%d+%d*sqrt(%d)/%d\n",xiang1fz,cur,d,xiang2fm);
				else if(xiang1fm==-1) printf("-%d+%d*sqrt(%d)/%d\n",xiang1fz,cur,d,xiang2fm);
				else if(xiang2fm==1) printf("%d/%d+%d*sqrt(%d)\n",xiang1fz,xiang1fm,cur,d);
				else if(xiang2fm==-1) printf("%d/%d-%d*sqrt(%d)\n",xiang1fz,xiang1fm,cur,d);
				else printf("%d/%d+%d*sqrt(%d)/%d\n",xiang1fz,xiang1fm,cur,d,xiang2fm);
			}
		}
	}
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
input:
9 1000
1 -1 0
-1 -1 -1
1 -2 1
1 5 4
4 4 1
1 0 -432
1 -3 1
2 -4 1
1 7 1
output:
1
NO
1
-1
-1/2
12*sqrt(3)
3/2+sqrt(5)/2
1+sqrt(2)/2
-7/2+3*sqrt(5)/2
*/
