#include <cstdio>

using namespace std;

#define N (int)(1e5+10)
#define ll long long

int n,d,lst;
int a[N],v[N];
int mnp[N];
ll cnt,ans;

int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d %d",&n,&d);
	for(int i=1;i<n;++i) scanf("%d",&v[i]);
	for(int i=1;i<=n;++i) scanf("%d",&a[i]);
	a[0]=1e9;
	for(int i=1;i<=n;++i){
		if(a[i]<a[mnp[i-1]]) mnp[i]=i;
		else mnp[i]=mnp[i-1];
	}
//	for(int i=1;i<=n;++i) printf("mnp=%d\n",mnp[i]);
	cnt=v[1]/d;
	if(v[1]%d) ++cnt;
	lst=cnt*d-v[1];
	ans+=cnt*a[1];
	for(int i=3;i<=n;++i){
		int tmp=a[mnp[i-1]];
		int ldh=v[i-1]-lst;
		cnt=ldh/d;
		if(ldh%d) ++cnt;
		ans+=tmp*cnt;
		lst=cnt*d-ldh;
	}
	printf("%lld\n",ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
/*
input:
5 4
10 10 10 10
9 8 9 6 5
output:
79
*/
