//QuartZ_Z bless me
#include <cstdio>

using namespace std;

int n,cnt,ans;

int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);
	bool fl=0;
	while(n>0){
		++cnt;
		if(n%3==1&&!fl) ans=cnt,fl=1;
		int tmp=n/3;
		if(n%3) --n;
		n-=tmp;
	}
	printf("%d %d\n",cnt,ans);
	fclose(stdin);fclose(stdout);
	return 0;
}
