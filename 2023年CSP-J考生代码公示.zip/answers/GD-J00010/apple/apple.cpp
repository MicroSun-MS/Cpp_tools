#include<bits/stdc++.h>
using namespace std;
int a[100000000],c[100000000],n,sum,qaq,t=0,k=0;
bool flag=0;	
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		a[i]=i;
	}
	while(n!=0){
		for(int i=1;i<=n;i+=3)
		{
			a[i]=0;
			
			sum++;
			if(i==n&&flag==0)	qaq=t,flag=1;
		}
		for(int i=1;i<=n;i++)
		{
			if(a[i]!=0)
			c[++k]=a[i];
		}
		n=k;k=0;
		sum++;
		if(n==0)	break;
		++t;
	}
	t++;
	qaq++;
cout<<t<<" "<<qaq;
	return 0;
}
