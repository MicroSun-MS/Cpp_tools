#include<bits/stdc++.h>
using namespace std;
int dirta(int a,int b,int c)
{
	return b*b-4*a*c;	
}
int gcd(int a,int c,bool q)
{
	int d,sum=1;
	if(a<c)		d=a;
	else		d=c;
	if(q==1)
	{
	for(int i=2;i<=d;i++)
	{
		while(a%i==0&&c%i==0)	sum*=i,a/=i,c/=i;
	}
	return sum;
	}
	else
	{
		for(int i=2;i<=sqrt(a);i++)
		{
			int s=i*i;
			while(a%s==0)	a/=s,sum*=i;
		}
		return sum;
	}
}
void qaq(int a,int b,int c)
{
	if(2*a/gcd(2*a,b,1)==1)	cout<<(-b/2*a);//zhengshu
	else	cout<<(-b/gcd(2*a,b,1))<<"/"<<(2*a/gcd(2*a,b,1));
}
void panduan(int a,int b,int c)
{
	if(dirta(a,b,c)<0)	cout<<"NO"<<endl;
	else if(sqrt(dirta(a,b,c))*sqrt(dirta(a,b,c))!=dirta(a,b,c))//dirta bushi pingfang shu
	{
		if(gcd(dirta(a,b,c),1,0)==1)	if(b!=0)	cout<<"+sqrt("<<dirta(a,b,c)<<")/"<<2*a<<endl;
		if(gcd(dirta(a,b,c),1,0)!=1)
		{
			if(b!=0&&gcd(gcd(dirta(a,b,c),1,0),2*a,1)==1)
			cout<<"+"<<gcd(dirta(a,b,c),1,0)<<"*sqrt("<<dirta(a,b,c)/gcd(dirta(a,b,c),1,0)/gcd(dirta(a,b,c),1,0)<<")/"<<2*a<<endl;
			if(b!=0&&gcd(gcd(dirta(a,b,c),1,0),2*a,1)!=1)
				if(2*a/gcd(gcd(dirta(a,b,c),1,0),2*a,1)==1)	cout<<"+"<<gcd(dirta(a,b,c),1,0)/gcd(gcd(dirta(a,b,c),1,0),2*a,1)<<"*sqrt("<<dirta(a,b,c)/gcd(dirta(a,b,c),1,0)/gcd(dirta(a,b,c),1,0);
			
		}		
	}
}
int main()
{
	int a,b,c;
	cin>>a>>b>>c;
	panduan(a,b,c);
}
