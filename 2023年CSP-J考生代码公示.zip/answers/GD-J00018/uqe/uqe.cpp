#include<bits/stdc++.h>
using namespace std;
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int t,m,a,b,c;
	cin>>t>>m;
	for(int i=1;i<=t;i++) 
	{
		cin>>a>>b>>c;
		int d=b*b-4*a*c;
		if(d<0) 
		{
			cout<<"NO"<<endl;
	    	continue;
		} 
		int xy=(-b+sqrt(d))/(2*a);
		int xx=(-b-sqrt(d))/(2*a);
		int p=max(xx,xy);
		cout<<p<<endl;
	}
	return 0;
}
