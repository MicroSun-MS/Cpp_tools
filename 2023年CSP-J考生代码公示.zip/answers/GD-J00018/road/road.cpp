#include<bits/stdc++.h>
using namespace std;
int n,d;
struct ab{
	int sum;
	int v;
}a[100001];
int x=0;
int sum=0;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	
	cin>>n>>d;
	for(int i=1;i<=n-1;i++)
	{
		cin>>a[i+1].v;
		
	}
	for(int i=1;i<=n;i++)
	{
		cin>>a[i].sum;
	}
	for(int i=1;i<n;)
	{
		int k=n,p=0;
		for(int j=i+1;j<=n;j++)
		{
			p+=a[j].v;
			if(a[j].sum<a[i].sum) 
			{
				k=j;
				//cout<<k<<" ";
				break;
			}
			if(i==n) k=n;
		}
		int q;
		//cout<<p-x<<" ";
		if((p-x)%d!=0) q=(p-x)/d+1;
		else q=(p-x)/d;
		sum+=q*a[i].sum;
		x=(x+q*d)-p;
		//cout<<x<<" "<<p<<" "<<q<<" "<<i<<endl;
		i=k;
	}
	cout<<sum;
	return 0;
}
