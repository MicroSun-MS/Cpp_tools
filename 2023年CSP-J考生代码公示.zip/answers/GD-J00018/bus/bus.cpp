#include<bits/stdc++.h>
using namespace std;
struct ab{
	vector<int>m;
	vector<int>x;
}a[10001];
int n,m,k;
int mm=1000000001;
bool kp[10001];
void dfs(int x,int p,int mx)
{
	if(x==n)
	{
		if(p%k!=0) return ;
		int qx;
		if(mx%k!=0) 
		qx=(mx/k+1)*k;
		else qx=(mx/k)*k;
		//cout<<mx<<" "<<k<<endl;
		p=p+qx;
		mm=min(mm,p);
		return ;
	}
	for(int i=0;i<a[x].m.size();i++)
	{
		int px=max(mx,max(a[x].x[i]-p,0));
		dfs(a[x].m[i],p+1,px);
	}
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	int x,y,q;
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++) 
	{
		cin>>x>>y>>q;
		a[x].m.push_back(y);
		a[x].x.push_back(q);
	}
	dfs(1,0,0);
	cout<<mm;
	return 0;
 } 
