#include<bits/stdc++.h>
using namespace std;
int s=0,k=0,p=0;
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n;
	cin>>n;
	bool q=false;
	while(s<n)
	{
		p++;
		if((n-s-1)%3==0&&q==false) 
		{
			k=p;
			q=true;
		}
		s+=(n-s-1)/3+1;
	}
	cout<<p<<" "<<k;
	return 0;
}
