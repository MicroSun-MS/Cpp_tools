// O(T(sqrt(M) + log log M))
#include <iostream>
using namespace std;

using ll = long long;

ll _gcd(ll a, ll b)
{
	return b ? _gcd(b, a % b) : a;
}

ll _abs(ll a)
{
	return a > 0 ? a : -a;
}

int main()
{
	freopen("uqe.in", "r", stdin);
	freopen("uqe.out", "w", stdout);
	int t, m;
	cin >> t >> m;
	while (t--)
	{
		ll a, b, c;
		cin >> a >> b >> c;
		ll d = b * b - 4 * a * c;
		if (d < 0)
		{
			cout << "NO" << endl;
		}
		else if (d == 0)
		{
			if (b)
			{
				a *= 2;
				b = -b;
				ll e = _gcd(_abs(b), _abs(a));
				a /= e;
				b /= e;
				if (a < 0)
				{
					b = -b;
					a = -a;
				}
				if (a == 1)
				{
					cout << b << endl;
				}
				else
				{
					cout << b << '/' << a << endl;
				}
			}
			else
			{
				cout << 0 << endl;
			}
		}
		else
		{
			ll e = 1;
			for (ll i = 2; i * i <= d; i++)
			{
				while ((d % (i * i)) == 0)
				{
					e *= i;
					d /= i;
					d /= i;
				}
			}
			if (d > 1)
			{
				a *= 2;
				if (b)
				{
					ll _a = a;
					ll _b = -b;
					ll f = _gcd(_abs(_a), _abs(_b));
					_a /= f;
					_b /= f;
					if (_a < 0)
					{
						_a = -_a;
						_b = -_b;
					}
					if (_a == 1)
					{
						cout << _b;
					}
					else
					{
						cout << _b << '/' << _a;
					}
					cout << '+';
				}
				ll f = _gcd(_abs(a), _abs(e));
				a /= f;
				e /= f;
				a = _abs(a);
				e = _abs(e);
				if (e > 1)
				{
					cout << e << '*';
				}
				cout << "sqrt(" << d << ')';
				if (a > 1)
				{
					cout << '/' << a;
				}
				cout << endl;
			}
			else
			{
				a *= 2;
				b = -b;
				if (a < 0)
				{
					a = -a;
					b = -b;
				}
				b += e;
				if (b)
				{
					ll f = _gcd(a, _abs(b));
					a /= f;
					b /= f;
					cout << b;
					if (a > 1)
					{
						cout << '/' << a;
					}
					cout << endl;
				}
				else
				{
					cout << 0 << endl;
				}
			}
		}
	}
	return 0;
}

