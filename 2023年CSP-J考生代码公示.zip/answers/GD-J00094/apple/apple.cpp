// O(log n)
#include <iostream>
using namespace std;

int main()
{
	freopen("apple.in", "r", stdin);
	freopen("apple.out", "w", stdout);
	long long n;
	cin >> n;
	long long t = 0, r = 0;
	while (n)
	{
		t++;
		if (n % 3 == 1)
		{
			if (!r)
			{
				r = t;
			}
			n = (n - 1) / 3 * 2;
		}
		else if (n % 3 == 2)
		{
			n = (n - 2) / 3 * 2 + 1;
		}
		else
		{
			n = n / 3 * 2;
		}
	}
	cout << t << ' ' << r << endl;
}

/*
#include <iostream>
#include <iomanip>
#include <windows.h>
#include <cstring>
#include <random>
#include <ctime>
using namespace std;

int mp[55][55];
bool vis[55][55];

int n, m, b;
int t = 0;
int o = 0;
int mk = 0;

void print()
{
	cout << "   ";
	for (int i = 1; i <= m; i++)
	{
		cout << left << setw(3) << i;
	}
	for (int i = 1; i <= n; i++)
	{
		cout << endl;
		cout << left << setw(3) << i;
		for (int j = 1; j <= m; j++)
		{
			if (!vis[i][j])
			{
				cout << "## ";
			}
			else
			{
				int b = mp[i][j];
				if (b == 0)
				{
					cout << "   ";
				}
				else if (b == -1 || b > 8)
				{
					cout << "MK ";
				}
				else
				{
					cout << left << setw(3) << b;
				}
			}
		}
	}
	cout << endl;
	cout << endl;
	cout << "Remaining bombs: " << b - mk << endl;
	cout << endl;
	cout << "o i j : Open (i, j)" << endl;
	cout << "m i j : Mark (i, j), but in the first step, it's recognized as opening" << endl;
	cout << "(row, column)" << endl;
	cout << endl;
	cout << "> ";
}

int dx[8] = {-1, 0, 1, -1, 1, -1, 0, 1};
int dy[8] = {-1, -1, -1, 0, 0, 1, 1, 1};

void generate()
{
	memset(mp, 0, sizeof(mp));
	mt19937 tst(time(0));
	for (int i = 1; i <= b; i++)
	{
		int x = tst() % n + 1;
		int y = tst() % m + 1;
		while (mp[x][y])
		{
			x = tst() % n + 1;
			y = tst() % m + 1;
		}
		mp[x][y] = -2;
	}
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= n; j++)
		{
			if (mp[i][j] == -2)
			{
				continue;
			}
			for (int k = 0; k < 8; k++)
			{
				if (mp[i + dx[k]][j + dy[k]] == -2)
				{
					mp[i][j]++;
				}
			}
		}
	}
}

void dfs(int x, int y)
{
	if (x < 1 || x > n || y < 1 || y > n)
	{
		return;
	}
	if (vis[x][y])
	{
		return;
	}
	vis[x][y] = 1;
	o++;
	if (!mp[x][y])
	{
		for (int k = 0; k < 8; k++)
		{
			dfs(x + dx[k], y + dy[k]);
		}
	}
}

int open(int x, int y)
{
	if (vis[x][y])
	{
		cout << "You've already opened or marked this block." << endl;
		return 1;
	}
	if (mp[x][y] == -2)
	{
		cout << "Failed" << endl;
		return -1;
	}
	t++;
	dfs(x, y);
	cout << "Opened" << endl;
	return 0;
}

int mark(int x, int y)
{
	if (vis[x][y] && mp[x][y] > -1 && mp[x][y] < 9)
	{
		cout << "It is empty." << endl;
		return 1;
	}
	if (vis[x][y])
	{
		mk--;
		int b = mp[x][y];
		if (b == -1)
		{
			mp[x][y] = -2;
			vis[x][y] = 0;
		}
		if (b > 9)
		{
			mp[x][y] -= 9;
			vis[x][y] = 0;
		}
		cout << "Unmarked" << endl;
		return 0;
	}
	mk++;
	vis[x][y] = 1;
	int b = mp[x][y];
	if (b == -2)
	{
		mp[x][y] = -1;
	}
	else
	{
		mp[x][y] += 9;
	}
	cout << "Marked" << endl;
	return 0;
}

struct Query
{
	char op;
	int x, y;
};
Query query()
{
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= m; j++)
		{
			if (mp[i][j] > 0 && mp[i][j] < 9)
			{
				int c = 0;
				for (int k = 0; k < 8; k++)
				{
					int x = i + dx[k];
					int y = i + dy[k]; 
					if (!vis[x][y] || mp[x][y] == -2 || mp[x][y] > 8)
					{
						c++;
					}
				}
				if (c == mp[i][j])
				{
					for (int k = 0; k < 8; k++)
					{
						int x = i + dx[k];
						int y = i + dy[k];
						if (!vis[x][y])
						{
							return {'m', x, y}; // mark
						}
					}
				}
				c = 0;
				for (int k = 0; k < 8; k++)
				{
					int x = i + dx[k];
					int y = i + dy[k]; 
					if (mp[x][y] == -2 || mp[x][y] > 8)
					{
						c++;
					}
				}
				if (c == mp[i][j])
				{
					for (int k = 0; k < 8; k++)
					{
						int x = i + dx[k];
						int y = i + dy[k];
						if (!vis[x][y])
						{
							return {'o', x, y}; // open
						}
					}
				}
			}
		}
	}
	return {'o', 1, 1};
}

int main()
{
	cout << "Mine Sweeper" << endl;
	cout << "Please enter the height, width and the number of bombs:" << endl;
	cin >> n >> m >> b;
	system("cls");
	cout << "Mine Sweeper" << endl;
	cout << endl << endl;
	print();
	char op;
	generate();
	while (mp[1][1])
	{
		generate();
	}
	system("cls");
	cout << "Mine Sweeper" << endl;
	open(1, 1);
	cout << endl;
	print();
	while (n * m - o > b)
	{
		Sleep(2000);
//		cin >> op >> x >> y;
		Query q = query();
		char op = q.op;
		int x = q.x, y = q.y;
		cout << op << ' ' << x << ' ' << y << endl; 
		system("cls");
		cout << op << ' ' << x << ' ' << y << endl; 
		cout << "Mine Sweeper" << endl;
		if (op == 'o')
		{
			int r = open(x, y);
			if (r == -1)
			{
				return 0;
			}
		}
		else if (op == 'm')
		{
			mark(x, y);
		}
		cout << endl;
		print();
	}
	cout << "You used " << t << " steps." << endl;
}

*/

