// O(n)
#include <iostream>
using namespace std;

#define MAXN 100005

long long v[MAXN];
long long a[MAXN];

long long n, d;

int main()
{
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	cin >> n >> d;
	for (int i = 1; i < n; i++)
	{
		cin >> v[i];
	}
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i];
	}
	long long r = 0, mn = 0x3ffff3fff3fff3ff;
	long long res = 0;
	for (int i = 1; i < n; i++)
	{
		mn = min(mn, a[i]);
		int b = ((v[i] - r) + d - 1) / d;
		res += b * mn;
		r = b * d + r - v[i];
	}
	cout << res << endl;
	return 0;
}

