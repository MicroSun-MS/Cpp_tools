// O(mk log mk)
#include <iostream>
#include <vector>
#include <cstring>
#include <queue>
using namespace std;

#define MAXN 10005
#define MAXK 105

using pii = pair<int, long long>;

vector<pii> e[MAXN * MAXK];

long long dis[MAXN * MAXK];
bool vis[MAXN * MAXK];

int n, m, k;

int main()
{
	freopen("bus.in", "r", stdin);
	freopen("bus.out", "w", stdout);
	cin >> n >> m >> k;
	for (int i = 1; i <= m; i++)
	{
		int u, v, w;
		cin >> u >> v >> w;
		for (int j = 0; j < k; j++)
		{
			e[u * k + j].push_back({v * k + (j + 1) % k, w});
		}
	}
	memset(dis, 0x3f, sizeof(dis));
	dis[k] = 0;
	priority_queue<pii> q;
	q.push({0, k});
	while (!q.empty())
	{
		int u = q.top().second;
		q.pop();
		vis[u] = 1;
		for (pii c : e[u])
		{
			if (vis[c.first])
			{
				continue;
			}
			long long t = dis[u] + 1;
			if (c.second > t)
			{
				t = t + (c.second - t + k - 1) / k * k;
			}
			if (dis[c.first] > t)
			{
				dis[c.first] = t;
				q.push({-t, c.first});
			}
		}
	}
	cout << dis[n * k] << endl;
	return 0;
}

