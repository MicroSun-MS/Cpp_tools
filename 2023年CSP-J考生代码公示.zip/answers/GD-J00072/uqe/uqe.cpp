#include<bits/stdc++.h>
#define ll long long
using namespace std;
int T,M;
int a,b,c;
ll r;
void gcd(int &x,int &y){
	for(int i=2;i<=min(abs(x),abs(y));i++)
		while(x%i==0&&y%i==0) x/=i,y/=i;
	return;
}
void sq(int &q,ll &r){
	for(int i=2;i*i<=r;i++)
		while(r%(i*i)==0) r/=i*i,q*=i;
	return;
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&T,&M);
	while(T--){
		scanf("%d%d%d",&a,&b,&c);
		r=b*b-4*a*c;
		if(r<0){
			printf("NO\n");	
			continue;
		}
		if(r==0){
			if(b==0){
				printf("0\n");
				continue;	
			}
			int p=-1*b,q=2*a;
			if(q<0) p=-1*p,q=-1*q;
			gcd(p,q);
			if(q<=1) printf("%d\n",p);
			else printf("%d/%d\n",p,q);
			continue;
		}
		int q1=-1*b,q2=1,d=2*a;
		if(d<0) q1=-1*q1,d=-1*d;
		sq(q2,r);
		if(r==1) q1+=q2;
		gcd(q1,d);
		if(q1!=0){
			if(d<=1) printf("%d",q1);
			else printf("%d/%d",q1,d);			
		}
		if(r!=1){
			if(q1!=0) printf("+");
			d=abs(2*a);
			gcd(q2,d);
			if(q2!=1) printf("%d*",q2);
			printf("sqrt(%d)",r);
			if(d!=1) printf("/%d",d);
		}
		if(q1==0&&r==1) printf("%d",q1);
		printf("\n");
	}
	return 0;
}
