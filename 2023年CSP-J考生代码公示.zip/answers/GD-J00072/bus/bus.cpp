#include<bits/stdc++.h>
using namespace std;
const int MAXN=10005,MAXM=20005;
int n,m,k,maxm,ans;
int head[MAXN],num[MAXN],cnt=0;
struct Edge{
	int u,v,a;
	int nxt;
}edge[MAXM];
vector <long long> dis[MAXN];
void add_edge(int u,int v,int a){
	++cnt;
	edge[cnt].u=u,edge[cnt].v=v,edge[cnt].a=a;
	edge[cnt].nxt=head[u],head[u]=cnt;
}
void dij(){
	int s=1;	
	priority_queue <pair<int,int>,vector<pair<int,int> >,greater<pair<int,int> > > q;
	for(int i=0;i*k<=maxm;i++){
		q.push({s,i*k});
		dis[s].push_back(i*k);
	}		
	while(!q.empty()){
		int x=q.top().first,d=q.top().second;
		q.pop();
		for(int i=head[x];i;i=edge[i].nxt){
			int v=edge[i].a,y=edge[i].v;
			if(d>=v){
				dis[y].push_back(d+1);
				ans=max(ans,d+1);
				if(++num[y]>=n) return;
				q.push({y,d+1});
			}
		}
	}
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	scanf("%d%d%d",&n,&m,&k);
	for(int i=1;i<=m;i++){
		int u,v,a;
		scanf("%d%d%d",&u,&v,&a);
		add_edge(u,v,a);
		maxm=max(a,maxm);
	}
	dij();
	ans+=1;
	long long an=ans;
	for(int i=0;i<dis[n].size();i++) if(ans>dis[n][i]&&dis[n][i]%k==0) ans=dis[n][i];
	if(ans==an) printf("-1\n");
	else printf("%d\n",ans);
	return 0;
}
