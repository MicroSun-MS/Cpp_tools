#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int MAXN=100005;
int n,d;
ll v[MAXN],a[MAXN];
ll ans=0,s=0;
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%d",&n,&d);
	for(int i=1;i<n;i++) cin>>v[i];
	for(int i=1;i<=n;i++) cin>>a[i];
	ll minn=1000000000;
	for(int i=1;i<=n-1;i++){
		minn=min(minn,a[i]);
		ll di;
		if(s>v[i]) di=v[i],s-=v[i];
		else di=s,s=0;
		ll d1=(v[i]-di)/d;		
		if((v[i]-di)%d!=0) d1++; 
		ans+=d1*minn;
		s+=d1*d-(v[i]-di);
	}
	printf("%lld\n",ans);
	return 0;
}
