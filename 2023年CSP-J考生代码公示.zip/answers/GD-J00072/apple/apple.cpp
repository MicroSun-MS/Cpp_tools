#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n;
ll d1,d2;
bool f=0;
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%lld",&n);
	while(n){
		d1++;
		if(f==0&&n%3==1) d2=d1,f=1;
		n-=(n+2)/3;
	}
	printf("%lld %lld\n",d1,d2);
	return 0;
}
