# include <cstdio>
using namespace std;
int n;
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	scanf("%d",&n);
	int ans=0,sum=0;
	while(n>0)
	{
		ans++;
		if(n%3==1&&sum==0) sum=ans;
		int p=n/3;
		if(n%3>0) p++;
		n-=p;
	}
	printf("%d %d",ans,sum);
	return 0;
}
