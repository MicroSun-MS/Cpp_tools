# include <cstdio>
# include <cstring>
using namespace std;
int n,a[200007],s[200007],f[200007],h[800007];
long long ans=0,sum=0,g[200007],d;
int min(int x,int y){return x<y?x:y;}
int get(int l,int r,int p,int x)
{
	if(r<=x) return h[p];
	int min1=1000000007,mid=(l+r)/2;
	min1=get(l,mid,p*2,x);
	if(mid+1<=x) min1=min(min1,get(mid+1,r,p*2+1,x));
	return min1;
}
void change(int l,int r,int p,int x,int y)
{
	if(l==r)
	{
		h[p]=y;
		return;
	}
	int mid=(l+r)/2;
	if(mid>=x) change(l,mid,p*2,x,y);
	if(mid+1<=x) change(mid+1,r,p*2+1,x,y);
	h[p]=min(h[p*2],h[p*2+1]);
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d%lld",&n,&d);
	for(int i=1;i<n;i++) scanf("%d",&a[i]);
	for(int i=1;i<=n;i++) scanf("%d",&s[i]);
	memset(h,127,sizeof(h));
	for(int i=2;i<=n;i++) g[i]=g[i-1]+a[i-1];
	for(int i=n;i>=1;i--)
	{
		if(s[i]==0)
		{
			f[i]=n;
			continue;
		}
		int p=get(1,100000,1,s[i]-1);
		if(p>n) f[i]=n;
		else f[i]=p;
		change(1,100000,1,s[i],i);
	}
	int u=1;
	while(u<n)
	{
		long long v=g[f[u]]-g[u];
		long long z=(v-ans)/d;
		if((v-ans)%d>0) z++;
		long long h1=s[u];
		sum+=z*h1;
		ans+=z*d-v;
		u=f[u];
	}
	printf("%lld",sum);
	return 0;
}
