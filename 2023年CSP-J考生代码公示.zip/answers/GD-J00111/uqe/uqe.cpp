# include <cstdio>
# include <cmath>
using namespace std;
int t,m,a,b,c;
int gcd(int x,int y)
{
	if(x%y==0) return y;
	else return gcd(y,x%y);
}
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	scanf("%d%d",&t,&m);
	while(t--)
	{
		scanf("%d%d%d",&a,&b,&c);
		int d=b*b-4*a*c;
		if(d<0) printf("NO\n");
		else
		{
			int g=sqrt(d);
			if(2*a<0) g=-g;
			if(g*g==d&&(0-b+g)%(2*a)==0)
			{
				printf("%d\n",(0-b+g)/2/a);
				continue;
			}
			else
			{
				if(g*g==d)
				{
					int p=0-b+g,q=2*a;
					int ans=((p<0)^(q<0));
					p=abs(p),q=abs(q);
					int f=0;
					if(p>q) f=gcd(p,q);
					else f=gcd(q,p);
					if(ans) printf("-");
					printf("%d/%d\n",p/f,q/f);
					continue;
				}
				else
				{
					if(b!=0)
					{
						int p=-b,q=2*a;
						int ans=((p<0)^(q<0));
						p=abs(p),q=abs(q);
						int f=0;
						if(p>q) f=gcd(p,q);
						else f=gcd(q,p);
						p/=f,q/=f;
						if(ans) printf("-");
						if(q==1) printf("%d+",p);
						else printf("%d/%d+",p,q);
					}
					int q2=1,r=b*b-4*a*c;
					for(int i=2;i<=10000;i++)
					{
						if(i*i>r) break;
						while(r%(i*i)==0&&r>0)
						{
							r/=(i*i);
							q2*=i;
						}
					}
					if(q2%(2*a)==0)
					{
						r=abs(r);
						if(q2/2/a<0) q2=-q2;
						if(q2/2/a==1) printf("sqrt(%d)\n",r);
						else printf("%d*sqrt(%d)\n",q2/2/a,r);
						continue;
					}
					int t1=q2,t2=2*a;
					int f=0;
					if(t1>t2) f=gcd(t1,t2);
					else f=gcd(t2,t1);
					t1/=f,t2/=f;
					if(t1==1)
					{
						r=abs(r),t2=abs(t2); 
						printf("sqrt(%d)/%d\n",r,t2);
						continue;
					}
					t1=abs(t1),r=abs(r),t2=abs(t2);
					printf("%d*sqrt(%d)/%d\n",t1,r,t2);
				}
			}
		}
	}
	return 0;
}
