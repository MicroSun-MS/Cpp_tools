#include<bits/stdc++.h>
#define ll long long
using namespace std;
int n,m,i,j,k,ans,cnt;
bool is;
int read(){
	int x=0,y=1;
	char ch=getchar();
	if(ch<'0'||ch>'9'){
		if(ch=='-')y=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+(ch-'0');
		ch=getchar();
	}
	return x*y;
}
int main(){
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	n=read();
	while(n>0){
		cnt++;
		if((n-1)%3==0&&!is){
			is=1;
			ans=cnt;
		}
		k=(n-1)/3;
		n=n-k-1;
	}
	printf("%d %d\n",cnt,ans);
	return 0;
}
