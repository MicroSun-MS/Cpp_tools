#include<bits/stdc++.h>
#define N 100005
#define ll long long
using namespace std;
ll t,n,m,i,j,k=1e9,ans,cnt,a,b,c,dt,x,y;
bool is;
ll read(){
	ll x=0,y=1;
	char ch=getchar();
	if(ch<'0'||ch>'9'){
		if(ch=='-')y=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+(ch-'0');
		ch=getchar();
	}
	return x*y;
}
ll gcd(int x,int y){
	if(x%y==0)return y;
	return gcd(y,x%y);
}
int main(){
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	t=read(),m=read();
	while(t--){
		a=read(),b=read(),c=read();
		dt=b*b-4*a*c;
		if(dt<0){
			printf("NO\n");
			continue;
		}
		else if(dt==0){
			k=gcd(abs(b),abs(2*a));
			if(2*a<0)k=-k;
			if(b==0){
				printf("0\n");
				continue;
			}
			if(2*a/k==1){
				printf("%lld\n",-b/k);
			}
			else{
				printf("%lld/%lld\n",-b/k,2*a/k);
			}
		}else{
			for(int i=sqrt(dt);i>=1;i--){
				if(dt%(i*i)==0){
					is=1;
					x=i;
					break;
				}
			}
			if(x==1){
				is=0;
			}
			if(dt/(x*x)==1){
				is=0;
				if(a<0){
					b=b+x;
				}else{
					b=b-x;
				}
				k=gcd(abs(b),abs(2*a));
				if(2*a<0)k=-k;
				if(2*a/k==1){
					printf("%lld\n",-b/k);
				}
				else{
					printf("%lld/%lld\n",-b/k,2*a/k);
				}
			}else{
				k=gcd(abs(b),abs(2*a));
				if(2*a<0)k=-k;
				if(2*a/k==1&&b!=0){
					printf("%lld+",-b/k);
				}else if(b!=0){
					printf("%lld/%lld+",-b/k,2*a/k);
				}
				if(is){
					y=gcd(x,abs(2*a));
					if(x/y==1){
						printf("sqrt(%lld)/%lld\n",dt/(x*x),abs(2*a)/y);
					}else if(abs(2*a)/y==1){
						printf("%lld*sqrt(%lld)\n",x/y,dt/(x*x));
					}else{
						printf("%lld*sqrt(%lld)/%lld\n",x/y,dt/(x*x),abs(2*a)/y);
					}
				}else{
					printf("sqrt(%lld)/%lld\n",dt,abs(2*a));
				}
			}
		}
	}
	return 0;
}
