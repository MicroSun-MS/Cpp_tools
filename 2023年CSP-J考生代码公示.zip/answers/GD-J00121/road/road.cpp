#include<bits/stdc++.h>
#define N 100005
#define ll long long
using namespace std;
ll n,m,i,j,k=1e9,ans,cnt,d[N],x,a[N],dis;
bool is;
ll read(){
	ll x=0,y=1;
	char ch=getchar();
	if(ch<'0'||ch>'9'){
		if(ch=='-')y=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+(ch-'0');
		ch=getchar();
	}
	return x*y;
}
int main(){
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	n=read(),m=read();
	for(int i=1;i<=n-1;i++){
		d[i]=read();
	}
	for(int i=1;i<=n;i++){
		a[i]=read();
	}
	for(int i=1;i<=n;i++){
		if(a[i]<k){
			if(dis%m!=0){
				cnt=dis/m+1;
				x=m*cnt-dis;
				ans+=k*cnt;
			}
			else{
				cnt=dis/m;
				x=0;
				ans+=k*cnt;
			}
			dis=d[i]-x;
			k=a[i];
		}
		else{
			dis+=d[i];
		}
	}
	if(dis){
		if(dis%m!=0){
			cnt=dis/m+1;
			x=m*cnt-dis;
			ans+=k*cnt;
		}
		else{
			cnt=dis/m;
			x=0;
			ans+=k*cnt;
		}
	}
	printf("%lld\n",ans);
	return 0;
}
