#include<bits/stdc++.h>
#define N 100005
#define ll long long
using namespace std;
ll t,n,m,i,j,k,ans,cnt,a,b,c;
bool is;
ll read(){
	ll x=0,y=1;
	char ch=getchar();
	if(ch<'0'||ch>'9'){
		if(ch=='-')y=-1;
		ch=getchar();
	}
	while(ch>='0'&&ch<='9'){
		x=x*10+(ch-'0');
		ch=getchar();
	}
	return x*y;
}
int main(){
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	n=read(),m=read(),t=read();
	for(i=1;i<=m;i++){
		scanf("%lld%lld%lld",&a,&b,&c);
	}
	printf("-1\n");
	return 0;
}
