#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
int n,d,a[N],b[N],s[N];
int main(){
	freopen("road.in","w",stdin);
	freopen("road.out","r",stdout);
	scanf("%d%d",&n,&d);
	for(int i=1;i<n;i++){
		scanf("%d",&a[i]);
		s[i]=s[i-1]+a[i];
	}
	for(int i=1;i<=n;i++) scanf("%d",&b[i]);
	printf("%d\n",b[1]*s[n-1]/d);
	return 0;
}
