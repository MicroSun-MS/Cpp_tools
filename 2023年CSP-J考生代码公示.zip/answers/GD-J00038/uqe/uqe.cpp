#include<bits/stdc++.h>
using namespace std;
int t,m;
int main(){
	freopen("uqe.in","w",stdin);
	freopen("uqe.out","r",stdout);
	scanf("%d%d",&t,&m);
	int a,b,c;
	while(t--){
		scanf("%d%d%d",&a,&b,&c);
		int det=b*b-4*a*c;
		int j=(-b+sqrt(det))/(2*a);
		printf("%d\n",j); 
	}
	return 0;
}
