#include<bits/stdc++.h>
using namespace std;
const int N=1e7+10; 
int n,a[N];
bool abc(){
	for(int i=1;i<=n;i++) if(!a[i]) return false;
	return true;
}
int main(){
	freopen("apple.in","w",stdin);
	freopen("apple.out","r",stdout);
	scanf("%d",&n);
	int sum=0;
	while(!abc()){
		sum++;
		int k=1;
		while(a[k]) k++;
		a[k]=sum;
		int j=0;
		for(int i=k;i<=n;i++){
			if(a[i]) continue;
			++j;
			if(j==3){
				a[i]=sum;
				j=0;
			}
		}
	}
	printf("%d %d",sum,a[n]);
	return 0;
}
