#include<bits/stdc++.h>
using namespace std;
int main(){
	freopen("bus.in","w",stdin);
	freopen("bus.out","r",stdout);
	int n,m,k;
	scanf("%d%d%d",&n,&m,&k);
	return 0;
}
