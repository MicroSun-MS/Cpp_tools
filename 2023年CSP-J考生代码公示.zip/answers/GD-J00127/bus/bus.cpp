#include<bits/stdc++.h>
using namespace std;
int n,m,k,f[6505][6505],h,e,g,mi=1111111,ma=-1,ans=1111111,v,c;
void cg(int x,int t)
{
	if(x==n)
	{
		if(t%k==0)
		{
			v=1;
			ans=min(ans,t);
		}
		return;
	}
	for(int i=1;i<=n;i++)
	{
		if(f[x][i]!=0)
		{
			if(f[x][i]-1<=t)
			{
				cg(i,t+1);
			}
		}
	}
}
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d%d",&h,&e,&g);
		if(h<=6500&&e<=6500)f[h][e]=g+1;
		mi=min(mi,g/k);
		ma=max(ma,g/k+1);
	}
	ma++;
	if(mi>0)mi--;
	while(mi+1<ma)
	{
		c=(mi+ma)/2;
		v=0;
		cg(1,k*c);
		if(v==1)ma=c;
		else mi=c;
	}
	if(ans==1111111)cout<<-1;
	else cout<<ans;
	return 0;
}
