#include<bits/stdc++.h>
using namespace std;
int n,m,a[111111],b[111111],v=-1,s;
long long mi;
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>m;
	for(int i=2;i<=n;i++)
	{
		scanf("%d",&a[i]);
		a[i]=a[i]+a[i-1];
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&b[i]);
	}
	v=b[1];
	for(int i=1;i<n;i++)
	{
		if(b[i]<v)
		{
			if(s<a[i])
			{
				if((a[i]-s)%m==0)
				{
					mi+=(a[i]-s)/m*v;
					s=a[i];
				}
				else
				{
					mi+=((a[i]-s)/m+1)*v;
					s+=((a[i]-s)/m+1)*m;
				}
			}
			v=min(b[i],v);
		}
	}
	if(s<a[n])
	{
		if((a[n]-s)%m==0)
		{
			mi+=(a[n]-s)/m*v;
			s=a[n];
		}
		else
		{
			mi+=((a[n]-s)/m+1)*v;
			s+=((a[n]-s)/m+1)*m;
		}
	}
	cout<<mi;
	return 0;
}
