#include<bits/stdc++.h>
using namespace std;
long long n,i,k,p;
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	while(n>0)
	{
		i++;
		if(n%3==1&&p==0)
		{
			k=i;
			p=1;
		}
		if(n%3==0)n=n-n/3;
		else n=n-n/3-1;
	}
	cout<<i<<" "<<k;
	return 0;
}
