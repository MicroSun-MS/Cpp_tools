#include <iostream>
#include <cstring>
#include <algorithm>
#include <queue>
//#define int long long
#define x first
#define y second
using namespace std;

const int N = 2e4 + 10, K = 1e2 + 10, INF = 2e9;

int n, m, k, f[N][K];
vector<pair<int, int> > g[N]; 
bool st[N][K];
int ans = INF;
void bfs() {
	queue<pair<int, int> > q;
	memset(f, 0x7f, sizeof f);
	q.push({1, 0});
	f[1][0] = 0;
	while(q.size()) {
		int t = q.front().x, d = q.front().y; q.pop();
		if(st[t][d]) continue;
		st[t][d] = 1;
		int d2 = (d + 1) % k;
		for(auto i : g[t]) {
			int v = i.x, w = i.y;
			if(f[v][d2] > f[t][d] + 1) {
				f[v][d2] = f[t][d] + 1;
				q.push({v, d2});
			}
		}
	}
}
int mxc = 0;
namespace Bf {
	void dfs(int u, int d) {
		if(u == n) {
			if(d % k == 0)
				ans = min(ans, d);
			return ;
		}
		if(d > ans) return ;
		for(auto i : g[u]) {
			if(d < i.y) continue;
			dfs(i.x, d + 1);
		}
	}
	void main() {
		for(int i = 0; i * k <= mxc; i ++) dfs(1, i * k);
		cout << ans << '\n';
	}
}

int main() {
	ios::sync_with_stdio(0), cin.tie(0);
	freopen("bus.in", "r", stdin);
	freopen("bus.out", "w", stdout);
	cin >> n >> m >> k;
	bool flg = 1;
	for(int i = 1, a, b, c; i <= m; i ++) {
		cin >> a >> b >> c;
		g[a].push_back({b, c});
		mxc = max(mxc, c);
		if(c != 0) flg = 0;
	} 
	if((n <= 10) || (!flg && n <= 20)) {
		Bf::main();
		return 0;
	}
	else if(flg) {
		bfs();
		cout << (f[n][0] >= INF ? -1 : f[n][0]) << '\n';
	}
	else cout << -1 << '\n';
	
	return 0;
} 
