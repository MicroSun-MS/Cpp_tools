#include <iostream>
#include <cstring>
#include <algorithm>
#include <queue>
#define int long long

using namespace std;

const int N = 1e5 + 10;

int n, d, a[N], v[N], s[N];
int pos[N], idx;

signed main() {
	ios::sync_with_stdio(0), cin.tie(0);
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	cin >> n >> d;
	for(int i = 2; i <= n; i ++) cin >> a[i], s[i] = s[i - 1] + a[i];
	for(int i = 1, lst = 1e9; i <= n; i ++) {
		cin >> v[i];
		if(lst > v[i]) {
			lst = v[i];
			pos[++ idx] = i;
		}
	}
	if(pos[idx] != n) pos[++ idx] = n;
	int ans = 0, oil = 0;
	for(int i = 1; i < idx; i ++) {
		if(oil >= s[pos[i + 1]] - s[pos[i]]) oil -= s[pos[i + 1]] - s[pos[i]];
		else {
			int rst = s[pos[i + 1]] - s[pos[i]] - oil; // ��Ҫ rst km ���� 
			int tmp = (rst + d - 1) / d; // ��Ҫ�� tmp ���� 
			ans += tmp * v[pos[i]];
			oil = oil + tmp * d - s[pos[i + 1]] + s[pos[i]];
		}
	}
	cout << ans << '\n';
	
	return 0;
} 
