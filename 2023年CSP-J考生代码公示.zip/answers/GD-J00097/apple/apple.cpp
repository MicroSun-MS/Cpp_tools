#include <iostream>
#include <cstring>
#include <algorithm>
#include <queue>
//#define int long long

using namespace std;

int n;

signed main() {
	ios::sync_with_stdio(0), cin.tie(0);
	freopen("apple.in", "r", stdin);
	freopen("apple.out", "w", stdout);
	cin >> n;
	n --;
	int tot = n + 1, ans1 = 0, ans2 = 0;
	while(tot) tot -= (tot + 2) / 3, ans1 ++;
	while(n % 3) n -= (n + 2) / 3, ans2 ++;
	cout << ans1 << ' ' << ans2 + 1 << '\n';
	
	return 0;
} 
