#include <iostream>
#include <cstring>
#include <algorithm>
#include <queue>
//#define int long long

using namespace std;

const int N = 1e3 + 10;

int a, b, c, delta;

bool check(int x) {
	int tmp = (int)sqrt(x) * (int)sqrt(x);
	return tmp == x;
}

int hj(int &a, int &b) {
	int d = __gcd(a, b);
	a /= d, b /= d;
}

int get_p(int &x) {
	int res = 1;
	for(int p = 2; p * p <= x; p ++) {
		if(x % (p * p) == 0) {
			res = max(res, p);
		}
	} 
	x /= res * res;
	return res;
}

void print(int delta, int a) {
	if(a < 0 && delta < 0) a = -a, delta = -delta;
	hj(delta, a);
	if(delta < 0 || a < 0) {
		cout << "-";
		delta = abs(delta), a = abs(a);
	}
	if(a == 1) cout << delta;
	else cout << delta << '/' << a;
}

void work() {
	cin >> a >> b >> c;
	delta = b * b - 4ll * a * c;
	if(delta < 0) { // �����޽� 
		cout << "NO\n";
		return ;
	}
	a *= 2;
	if(check(delta)) { // ������ 
		delta = sqrt(delta);
		if(a > 0) delta -= b;
		else delta = -delta - b;
		print(delta, a);
		cout << '\n';
		return ;
	}
	if(b != 0) print(-b, a), cout << '+';
	int q2 = get_p(delta);
	if(q2 == a) {
		cout << "sqrt(" << delta << ")\n";
		return ;
	}
	else if(q2 % a == 0) {
		if(abs(q2 / a) != 1) cout << abs(q2 / a) << '*';
		cout << "sqrt(" << delta << ")\n";
		return ;
	} 
	else if(a % q2 == 0) {
		a /= q2;
		a = abs(a);
		cout << "sqrt(" << delta << ")/" << a << '\n';
		return ;
	} 
	hj(a, q2);
	a = abs(a), q2 = abs(q2);
	cout << q2 << "*sqrt(" << delta << ")/" << a << '\n';
}

signed main() {
	ios::sync_with_stdio(0), cin.tie(0);
	freopen("uqe.in", "r", stdin);
	freopen("uqe.out", "w", stdout);
	int T, m;
	cin >> T >> m;
	while(T --) work();
	
	return 0;
} 
