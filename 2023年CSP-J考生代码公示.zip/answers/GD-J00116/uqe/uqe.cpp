#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int T,M;
int a,b,c;
int gcd(int x,int y){
	int minx=(x<y)?x:y;
	for(int i=x;i>0;i--){
		if(x%i==0&&y%i==0)return i;
	}
}
int main(){
	ios::sync_with_stdio(0);
	freopen("uqe.in","r",stdin);
	freopen("uqe.in","w",stdout);
	cin>>T>>M;
	while(T--){
		cin>>a>>b>>c;
		int tmp=b*b-4*a*c;
		if(tmp<0){
			cout<<"NO"<<endl;
			continue;
		}
		else{
			if(tmp==0){
				if((-b)%(2*a)==0)cout<<(-b)/(2*a)<<endl;
				else{
					int g=gcd((-b),(2*a));
					cout<<(-b)/g<<"/"<<(2*a)/g;
				}
			}
			else{
				double s=sqrt(tmp);
				int j1,j2;
				j1=(-b+s)/(2*a);
				j2=(-b-s)/(2*a);
				if(s==(int)s){
					if(j1>j2){
						if(j1==(int)j1)cout<<j1<<endl;
						else{
							int g=gcd((-b+s),(2*a));
							cout<<(-b+s)/g<<"/"<<(2*a)/g;
						}
					}
					else{
						if(j2==(int)j2)cout<<j2<<endl;
						else{
							int g=gcd((-b-s),(2*a));
							cout<<(-b-s)/g<<"/"<<(2*a)/g;
						}
					}
				}
				else{
					cout<<endl;
				}
			}
		}
	}
}
