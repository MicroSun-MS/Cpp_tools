#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int n,d,last_more;
int v[100000],a[100005],sum_v[100005];
int dp[100005];
void f(int x){
	int minx=1e9+7,tmp,mini;
	for(int i=1;i<x;i++){
		tmp=(i==x-1)?(int)(dp[i]+ceil(1.0*(v[x-1]-last_more)/d)*a[i]):(int)(dp[i]+ceil(1.0*(sum_v[x-1]-sum_v[i-1])/d)*a[i]);
		minx=(minx<tmp)?minx:tmp;
		mini=(minx<tmp)?mini:i;
	}
	last_more=tmp/a[mini]*d-(sum_v[x-1]-sum_v[mini-2]);
	dp[x]=minx;
}
void solve(int n){
	for(int i=2;i<=n;i++)f(i);
}
int main(){
	ios::sync_with_stdio(0);
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=1;i<n;i++){
		cin>>v[i];
		sum_v[i]=sum_v[i-1]+v[i];
	}
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	dp[1]=0;
	solve(n);
	cout<<dp[n]<<" ";
}
