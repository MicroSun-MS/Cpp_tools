#include<iostream>
#include<cstdio>
#include<cmath>
#define ll long long
using namespace std;
ll n,cnt,cnt2,st=1,tmp2;
bool b[1000000001];
int main(){
	ios::sync_with_stdio(0);
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	cin>>n;
	ll tmp=n;
	while(tmp>0){
		tmp2=ceil(tmp/3.0);
		tmp-=tmp2;
		cnt++;
		for(int i=st,cnt3=0;i<=n;i++){
			if(b[i]==1)continue;
			if(cnt3==tmp2)break;
			if(b[i]==0){
				if(cnt3%3==0){
					b[i]=1;
					if(i==n){
						cnt2=cnt;
						break;
					}
				}
				if(cnt3==1)st=i;
				cnt3++;
			}
		}
	}
	cout<<cnt<<" "<<cnt2;		
}
