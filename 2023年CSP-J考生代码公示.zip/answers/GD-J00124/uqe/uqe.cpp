#include <bits/stdc++.h>
using namespace std;
int M, T;

int gcd(int a, int b) {
	return b == 0 ? a : gcd(b, a % b);
}

void check(int &q, int &d) {
	for (int i = floor(sqrt(d)); i >= 2; i--)
		if (d % (i * i) == 0) {
			q *= i, d /= i * i;
			return;
		}
}

int main() {
	freopen("uqe.in", "r", stdin);
	freopen("uqe.out", "w", stdout);
	
	cin >> T >> M;
	while (T--) {
		int a, b, c, delta;
		bool flag = false;
		cin >> a >> b >> c;
		delta = b * b - 4 * a * c;
		if (delta < 0) {
			cout << "NO" << endl;
			continue;
		}
		//ǰ�� b/a1
		int a1 = a * 2, a2 = a * 2;
		if (a1 < 0) a1 *= -1;
		else b *= -1;
		int g = gcd(a1, abs(b));
		a1 /= g, b /= g;
		//���� q2*sqrt(delta)/a2
		int q2 = 1;
		check(q2, delta);
		a2 = abs(a2), q2 = abs(q2);
		g = gcd(a2, q2);
		a2 /= g, q2 /= g;
		//����
		if (delta == 1) {
			int a3 = a1 * a2;
			int b3 = a1 * q2 + a2 * b;
			int g = gcd(a3, b3);
			a3 /= g, b3 /= g;
			if (a3 < 0) b3 *= -1, a3 *= -1;
			if (a3 == 1) printf("%d\n", b3);
			else printf("%d/%d\n", b3, a3);
		} else if (delta == 0) {
			if (a1 == 1) printf("%d\n", b);
			else printf("%d/%d\n", b, a1);
		} else {
			if (b != 0)
				if (a1 == 1) printf("%d+", b);
				else printf("%d/%d+", b, a1);
			if (a2 == 1 && q2 == 1) printf("sqrt(%d)\n", delta);
			else if (q2 == 1) printf("sqrt(%d)/%d\n", delta, a2);
			else if (a2 == 1) printf("%d*sqrt(%d)\n", q2, delta);
			else printf("%d*sqrt(%d)/%d\n", q2, delta, a2);
		}
	}
	fclose(stdin);
	fclose(stdout);
	return 0;
} 
