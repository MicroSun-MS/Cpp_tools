#include <bits/stdc++.h>
using namespace std;

short a[10010][10010];

struct node{
	int num, t;
};
int n, m, k;
queue <node> Q;
int bfs(int st) {
	node start;
	start.num = 1; start.t = st;
	Q.push(start);
	while (!Q.empty()) {
		node f = Q.front();
		Q.pop();
		if (f.num == n && f.t % k == 0) {
			cout << f.t;
			return 0;
		}
		for (int i = 1; i <= n; i++)
			if (a[f.num][i] != -1 && f.t >= a[f.num][i]) {
				node next;
				next.num = i;
				next.t = f.t + 1;
				Q.push(next);
			}
	}
	return 1;
}

int main() {
	freopen("bus.in", "r", stdin);
	freopen("bus.out", "w", stdout);
	ios::sync_with_stdio(false);
	memset(a, -1, sizeof(a));
	cin >> n >> m >> k;
	for (int i = 0; i < m; i++) {
		int b, c, d;
		cin >> b >> c >> d;
		a[b][c] = d;
	}
	cout << -1;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
