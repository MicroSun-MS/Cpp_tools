#include <bits/stdc++.h>
using namespace std;
int n, d, v[100010], a[100010];
struct stop{
	int num, price;
};
queue <stop> Q;

long long add(int f, int t) {
	int sum = 0;
	for (int i = f; i < t; i++)
		sum += v[i];
	return sum;
}

int main() {
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	cin >> n >> d;
	for (int i = 0; i < n - 1; i++) cin >> v[i];
	for (int i = 0; i < n; i++) cin >> a[i];
	int last = 100010;
	for (int i = 0; i < n; i++)
		if (last > a[i]) {
			stop b;
			b.num = i ;
			b.price = a[i];
			Q.push(b);
			last = a[i];
		}
	long long sum = 0, rest = 0;
	while (1) {
		stop b = Q.front();
		Q.pop();
		stop c = Q.front();
		if (Q.empty()) {
			sum += b.price * ceil((add(b.num, n) - rest) * 1.0 / d);
			break;
		}
		long long r = ceil((add(b.num, c.num) - rest) * 1.0 / d);
		sum += b.price * r;
		rest = r * d - (add(b.num, c.num) - rest);
	}
	cout << sum;
	fclose(stdin);
	fclose(stdout);
	return 0;
}
