#include <bits/stdc++.h>
using namespace std;
int n;
int main() {
	freopen("apple.in", "r", stdin);
	freopen("apple.out", "w", stdout);
	cin >> n;
	int m = n, d = 0, ans = 0;
	while (m > 0) {
		if (m % 3 == 1 && ans == 0) ans = d + 1;
		m -= ceil(m / 3.0), d++;
	}
	cout << d << ' ' << ans;
	
	fclose(stdin);
	fclose(stdout);
	return 0;
}
