#include<bits/stdc++.h>
#include<cstdio>
using namespace std;
long long a[100000001];
int num;
int i=1;
int day=1;
int d2;
int main()
{
	freopen("apple.in","r",stdin);
	freopen("apple.out","w",stdout);
	int n;
	cin>>n;
	while(num<n)
	{
		if(i<=n)
		{
			if(a[i]==1)
			{
				i++;
			}
			else
			{
				a[i]=1;
				if(i==n)
				{
					d2=day;
				}
				for(int j=1;j<=3;j++)
				{
					i++;
					if(a[i]==1)
					{
						j--;
					}
				}
				num++;
			}
		}
		else
		{
			i=1;
			day++;
		}
	}
	cout<<day<<" "<<d2<<endl;
	return 0;
}
