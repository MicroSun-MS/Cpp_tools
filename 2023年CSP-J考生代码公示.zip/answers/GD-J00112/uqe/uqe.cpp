#include<bits/stdc++.h>
#include<cstdio>
using namespace std;
int up;
int un;
int bei;
int yu;
void shai(int a,int b)
{
	int q=max(abs(a),abs(b));
	for(int i=q;i>=2;i--)
	{
		if(a%i==0&&b%i==0)
		{
			a/=i;
			b/=i;
		}
	}
	up=a;
	un=b;
}
void shai2(int a)
{
	bei=1;
	int q=floor(sqrt(a));
	for(int i=q;i>=2;i--)
	{
		if(a%q*q==0)
		{
			a/=q*q;
			bei*=q;
		}
	}
	yu=a;
}
int main()
{
	freopen("uqe.in","r",stdin);
	freopen("uqe.out","w",stdout);
	int n,m;
	cin>>n>>m;
	int a1[101],b1[101],c1[101];
	int a,b,c;
	for(int i=1;i<=n;i++)
	{
		cin>>a1[i]>>b1[i]>>c1[i];
	}
	for(int i=1;i<=n;i++)
	{
		a=a1[i];
		b=b1[i];
		c=c1[i];
		int d=b*b-4*a*c;
		if(d<0)
		{
			cout<<"NO"<<endl;
		}
		else if(d==0)
		{
			double x=-(b/(2*a));
			if(abs(x)-floor(abs(x))==0)
			{
				cout<<x<<endl;
			}
			else
			{
				if(b==0)
				{
					cout<<0<<endl;
				}
				else
				{
					shai(b,2*a);
					if(x>=0)
					{
						cout<<up<<"/"<<un<<endl;
					}
					else
					{
						cout<<"-"<<up<<"/"<<un<<endl;
					}
				}
			}
		}
		else if(d>0)
		{
			double x;
			if(sqrt(d)-floor(sqrt(d))==0)
			{
				shai(sqrt(d)-b,2*a);
				x=-((sqrt(d)-b)/(2*a));
				if(x>=0)
				{
					cout<<up<<"/"<<un<<endl;
				}
				else
				{
					cout<<"-"<<up<<"/"<<un<<endl;
				}
			}
			else
			{
				double y=-(b/(2*a));
				if(abs(y)-floor(abs(y))==0)
				{
					shai2(d);
					cout<<y;
					shai(bei,2*a);
					if(up!=1)
					{
						if(a>0)
						{
							cout<<"+"<<up<<"*";
						}
						else
						{
							cout<<"-"<<up<<"*";
						}
					}
					cout<<"sqrt("<<yu<<")";
					if(un!=1)
					{
						cout<<"/"<<un<<endl;
					}
				}
				else
				{
					shai(b,2*a);
					if(y>=0)
					{
						cout<<up<<"/"<<un<<endl;
					}
					else
					{
						cout<<"-"<<up<<"/"<<un<<endl;
					}
					shai2(d);
					shai(bei,a*2);
					if(up!=1)
					{
						if(a>0)
						{
							cout<<"+"<<up<<"*";
						}
						else
						{
							cout<<"-"<<up<<"*";
						}
					}
					cout<<"sqrt("<<yu<<")";
					if(un!=1)
					{
						cout<<"/"<<un<<endl;
					}
				}
			}
		}
	}
	return 0;
}
