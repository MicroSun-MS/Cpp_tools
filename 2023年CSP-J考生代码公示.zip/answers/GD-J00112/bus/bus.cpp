#include<bits/stdc++.h>
#include<cstdio>
using namespace std;
int main()
{
	freopen("bus.in","r",stdin);
	freopen("bus.out","w",stdout);
	cin>>n>>m>>k;
	int a[10001],b[10001],c[10001];
	for(int i=1;i<=m;i++)
	{
		cin>>a[i]>>b[i]>>c[i];
	}
	cout<<-1<<endl;
	return 0;
}
