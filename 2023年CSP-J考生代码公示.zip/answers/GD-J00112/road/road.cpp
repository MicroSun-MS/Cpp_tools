#include<bits/stdc++.h>
#include<cstdio>
using namespace std;
int n,d;
int a[10001],y[10001];
int dp[10001];
int le[10001];
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>d;
	for(int i=1;i<=d;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=n;i++)
	{
		cin>>y[i];
	}
	dp[1]=0;
	if(a[1]%d==0)
	{
		dp[2]=y[1]*(a[1]/d);
	}
	else
	{
		dp[2]=y[1]*(a[1]/d+1);
		le[2]=(a[1]/d+1)*d-a[1];
	}
	for(int i=3;i<=n;i++)
	{
		int r1=a[i-2]-le[i-2]+a[i-1];
		int r2=a[i-1]-le[i-1];
		if(r1%d==0&&r2%d==0)
		{
			if(y[i-2]*(r1/d)+dp[i-2]>y[i-1]*(r2/d)+dp[i-1])
			{
				dp[i]=y[i-1]*(r2/d)+dp[i-1];
				le[i]=0;
			}
			else
			{
				dp[i]=y[i-2]*(r1/d)+dp[i-2];
				le[i]=0;
			}
		}
		else if(r1%d!=0&&r2%d==0)
		{
			if(y[i-2]*(r1/d+1)+dp[i-2]>y[i-1]*(r2/d)+dp[i-1])
			{
				dp[i]=y[i-1]*(r2/d)+dp[i-1];
				le[i]=0;
			}
			else
			{
				dp[i]=y[i-2]*(r1/d+1)+dp[i-2];
				le[i]=d*(r1/d+1)-a[i-1]-a[i-2];
			}
		}
		else if(r1%d==0&&r2%d!=0)
		{
			if(y[i-2]*(r1/d)+dp[i-2]>y[i-1]*(r2/d+1)+dp[i-1])
			{
				dp[i]=y[i-1]*(r2/d)+dp[i-1];
				le[i]=d*(r2/d+1)-a[i-1];
			}
			else
			{
				dp[i]=y[i-2]*(r1/d)+dp[i-2];
				le[i]=0;
			}
		}
		else if(r1%d!=0&&r2%d!=0)
		{
			if(y[i-2]*(r1/d+1)+dp[i-2]>y[i-1]*(r2/d+1)+dp[i-1])
			{
				dp[i]=y[i-1]*(r2/d+1)+dp[i-1];
				le[i]=d*(r2/d+1)-a[i-1];
			}
			else
			{
				dp[i]=y[i-2]*(r1/d+1)+dp[i-2];
				le[i]=d*(r1/d+1)-a[i-1]-a[i-2];
			}
		}
	}
	cout<<dp[n]<<endl;
	return 0;
}
